import { o as __toESM, t as __commonJSMin } from "./chunk-6z4oVpB-.js";
import { It as ref } from "./vue.runtime.esm-bundler-DDuXT-9r.js";
import { c as require_isObject, f as require__root } from "./_MapCache-BGBKpT5S.js";
import { d as require_isSymbol } from "./truncate-Dc79aML5.js";
var require__trimmedEndIndex = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var reWhitespace = /\s/;
	function trimmedEndIndex$1(string) {
		var index = string.length;
		while (index-- && reWhitespace.test(string.charAt(index)));
		return index;
	}
	module.exports = trimmedEndIndex$1;
}));
var require__baseTrim = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var trimmedEndIndex = require__trimmedEndIndex();
	var reTrimStart = /^\s+/;
	function baseTrim$1(string) {
		return string ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, "") : string;
	}
	module.exports = baseTrim$1;
}));
var require_toNumber = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var baseTrim = require__baseTrim(), isObject$1 = require_isObject(), isSymbol = require_isSymbol();
	var NAN = NaN;
	var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
	var reIsBinary = /^0b[01]+$/i;
	var reIsOctal = /^0o[0-7]+$/i;
	var freeParseInt = parseInt;
	function toNumber$1(value) {
		if (typeof value == "number") return value;
		if (isSymbol(value)) return NAN;
		if (isObject$1(value)) {
			var other = typeof value.valueOf == "function" ? value.valueOf() : value;
			value = isObject$1(other) ? other + "" : other;
		}
		if (typeof value != "string") return value === 0 ? value : +value;
		value = baseTrim(value);
		var isBinary = reIsBinary.test(value);
		return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
	}
	module.exports = toNumber$1;
}));
var require_now = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var root = require__root();
	var now$1 = function() {
		return root.Date.now();
	};
	module.exports = now$1;
}));
var require_debounce = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var isObject = require_isObject(), now = require_now(), toNumber = require_toNumber();
	var FUNC_ERROR_TEXT = "Expected a function";
	var nativeMax = Math.max, nativeMin = Math.min;
	function debounce(func, wait, options) {
		var lastArgs, lastThis, maxWait, result, timerId, lastCallTime, lastInvokeTime = 0, leading = false, maxing = false, trailing = true;
		if (typeof func != "function") throw new TypeError(FUNC_ERROR_TEXT);
		wait = toNumber(wait) || 0;
		if (isObject(options)) {
			leading = !!options.leading;
			maxing = "maxWait" in options;
			maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
			trailing = "trailing" in options ? !!options.trailing : trailing;
		}
		function invokeFunc(time) {
			var args = lastArgs, thisArg = lastThis;
			lastArgs = lastThis = void 0;
			lastInvokeTime = time;
			result = func.apply(thisArg, args);
			return result;
		}
		function leadingEdge(time) {
			lastInvokeTime = time;
			timerId = setTimeout(timerExpired, wait);
			return leading ? invokeFunc(time) : result;
		}
		function remainingWait(time) {
			var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime, timeWaiting = wait - timeSinceLastCall;
			return maxing ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting;
		}
		function shouldInvoke(time) {
			var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime;
			return lastCallTime === void 0 || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
		}
		function timerExpired() {
			var time = now();
			if (shouldInvoke(time)) return trailingEdge(time);
			timerId = setTimeout(timerExpired, remainingWait(time));
		}
		function trailingEdge(time) {
			timerId = void 0;
			if (trailing && lastArgs) return invokeFunc(time);
			lastArgs = lastThis = void 0;
			return result;
		}
		function cancel() {
			if (timerId !== void 0) clearTimeout(timerId);
			lastInvokeTime = 0;
			lastArgs = lastCallTime = lastThis = timerId = void 0;
		}
		function flush() {
			return timerId === void 0 ? result : trailingEdge(now());
		}
		function debounced() {
			var time = now(), isInvoking = shouldInvoke(time);
			lastArgs = arguments;
			lastThis = this;
			lastCallTime = time;
			if (isInvoking) {
				if (timerId === void 0) return leadingEdge(lastCallTime);
				if (maxing) {
					clearTimeout(timerId);
					timerId = setTimeout(timerExpired, wait);
					return invokeFunc(lastCallTime);
				}
			}
			if (timerId === void 0) timerId = setTimeout(timerExpired, wait);
			return result;
		}
		debounced.cancel = cancel;
		debounced.flush = flush;
		return debounced;
	}
	module.exports = debounce;
}));
var import_debounce = /* @__PURE__ */ __toESM(require_debounce());
function useDebounce() {
	const debounceCache = ref(/* @__PURE__ */ new WeakMap());
	const debounce$1 = (fn, options) => {
		const { trailing, debounceTime } = options;
		let debouncedFn = debounceCache.value.get(fn);
		if (debouncedFn === void 0) {
			debouncedFn = (0, import_debounce.default)(async (...args) => {
				return fn(...args);
			}, debounceTime, trailing ? { trailing } : { leading: true });
			debounceCache.value.set(fn, debouncedFn);
		}
		return debouncedFn;
	};
	const callDebounced = (fn, options, ...inputParameters) => {
		return debounce$1(fn, options)(...inputParameters);
	};
	return {
		debounce: debounce$1,
		callDebounced
	};
}
export { require_debounce as n, require_toNumber as r, useDebounce as t };
