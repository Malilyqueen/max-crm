const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/MainSidebar-fP7bVKd-.js","assets/_plugin-vue_export-helper-BwBpWJRZ.js","assets/src-Cl0xZtCE.js","assets/preload-helper-CR0ecmWK.js","assets/icon-C8yfF1LY.js","assets/vue.runtime.esm-bundler-DDuXT-9r.js","assets/chunk-6z4oVpB-.js","assets/truncate-Dc79aML5.js","assets/_MapCache-BGBKpT5S.js","assets/sanitize-html-BuXr7o4T.js","assets/empty-BuGRxzl4.js","assets/path-browserify-DsmB_HMK.js","assets/en-BYTsM8fR.js","assets/src-C5a_PFvg.css","assets/nodeCreator.store-DDUlc1Wi.js","assets/constants-B1JYxPAR.js","assets/merge-Db6rb1_m.js","assets/useTelemetry-BxbCYDca.js","assets/dateformat-D7TIhVd4.js","assets/useDebounce-BRhQZVIC.js","assets/useExternalHooks-ChElZw8W.js","assets/templates.store-pF0jvUy0.js","assets/cloudPlan.store-x1IpiElw.js","assets/nodeIcon-CyGsA5TL.js","assets/useToast-CKD06lpn.js","assets/sortByProperty-CUhVU03p.js","assets/versions.store-DyddKRXT.js","assets/MainSidebarUserArea-DZmO7pT1.js","assets/MainSidebarUserArea-yJKeCkOz.css","assets/useBugReporting-C4eU8DLn.js","assets/usePageRedirectionHelper-Cn-LYQLi.js","assets/useKeybindings-fJZrJyDB.js","assets/personalizedTemplatesV3.store-CJ9Bfy5u.js","assets/constants-DlQs6Cav.js","assets/sourceControl.eventBus-B10rpVhp.js","assets/MainSidebar-BqoiqeXY.css","assets/DataTableView-D2eeWDUi.js","assets/useMessage-CVZHrsoz.js","assets/overlay-DeoWJ8oB.js","assets/orderBy-CanHuORU.js","assets/TimeAgo-FvYQex-v.js","assets/smartDecimal-BitNC0jz.js","assets/ProjectIcon-Doey-RQc.js","assets/ProjectIcon-DT95ZcDW.css","assets/EnterpriseEdition.ee-B_ZSY4rl.js","assets/ResourcesListLayout-BYno1UYD.js","assets/PageViewLayout-CCwb27rd.js","assets/PageViewLayout-BIiboMgG.css","assets/ProjectSharing-CRwSdefc.js","assets/ProjectSharing-DsD3YT5P.css","assets/useProjectPages-DrIHs-hv.js","assets/ResourcesListLayout-B8d0Asrt.css","assets/ProjectHeader-BRHPT2Gf.js","assets/readyToRunWorkflowsV2.store-6CMdkLg0.js","assets/folders.store-x8KuYpUo.js","assets/ProjectHeader-CY-3wSig.css","assets/DataTableActions-CLoVJ5kV.js","assets/dataTable.store-Bgg7dsRy.js","assets/InsightsSummary-CAapTcha.js","assets/insights.constants-DK2g3nnD.js","assets/insights.utils-7zZgNSKk.js","assets/InsightsSummary-BazqPYQ0.css","assets/insights.store-LOsCbJQU.js","assets/DataTableView-ByKnlVtU.css","assets/DataTableDetailsView-B8wQLLu_.js","assets/date-picker-YLC0sjSf.js","assets/SelectedItemsInfo-BO9w2ntq.js","assets/SelectedItemsInfo-DDbNnY7M.css","assets/useClipboard-BPg-srt1.js","assets/ProjectBreadcrumb-CmmsF90D.js","assets/ProjectBreadcrumb-CAEDvzuN.css","assets/DataTableDetailsView-CxS46D7a.css","assets/AddDataTableModal-i8GQtKYX.js","assets/dialog-B1U4ND70.js","assets/Modal-B8k7lYVM.js","assets/Modal-C6HnfA6j.css","assets/AddDataTableModal-BzS5Yqag.css","assets/InsightsDashboard-DgPTPhXD.js","assets/InsightsDashboard-CXRybzGm.css","assets/SettingsMCPView-B9w3XrA9.js","assets/useCanvasOperations-BxV5Dc21.js","assets/usePinnedData-_-i0LUdd.js","assets/executions.store-DmR1JjSC.js","assets/focusPanel.store-Pqc2v-Ms.js","assets/sso.store-BSJgAn6v.js","assets/npsSurvey.store-DTTUiGq9.js","assets/roles.store-D2mgfxDv.js","assets/NodeIcon-Bbl9Jpsi.js","assets/NodeIcon-C-Ise6x6.css","assets/useMcp-ClSG_eXg.js","assets/mcp.store-Cwt_hzwD.js","assets/useRecentResources-D_WnXWIZ.js","assets/SettingsMCPView-BBO_ZyBU.css","assets/ChatSidebar-CXnF23Sm.js","assets/ModalDrawer-K2QDXW8H.js","assets/ModalDrawer-B-12esvU.css","assets/retry-sDkwzrPY.js","assets/useChatHubSidebarState-CTFhoZRQ.js","assets/CredentialIcon-BmzfYSyO.js","assets/CredentialIcon-bZrcXcyJ.css","assets/ChatSidebar-DGlWPwKB.css","assets/ChatView-BOWzOn2x.js","assets/VueMarkdown-70GnkI0W.js","assets/ChatView-tcBlz_g5.css","assets/WorkflowsView-CUeNwQmg.js","assets/usage.store-DXgdlM1s.js","assets/Draggable-BSa80qci.js","assets/Draggable-DfBtatxg.css","assets/TagsDropdown-B9w42ULo.js","assets/TagsDropdown-2j57MEiW.css","assets/WorkflowActivator-FQDQyW1o.js","assets/useWorkflowActivate-B2RbrKj9.js","assets/useWorkflowSaving-DOwP3C1n.js","assets/WorkflowActivator-BNp0duVE.css","assets/WorkflowTagsDropdown-C4m2b8q6.js","assets/readyToRunWorkflows.store-CjgkGuJy.js","assets/ProjectCardBadge-SSY0HK9w.js","assets/ProjectCardBadge-B_wj_mAB.css","assets/EmptySharedSectionActionBox-32M48kPX.js","assets/WorkflowsView-2XTsT7zB.css","assets/CredentialsView-VSMpVIfN.js","assets/pickBy-DoRblpyg.js","assets/externalSecrets.ee.store-px6HohWF.js","assets/CredentialsView-BDOl2A0w.css","assets/ProjectSettings-1ZQGH61x.js","assets/radio-j4rSUoao.js","assets/ProjectSettings-BQOluc3A.css","assets/ExecutionsView-D4k3uqTy.js","assets/AnimatedSpinner-DRB4A7Dx.js","assets/AnimatedSpinner-ChSRgyeI.css","assets/AnnotationTagsDropdown.ee-DV_Mobmt.js","assets/ExecutionsTime-DQ0lKlTn.js","assets/ExecutionsTime-qhi9xQEs.css","assets/useExecutionHelpers-5AFgT_t7.js","assets/dateFormatter-jkly8a5N.js","assets/ExecutionsView-f-kKRR2k.css","assets/ProjectVariables-BKV1_OBU.js","assets/VariablesUsageBadge-CEu0Fi7I.js","assets/VariablesUsageBadge-CQU1F9NU.css","assets/ProjectVariables-Cw92ZPKE.css","assets/ChangePasswordView-mVWAZ3kL.js","assets/AuthView-BucJoBVs.js","assets/AuthView-Dg9ZkCud.css","assets/ErrorView-DAsa-PS_.js","assets/ErrorView-D2OMvGTk.css","assets/EntityNotFound-CKlXW1IL.js","assets/EntityNotFound-DfstTvbZ.css","assets/EntityUnAuthorised-DB0HgLOM.js","assets/EntityUnAuthorised-C6EIQ1Pq.css","assets/ForgotMyPasswordView-B9XpVVQb.js","assets/MainHeader-Dwzc_Fak.js","assets/useRunWorkflow-D5rKvgfC.js","assets/FileSaver.min-CR_3Le5x.js","assets/usePushConnection-BHaxo8fR.js","assets/schemaPreview.store-BdP1Rtj4.js","assets/assistant.store-D6Fihh2i.js","assets/KeyboardShortcutTooltip-CXKgjDIT.js","assets/KeyboardShortcutTooltip-pRLqnHdh.css","assets/PushConnectionTracker-V3T3vpnB.js","assets/SaveButton-C2Gkwcd6.js","assets/SaveButton-Dc01Y2MA.css","assets/useBeforeUnload-BDgq2LXA.js","assets/useWorkflowsCache-4ARgZCpO.js","assets/MainHeader-QMv9Ba5g.css","assets/LogsPanel-mv855bJ4.js","assets/isEmpty-CRyMT0C3.js","assets/uniqBy-C2OAfwKy.js","assets/NDVEmptyState-CFiiknri.js","assets/NDVEmptyState-Hm1vFJ4i.css","assets/vue-json-pretty-DiH9ZFoW.js","assets/vue-B27A1Apg.js","assets/chatPanel.store-Dt9ypdvG.js","assets/RunDataHtml-DOQ0pkg3.js","assets/RunDataHtml-Bu3RZcuV.css","assets/isEmpty-B-mcFJ04.css","assets/core-CGHB7oTc.js","assets/core-BfCr8skN.js","assets/xml-CcxXd9zY.js","assets/LogsPanel-BSFP3TRR.js","assets/useLogsTreeExpand-DbXAJb89.js","assets/useLogsTreeExpand-BT6XJR8J.css","assets/LogsPanel-K1M_gOCT.css","assets/DemoFooter-CWdsp2am.js","assets/NodeView-BjGTiM1O.js","assets/ParameterInputList-CtoyrDjR.js","assets/exports-RJH1xso1.js","assets/VirtualSchema-CC3sIZuJ.js","assets/useTelemetryContext-55FklHQh.js","assets/useTelemetryContext-BpnKRIT7.css","assets/TextWithHighlights-B8mQwCVK.js","assets/TextWithHighlights-BgbTzzK2.css","assets/nodeTransforms-CJd0FLm1.js","assets/VirtualSchema-CSh2c6Ec.css","assets/ParameterInputList-aGPYvt18.css","assets/Canvas-Td0SIV0U.js","assets/NodeSettings-BKd6Pbpi.js","assets/col-b1w4xo57.js","assets/useActions-CYE2yaOW.js","assets/CommunityNodeUpdateInfo-Bk-rYnfU.js","assets/semver-C8_oAvi8.js","assets/CommunityNodeUpdateInfo-kPDiipF5.css","assets/NodeSettings-B50suDD9.css","assets/Canvas-Bn6gWZ4a.css","assets/useExecutionData-B4rCxtFJ.js","assets/useExecutionDebugging-B-lTq5hU.js","assets/NodeView-KpAB56Z3.css","assets/WorkflowExecutionsView-FCkyyfKq.js","assets/WorkflowExecutionsInfoAccordion-JHl30LoQ.js","assets/WorkflowExecutionsInfoAccordion-CEOvJ-SX.css","assets/WorkflowExecutionsView-9RB5OO5c.css","assets/WorkflowExecutionsLandingPage-CcJ9U18X.js","assets/WorkflowExecutionsLandingPage-DMldlKod.css","assets/WorkflowExecutionsPreview-BYWh0GBH.js","assets/WorkflowPreview-CQzIuWsu.js","assets/WorkflowPreview-Bt03akXc.css","assets/WorkflowExecutionsPreview-BkXT82z5.css","assets/SettingsView-BdM6C-Pa.js","assets/SettingsView-6sirGv9l.css","assets/SettingsLdapView-DOse-1bN.js","assets/table-B9oFv7WW.js","assets/SettingsLdapView-KgMO_1GA.css","assets/SettingsPersonalView-DWGs5wge.js","assets/auth.eventBus-CUpasXbj.js","assets/SettingsPersonalView-D6LtKnaF.css","assets/SettingsUsersView-8_Y7zQMz.js","assets/SettingsUsersView-CfJcVjkl.css","assets/SettingsCommunityNodesView-3swLF8oI.js","assets/SettingsCommunityNodesView-m7kLUpJK.css","assets/SettingsApiView-DHCr1LrA.js","assets/apiKeys.store-CHTKph22.js","assets/SettingsApiView-Dtl_N9mK.css","assets/SettingsLogStreamingView-BVSln3cm.js","assets/logStreaming.store-DUt3HvR4.js","assets/SettingsLogStreamingView-xo-rTSA0.css","assets/SetupView-DXmGJi1C.js","assets/SigninView-Di3btl9A.js","assets/SigninView-BQgsTN8o.css","assets/SignupView-BM4OXX-x.js","assets/TemplatesCollectionView-DdMjHvDQ.js","assets/TemplatesView-FCDPW2Yq.js","assets/TemplatesView-BgdyYmrL.css","assets/TemplateList-C7Gtb7cW.js","assets/TemplateList-CNUtq0N7.css","assets/TemplateDetails-DNyPiFTw.js","assets/TemplateDetails-DfyKyMyy.css","assets/templateActions-CAMtj2SG.js","assets/templateTransforms-ClSZtrME.js","assets/TemplatesCollectionView-klb8FT9y.css","assets/TemplatesWorkflowView-B8_w-yL7.js","assets/TemplatesWorkflowView-CBjRBbmw.css","assets/SetupWorkflowFromTemplateView-B77sQQ6O.js","assets/SetupTemplateFormStep-vegHZ86T.js","assets/SetupTemplateFormStep-She0GnTz.css","assets/SetupWorkflowFromTemplateView-CU2iGJTa.css","assets/TemplatesSearchView-BtUlSZXh.js","assets/TemplatesSearchView-BfT0LMil.css","assets/VariablesView-CnlNqt-I.js","assets/VariablesView-PPP4k5c3.css","assets/SettingsUsageAndPlan-BcyB9_cH.js","assets/SettingsUsageAndPlan-pptm91gP.css","assets/SettingsSso-LCXnYtLn.js","assets/CopyInput-DQBVF_BG.js","assets/CopyInput-CwgZTYF4.css","assets/SettingsSso-w7Iz4Luy.css","assets/SignoutView-WKs5gvAj.js","assets/SamlOnboarding-EExl-EAp.js","assets/SettingsSourceControl-BmJrrMbt.js","assets/SettingsSourceControl-DEs9MNB6.css","assets/SettingsExternalSecrets-Czm8izQh.js","assets/ExternalSecretsProviderConnectionSwitch.ee-ps4K4bOK.js","assets/ExternalSecretsProviderConnectionSwitch-Df3YK0La.css","assets/SettingsExternalSecrets-CaiOf7cD.css","assets/SettingsProvisioningView-Bd7_e49M.js","assets/SettingsProvisioningView-Dhfda99J.css","assets/WorkerView-a-85mW7s.js","assets/chart-inxSB4fp.js","assets/dist-BCqe3G7U.js","assets/WorkerView-4m_NaoAx.css","assets/WorkflowHistory-BDm1H5BL.js","assets/WorkflowHistory-BmerBiKz.css","assets/WorkflowOnboardingView-BZP0l2UH.js","assets/EvaluationsView-Dr4m1cGH.js","assets/evaluation.constants-BLT71nuf.js","assets/evaluation-CGxdCHrN.css","assets/EvaluationsView-DsfXDJ-U.css","assets/TestRunDetailView-CEE1M2hn.js","assets/TestRunDetailView-DkQcfFP4.css","assets/EvaluationsRootView-CcJipqTv.js","assets/EvaluationsRootView-BVNlhh2l.css","assets/PrebuiltAgentTemplatesView-C6IbTjn9.js","assets/PrebuiltAgentTemplatesView-jF7HvWnL.css","assets/ProjectRolesView-JblQF33a.js","assets/ProjectRolesView-Bpk_JP1z.css","assets/ProjectRoleView-Dz82Hr5N.js","assets/ProjectRoleView-Cewy9KCA.css"])))=>i.map(i=>d[i]);
import { C as computed, Gt as unref, L as h, M as createVNode, P as defineComponent, Sn as toDisplayString, T as createBlock, bt as withCtx, et as openBlock, j as createTextVNode, ot as resolveComponent } from "./vue.runtime.esm-bundler-DDuXT-9r.js";
import { _t as I18nT, gt as useI18n } from "./_MapCache-BGBKpT5S.js";
import { t as __vitePreload } from "./preload-helper-CR0ecmWK.js";
import { _ as isNavigationFailure, g as createWebHistory, h as createRouter, m as RouterView } from "./truncate-Dc79aML5.js";
import { $n as isAuthenticated, An as useProjectsStore, Di as tryToParseNumber, Js as useRootStore, Li as useUIStore, Qn as isDefaultUser, Xn as isGuest, Zn as isEnterpriseFeatureEnabled, er as shouldEnableMfa, i as usePostHog, ir as useUsersStore, jn as useSourceControlStore, nr as useRBACStore, rc as MfaRequiredError, rr as hasRole, rt as useNodeTypesStore, t as useTelemetry, tr as hasScope, zi as register, zo as useSettingsStore } from "./useTelemetry-BxbCYDca.js";
import { t as useToast } from "./useToast-CKD06lpn.js";
import { Fs as EnterpriseEditionFeature, Kn as DATA_TABLE_VIEW, Ln as ADD_DATA_TABLE_MODAL_KEY, Vn as DATA_TABLE_DETAILS, co as VIEWS, hr as getResourcePermissions, ir as PROJECT_DATA_TABLES, oo as EDITABLE_CANVAS_VIEWS } from "./constants-B1JYxPAR.js";
import { t as useExternalHooks } from "./useExternalHooks-ChElZw8W.js";
import { t as useNpsSurveyStore } from "./npsSurvey.store-DTTUiGq9.js";
import { t as useCloudPlanStore } from "./cloudPlan.store-x1IpiElw.js";
import { t as useTemplatesStore } from "./templates.store-pF0jvUy0.js";
import { _ as useCalloutHelpers } from "./nodeCreator.store-DDUlc1Wi.js";
import { t as useVersionsStore } from "./versions.store-DyddKRXT.js";
import { t as useDataTableStore } from "./dataTable.store-Bgg7dsRy.js";
import { t as useRolesStore } from "./roles.store-D2mgfxDv.js";
import { n as useSSOStore } from "./sso.store-BSJgAn6v.js";
import { t as useInsightsStore } from "./insights.store-LOsCbJQU.js";
import { i as MCP_SETTINGS_VIEW } from "./useMcp-ClSG_eXg.js";
import { r as CHAT_VIEW, t as CHAT_CONVERSATION_VIEW } from "./constants-DlQs6Cav.js";
import { t as useRecentResources } from "./useRecentResources-D_WnXWIZ.js";
const authenticatedMiddleware = async (to, _from, next, options) => {
	const url = new URL(window.location.href);
	url.searchParams.delete("redirect");
	const redirect = to.query.redirect ?? encodeURIComponent(`${url.pathname}${url.search}`);
	if (!isAuthenticated(options)) return next({
		name: VIEWS.SIGNIN,
		query: { redirect }
	});
	if (shouldEnableMfa()) {
		if (to.name !== VIEWS.PERSONAL_SETTINGS) return next({
			name: VIEWS.PERSONAL_SETTINGS,
			query: { redirect }
		});
		return;
	}
};
const enterpriseMiddleware = async (_to, _from, next, options) => {
	if (!isEnterpriseFeatureEnabled(options)) return next({ name: VIEWS.HOMEPAGE });
};
const guestMiddleware = async (to, _from, next) => {
	if (!isGuest()) {
		const redirect = to.query.redirect ?? "";
		if (redirect.startsWith("/")) return next(redirect);
		try {
			if (new URL(redirect).origin === window.location.origin) return next(redirect);
		} catch {}
		return next({ name: VIEWS.HOMEPAGE });
	}
};
function inferProjectIdFromRoute(to) {
	const routeParts = to.path.split("/");
	const projectsIndex = routeParts.indexOf("projects");
	return routeParts[projectsIndex !== -1 ? projectsIndex + 1 : -1];
}
function inferResourceTypeFromRoute(to) {
	const routeParts = to.path.split("/");
	const routeMap = {
		workflow: "workflows",
		credential: "credentials",
		user: "users",
		variable: "variables",
		sourceControl: "source-control",
		externalSecret: "external-secrets"
	};
	const isResource = (key) => routeParts.includes(routeMap[key]);
	for (const resource of Object.keys(routeMap)) if (isResource(resource)) return resource;
}
function inferResourceIdFromRoute(to) {
	return to.params.id ?? to.params.name;
}
const rbacMiddleware = async (to, _from, next, { scope, options }) => {
	const projectId = inferProjectIdFromRoute(to);
	const resourceType = inferResourceTypeFromRoute(to);
	if (!hasScope({
		scope,
		projectId,
		resourceType,
		resourceId: resourceType ? inferResourceIdFromRoute(to) : void 0,
		options
	})) return next({ name: VIEWS.HOMEPAGE });
};
const roleMiddleware = async (_to, _from, next, checkRoles) => {
	if (!hasRole(checkRoles)) return next({ name: VIEWS.HOMEPAGE });
};
const customMiddleware = async (to, from, next, isValid) => {
	if (!isValid({
		to,
		from,
		next
	})) return next({ name: VIEWS.HOMEPAGE });
};
const defaultUserMiddleware = async (_to, _from, next) => {
	if (!isDefaultUser()) return next({ name: VIEWS.HOMEPAGE });
};
const middleware = {
	authenticated: authenticatedMiddleware,
	custom: customMiddleware,
	defaultUser: defaultUserMiddleware,
	enterprise: enterpriseMiddleware,
	guest: guestMiddleware,
	rbac: rbacMiddleware,
	role: roleMiddleware
};
var SourceControlInitializationErrorMessage_default = /* @__PURE__ */ defineComponent({
	__name: "SourceControlInitializationErrorMessage",
	setup(__props) {
		const i18n$2 = useI18n();
		return (_ctx, _cache) => {
			const _component_RouterLink = resolveComponent("RouterLink");
			return openBlock(), createBlock(unref(I18nT), {
				keypath: "settings.sourceControl.connection.error.message",
				tag: "div",
				scope: "global"
			}, {
				link: withCtx(() => [createVNode(_component_RouterLink, { to: { name: unref(VIEWS).SOURCE_CONTROL } }, {
					default: withCtx(() => [createTextVNode(toDisplayString(unref(i18n$2).baseText("settings.sourceControl.connection.error.link")), 1)]),
					_: 1
				}, 8, ["to"])]),
				_: 1
			});
		};
	}
});
var i18n$1 = useI18n();
var MainSidebar$3 = async () => await __vitePreload(() => import("./MainSidebar-fP7bVKd-.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35]));
var DataTableView = async () => await __vitePreload(() => import("./DataTableView-D2eeWDUi.js"), __vite__mapDeps([36,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,22,55,56,57,58,59,60,61,62,63]));
var DataTableDetailsView = async () => await __vitePreload(() => import("./DataTableDetailsView-B8wQLLu_.js"), __vite__mapDeps([64,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,65,37,24,20,38,39,42,43,66,67,68,56,57,69,70,71]));
const DataTableModule = {
	id: "data-table",
	name: "Data Table",
	description: "Manage and store data efficiently with the Data Table module.",
	icon: "database",
	modals: [{
		key: ADD_DATA_TABLE_MODAL_KEY,
		component: async () => await __vitePreload(() => import("./AddDataTableModal-i8GQtKYX.js"), __vite__mapDeps([72,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,73,38,24,20,74,75,57,76])),
		initialState: { open: false }
	}],
	routes: [
		{
			name: DATA_TABLE_VIEW,
			path: "/home/datatables",
			components: {
				default: DataTableView,
				sidebar: MainSidebar$3
			},
			meta: { middleware: ["authenticated", "custom"] }
		},
		{
			name: PROJECT_DATA_TABLES,
			path: "datatables/:new(new)?",
			props: true,
			components: {
				default: DataTableView,
				sidebar: MainSidebar$3
			},
			meta: {
				projectRoute: true,
				middleware: ["authenticated", "custom"]
			}
		},
		{
			name: DATA_TABLE_DETAILS,
			path: "datatables/:id",
			props: true,
			components: {
				default: DataTableDetailsView,
				sidebar: MainSidebar$3
			},
			meta: {
				projectRoute: true,
				middleware: ["authenticated", "custom"]
			}
		}
	],
	projectTabs: {
		overview: [{
			label: i18n$1.baseText("dataTable.dataTables"),
			value: DATA_TABLE_VIEW,
			tag: i18n$1.baseText("generic.betaProper"),
			to: { name: DATA_TABLE_VIEW }
		}],
		project: [{
			label: i18n$1.baseText("dataTable.dataTables"),
			value: PROJECT_DATA_TABLES,
			tag: i18n$1.baseText("generic.betaProper"),
			dynamicRoute: {
				name: PROJECT_DATA_TABLES,
				includeProjectId: true
			}
		}]
	},
	resources: [{
		key: "dataTable",
		displayName: "Data Table"
	}]
};
var resources = /* @__PURE__ */ new Map();
function registerResource(metadata) {
	resources.set(metadata.key, metadata);
}
var MainSidebar$2 = async () => await __vitePreload(() => import("./MainSidebar-fP7bVKd-.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35]));
var InsightsDashboard = async () => await __vitePreload(() => import("./InsightsDashboard-DgPTPhXD.js"), __vite__mapDeps([77,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,73,38,24,20,39,41,42,43,26,30,22,48,49,58,59,60,61,62,78]));
const InsightsModule = {
	id: "insights",
	name: "Insights",
	description: "Provides insights and analytics features for projects.",
	icon: "chart-column-decreasing",
	routes: [{
		path: "/insights",
		beforeEnter() {
			return useInsightsStore().isInsightsEnabled || { name: VIEWS.NOT_FOUND };
		},
		components: {
			default: RouterView,
			sidebar: MainSidebar$2
		},
		meta: {
			middleware: ["authenticated", "rbac"],
			middlewareOptions: { rbac: { scope: ["insights:list"] } }
		},
		children: [{
			path: ":insightType?",
			name: VIEWS.INSIGHTS,
			beforeEnter(to) {
				if (to.params.insightType) return true;
				return Object.assign(to, { params: {
					...to.params,
					insightType: "total"
				} });
			},
			component: InsightsDashboard,
			props: true
		}]
	}]
};
var i18n = useI18n();
var SettingsMCPView = async () => await __vitePreload(() => import("./SettingsMCPView-B9w3XrA9.js"), __vite__mapDeps([79,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,80,68,81,54,82,83,42,43,84,85,86,26,87,88,33,89,90,57,62,60,59,91,92]));
const MCPModule = {
	id: "mcp",
	name: "MCP Access",
	description: "Access your n8n instance through MCP clients",
	icon: "mcp",
	routes: [{
		path: "mcp",
		name: MCP_SETTINGS_VIEW,
		components: { settingsView: SettingsMCPView },
		meta: {
			middleware: ["authenticated", "custom"],
			telemetry: { pageCategory: "settings" }
		}
	}],
	settingsPages: [{
		id: "settings-mcp",
		icon: "mcp",
		label: i18n.baseText("settings.mcp"),
		position: "top",
		route: { to: { name: MCP_SETTINGS_VIEW } }
	}]
};
var ChatSidebar = async () => await __vitePreload(() => import("./ChatSidebar-CXnF23Sm.js"), __vite__mapDeps([93,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,73,38,94,95,37,24,20,96,27,28,97,33,98,99,100]));
var ChatView = async () => await __vitePreload(() => import("./ChatView-BOWzOn2x.js"), __vite__mapDeps([101,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,73,38,24,20,102,96,74,75,68,97,33,98,99,103]));
var modules = [
	InsightsModule,
	DataTableModule,
	MCPModule,
	{
		id: "chat-hub",
		name: "Chat",
		description: "Interact with various LLM models or your n8n AI agents.",
		icon: "chat",
		modals: [],
		routes: [{
			name: CHAT_VIEW,
			path: "/home/chat",
			components: {
				default: ChatView,
				sidebar: ChatSidebar
			},
			meta: { middleware: ["authenticated", "custom"] }
		}, {
			name: CHAT_CONVERSATION_VIEW,
			path: "/home/chat/:id",
			components: {
				default: ChatView,
				sidebar: ChatSidebar
			},
			meta: { middleware: ["authenticated", "custom"] }
		}],
		projectTabs: {
			overview: [],
			project: []
		},
		resources: [{
			key: "chat",
			displayName: "Chat"
		}]
	}
];
const registerModuleResources = () => {
	modules.forEach((module) => {
		module.resources?.forEach((resource) => {
			registerResource(resource);
		});
	});
};
const registerModuleProjectTabs = () => {
	const uiStore = useUIStore();
	modules.forEach((module) => {
		if (module.projectTabs) {
			if (module.projectTabs.overview) uiStore.registerCustomTabs("overview", module.id, module.projectTabs.overview);
			if (module.projectTabs.project) uiStore.registerCustomTabs("project", module.id, module.projectTabs.project);
			if (module.projectTabs.shared) uiStore.registerCustomTabs("shared", module.id, module.projectTabs.shared);
		}
	});
};
const registerModuleSettingsPages = () => {
	const uiStore = useUIStore();
	modules.forEach((module) => {
		if (module.settingsPages && module.settingsPages.length > 0) uiStore.registerSettingsPages(module.id, module.settingsPages);
	});
};
var checkModuleAvailability = (options) => {
	if (!options?.to?.meta?.moduleName || typeof options.to.meta.moduleName !== "string") return true;
	return useSettingsStore().isModuleActive(options.to.meta.moduleName);
};
const registerModuleModals = () => {
	modules.forEach((module) => {
		module.modals?.forEach((modalDef) => {
			register(modalDef);
		});
	});
	useUIStore().initializeModalsFromRegistry();
};
const registerModuleRoutes = (router$1) => {
	modules.forEach((module) => {
		module.routes?.forEach((route) => {
			const enhancedRoute = {
				...route,
				meta: {
					...route.meta,
					moduleName: module.id,
					...route.meta?.middleware?.includes("custom") && { middlewareOptions: {
						...route.meta?.middlewareOptions,
						custom: checkModuleAvailability
					} }
				}
			};
			if (route.meta?.projectRoute) router$1.addRoute(VIEWS.PROJECT_DETAILS, enhancedRoute);
			else if (route.meta?.telemetry && route.meta.telemetry.pageCategory === "settings") router$1.addRoute(VIEWS.SETTINGS, enhancedRoute);
			else router$1.addRoute(enhancedRoute);
		});
	});
};
const state = { initialized: false };
var authenticatedFeaturesInitialized = false;
async function initializeCore() {
	if (state.initialized) return;
	const settingsStore = useSettingsStore();
	const usersStore = useUsersStore();
	const versionsStore = useVersionsStore();
	const ssoStore = useSSOStore();
	const uiStore = useUIStore();
	const toast = useToast();
	const i18n$2 = useI18n();
	registerAuthenticationHooks();
	try {
		await settingsStore.initialize();
	} catch (error) {
		toast.showToast({
			title: i18n$2.baseText("startupError"),
			message: i18n$2.baseText("startupError.message"),
			type: "error",
			duration: 0
		});
	}
	ssoStore.initialize({
		authenticationMethod: settingsStore.userManagement.authenticationMethod,
		config: settingsStore.settings.sso,
		features: {
			saml: settingsStore.isEnterpriseFeatureEnabled[EnterpriseEditionFeature.Saml],
			ldap: settingsStore.isEnterpriseFeatureEnabled[EnterpriseEditionFeature.Ldap],
			oidc: settingsStore.isEnterpriseFeatureEnabled[EnterpriseEditionFeature.Oidc]
		}
	});
	const banners = [];
	if (settingsStore.isEnterpriseFeatureEnabled.showNonProdBanner) banners.push("NON_PRODUCTION_LICENSE");
	if (!(settingsStore.settings.banners?.dismissed || []).includes("V1") && settingsStore.settings.versionCli.startsWith("1.")) banners.push("V1");
	uiStore.initialize({ banners });
	versionsStore.initialize(settingsStore.settings.versionNotifications);
	useExternalHooks().run("app.mount");
	if (!settingsStore.isPreviewMode) await usersStore.initialize({ quota: settingsStore.userManagement.quota });
	state.initialized = true;
}
async function initializeAuthenticatedFeatures(initialized = authenticatedFeaturesInitialized, routeName) {
	if (initialized) return;
	if (!useUsersStore().currentUser) return;
	const i18n$2 = useI18n();
	const toast = useToast();
	const sourceControlStore = useSourceControlStore();
	const settingsStore = useSettingsStore();
	const rootStore = useRootStore();
	const nodeTypesStore = useNodeTypesStore();
	const cloudPlanStore = useCloudPlanStore();
	const projectsStore = useProjectsStore();
	const rolesStore = useRolesStore();
	const insightsStore = useInsightsStore();
	const uiStore = useUIStore();
	const versionsStore = useVersionsStore();
	const dataTableStore = useDataTableStore();
	if (sourceControlStore.isEnterpriseSourceControlEnabled) try {
		await sourceControlStore.getPreferences();
	} catch (e) {
		toast.showMessage({
			title: i18n$2.baseText("settings.sourceControl.connection.error"),
			message: h(SourceControlInitializationErrorMessage_default),
			type: "error",
			duration: 0
		});
		console.error("Failed to initialize source control store", e);
	}
	if (rootStore.defaultLocale !== "en") await nodeTypesStore.getNodeTranslationHeaders();
	if (settingsStore.isCloudDeployment) cloudPlanStore.initialize().then(() => {
		if (cloudPlanStore.userIsTrialing) if (cloudPlanStore.trialExpired) uiStore.pushBannerToStack("TRIAL_OVER");
		else uiStore.pushBannerToStack("TRIAL");
		else if (cloudPlanStore.currentUserCloudInfo?.confirmed === false) uiStore.pushBannerToStack("EMAIL_CONFIRMATION");
	}).catch((error) => {
		console.error("Failed to initialize cloud plan store:", error);
	});
	if (settingsStore.isDataTableFeatureEnabled) dataTableStore.fetchDataTableSize().then(({ quotaStatus }) => {
		if (quotaStatus === "error") uiStore.pushBannerToStack("DATA_TABLE_STORAGE_LIMIT_ERROR");
		else if (quotaStatus === "warn") uiStore.pushBannerToStack("DATA_TABLE_STORAGE_LIMIT_WARNING");
	}).catch((error) => {
		console.error("Failed to fetch data table limits:", error);
	});
	if (insightsStore.isSummaryEnabled) insightsStore.weeklySummary.execute();
	if (!settingsStore.isPreviewMode && routeName !== VIEWS.DEMO) versionsStore.checkForNewVersions();
	await Promise.all([
		projectsStore.getMyProjects(),
		projectsStore.getPersonalProject(),
		projectsStore.getProjectsCount(),
		rolesStore.fetchRoles()
	]);
	registerModuleResources();
	registerModuleProjectTabs();
	registerModuleModals();
	registerModuleSettingsPages();
	authenticatedFeaturesInitialized = true;
}
function registerAuthenticationHooks() {
	const rootStore = useRootStore();
	const usersStore = useUsersStore();
	const cloudPlanStore = useCloudPlanStore();
	const postHogStore = usePostHog();
	const uiStore = useUIStore();
	const npsSurveyStore = useNpsSurveyStore();
	const telemetry = useTelemetry();
	const RBACStore = useRBACStore();
	const settingsStore = useSettingsStore();
	usersStore.registerLoginHook(async (user) => {
		await settingsStore.getSettings();
		RBACStore.setGlobalScopes(user.globalScopes ?? []);
		telemetry.identify(rootStore.instanceId, user.id, rootStore.versionCli);
		postHogStore.init(user.featureFlags);
		npsSurveyStore.setupNpsSurveyOnLogin(user.id, user.settings);
		settingsStore.getModuleSettings();
	});
	usersStore.registerLogoutHook(() => {
		uiStore.clearBannerStack();
		npsSurveyStore.resetNpsSurveyOnLogOut();
		postHogStore.reset();
		cloudPlanStore.reset();
		telemetry.reset();
		RBACStore.setGlobalScopes([]);
	});
}
var MainSidebar$1 = async () => await __vitePreload(() => import("./MainSidebar-fP7bVKd-.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35]));
var WorkflowsView = async () => await __vitePreload(() => import("./WorkflowsView-CUeNwQmg.js"), __vite__mapDeps([104,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,37,24,38,39,40,41,42,43,85,105,106,107,44,87,88,108,109,110,111,112,83,69,70,54,113,114,45,46,47,48,49,50,51,115,32,52,53,55,89,90,116,117,118,58,59,60,61,62,119]));
var CredentialsView = async () => await __vitePreload(() => import("./CredentialsView-VSMpVIfN.js"), __vite__mapDeps([120,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,39,121,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,22,55,116,117,118,98,99,58,59,60,61,62,122,123]));
var ProjectSettings = async () => await __vitePreload(() => import("./ProjectSettings-1ZQGH61x.js"), __vite__mapDeps([124,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,73,38,24,20,125,39,42,43,86,26,30,22,52,53,50,54,55,48,49,126]));
var ExecutionsView = async () => await __vitePreload(() => import("./ExecutionsView-D4k3uqTy.js"), __vite__mapDeps([127,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,65,37,24,20,38,41,42,43,26,128,129,130,108,109,114,66,67,30,22,52,53,50,54,55,131,132,133,134,82,58,59,60,61,62,135]));
var ProjectVariables = async () => await __vitePreload(() => import("./ProjectVariables-BKV1_OBU.js"), __vite__mapDeps([136,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,39,121,41,42,43,26,44,45,46,47,48,49,50,51,68,30,22,52,53,54,55,58,59,60,61,62,137,138,139]));
var checkProjectAvailability = (to) => {
	if (!to?.params.projectId) return true;
	return !!useProjectsStore().myProjects.find((p) => to?.params.projectId === p.id);
};
var commonChildRoutes = [
	{
		path: "workflows",
		components: {
			default: WorkflowsView,
			sidebar: MainSidebar$1
		},
		meta: {
			middleware: ["authenticated", "custom"],
			middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
		}
	},
	{
		path: "credentials/:credentialId?",
		props: true,
		components: {
			default: CredentialsView,
			sidebar: MainSidebar$1
		},
		meta: {
			middleware: ["authenticated", "custom"],
			middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
		}
	},
	{
		path: "executions",
		components: {
			default: ExecutionsView,
			sidebar: MainSidebar$1
		},
		meta: {
			middleware: ["authenticated", "custom"],
			middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
		}
	},
	{
		path: "folders/:folderId?/workflows",
		components: {
			default: WorkflowsView,
			sidebar: MainSidebar$1
		},
		meta: {
			middleware: ["authenticated", "custom"],
			middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
		}
	},
	{
		path: "variables",
		components: {
			default: ProjectVariables,
			sidebar: MainSidebar$1
		},
		meta: {
			middleware: ["authenticated", "custom"],
			middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
		}
	}
];
var commonChildRouteExtensions = {
	home: [
		{ name: VIEWS.WORKFLOWS },
		{ name: VIEWS.CREDENTIALS },
		{ name: VIEWS.EXECUTIONS },
		{ name: VIEWS.FOLDERS },
		{ name: VIEWS.HOME_VARIABLES }
	],
	projects: [
		{ name: VIEWS.PROJECTS_WORKFLOWS },
		{ name: VIEWS.PROJECTS_CREDENTIALS },
		{ name: VIEWS.PROJECTS_EXECUTIONS },
		{ name: VIEWS.PROJECTS_FOLDERS },
		{ name: VIEWS.PROJECTS_VARIABLES }
	]
};
const projectsRoutes = [
	{
		path: "/projects",
		name: VIEWS.PROJECTS,
		meta: { middleware: ["authenticated"] },
		redirect: "/home/workflows",
		children: [{
			name: VIEWS.PROJECT_DETAILS,
			path: ":projectId",
			meta: { middleware: ["authenticated"] },
			redirect: { name: VIEWS.PROJECTS_WORKFLOWS },
			children: commonChildRoutes.map((route, idx) => ({
				...route,
				name: commonChildRouteExtensions.projects[idx].name
			})).concat([{
				path: "settings",
				name: VIEWS.PROJECT_SETTINGS,
				components: {
					default: ProjectSettings,
					sidebar: MainSidebar$1
				},
				meta: {
					middleware: ["authenticated", "custom"],
					middlewareOptions: { custom: (options) => {
						return !!getResourcePermissions(useProjectsStore().myProjects.find((p) => p.id === options?.to.params.projectId)?.scopes).project.update;
					} }
				}
			}])
		}]
	},
	{
		path: "/home",
		name: VIEWS.HOMEPAGE,
		meta: { middleware: ["authenticated"] },
		redirect: "/home/workflows",
		children: commonChildRoutes.map((route, idx) => ({
			...route,
			name: commonChildRouteExtensions.home[idx].name
		}))
	},
	{
		path: "/shared",
		name: VIEWS.SHARED_WITH_ME,
		meta: { middleware: ["authenticated"] },
		redirect: "/shared/workflows",
		children: [{
			path: "workflows",
			name: VIEWS.SHARED_WORKFLOWS,
			components: {
				default: WorkflowsView,
				sidebar: MainSidebar$1
			},
			meta: {
				middleware: ["authenticated", "custom"],
				middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
			}
		}, {
			path: "credentials/:credentialId?",
			props: true,
			name: VIEWS.SHARED_CREDENTIALS,
			components: {
				default: CredentialsView,
				sidebar: MainSidebar$1
			},
			meta: {
				middleware: ["authenticated", "custom"],
				middlewareOptions: { custom: (options) => checkProjectAvailability(options?.to) }
			}
		}]
	},
	{
		path: "/workflows",
		redirect: "/home/workflows"
	},
	{
		path: "/credentials",
		redirect: "/home/credentials"
	},
	{
		path: "/executions",
		redirect: "/home/executions"
	},
	{
		path: "/variables",
		redirect: "/home/variables"
	}
];
const useEnvFeatureFlag = () => {
	const settingsStore = useSettingsStore();
	return { check: computed(() => (flag) => {
		const key = `N8N_ENV_FEAT_${flag}`;
		const settingsProvidedEnvFeatFlag = settingsStore.settings.envFeatureFlags?.[key];
		if (settingsProvidedEnvFeatFlag !== void 0) return settingsProvidedEnvFeatFlag !== "false" && !!settingsProvidedEnvFeatFlag;
		const buildTimeValue = {
			"BASE_URL": "/",
			"DEV": false,
			"LEGACY": false,
			"MODE": "production",
			"PROD": true,
			"SSR": false,
			"VUE_APP_PUBLIC_PATH": "/"
		}[key];
		if (buildTimeValue !== void 0) return buildTimeValue !== "false" && !!buildTimeValue;
		return false;
	}) };
};
var ChangePasswordView = async () => await __vitePreload(() => import("./ChangePasswordView-mVWAZ3kL.js"), __vite__mapDeps([140,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,141,142]));
var ErrorView = async () => await __vitePreload(() => import("./ErrorView-DAsa-PS_.js"), __vite__mapDeps([143,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,144]));
var EntityNotFound = async () => await __vitePreload(() => import("./EntityNotFound-CKlXW1IL.js"), __vite__mapDeps([145,1,2,3,4,5,6,7,8,9,10,11,12,13,146]));
var EntityUnAuthorised = async () => await __vitePreload(() => import("./EntityUnAuthorised-DB0HgLOM.js"), __vite__mapDeps([147,1,2,3,4,5,6,7,8,9,10,11,12,13,148]));
var ForgotMyPasswordView = async () => await __vitePreload(() => import("./ForgotMyPasswordView-B9XpVVQb.js"), __vite__mapDeps([149,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,141,142]));
var MainHeader = async () => await __vitePreload(() => import("./MainHeader-Dwzc_Fak.js"), __vite__mapDeps([150,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,151,24,80,68,81,54,82,83,96,112,37,38,85,152,153,154,155,115,53,50,42,43,26,44,156,157,158,159,160,108,109,110,111,69,70,113,114,161,30,162,89,163]));
var MainSidebar = async () => await __vitePreload(() => import("./MainSidebar-fP7bVKd-.js"), __vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35]));
var LogsPanel = async () => await __vitePreload(() => import("./LogsPanel-mv855bJ4.js"), __vite__mapDeps([164,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,165,151,24,80,68,81,54,82,83,96,112,37,38,85,152,166,167,168,169,170,154,155,171,133,134,122,172,173,174,175,176,177,102,178,179,128,129,87,88,180,156,157,31,181]));
var DemoFooter = async () => await __vitePreload(() => import("./DemoFooter-CWdsp2am.js"), __vite__mapDeps([182,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,165,151,24,80,68,81,54,82,83,96,112,37,38,85,152,166,167,168,169,170,154,155,171,133,134,122,172,173,174,175,176,177,102,178,179,128,129,87,88,180,156,157,31,181]));
var NodeView = async () => await __vitePreload(() => import("./NodeView-BjGTiM1O.js"), __vite__mapDeps([183,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,165,151,24,80,68,81,54,82,83,96,112,37,38,85,152,166,167,168,169,170,154,155,171,133,134,122,172,173,174,184,185,65,73,186,106,107,87,88,187,188,189,190,191,192,193,194,195,196,197,57,198,199,200,201,156,157,31,202,26,161,30,115,203,204,34,205]));
var WorkflowExecutionsView = async () => await __vitePreload(() => import("./WorkflowExecutionsView-FCkyyfKq.js"), __vite__mapDeps([206,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,65,37,24,38,80,68,81,54,82,83,85,26,130,108,109,114,30,112,131,132,207,208,133,134,209]));
var WorkflowExecutionsLandingPage = async () => await __vitePreload(() => import("./WorkflowExecutionsLandingPage-CcJ9U18X.js"), __vite__mapDeps([210,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,85,112,21,22,83,207,208,211]));
var WorkflowExecutionsPreview = async () => await __vitePreload(() => import("./WorkflowExecutionsPreview-BYWh0GBH.js"), __vite__mapDeps([212,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,26,130,108,109,213,82,214,30,22,204,133,134,215]));
var SettingsView = async () => await __vitePreload(() => import("./SettingsView-BdM6C-Pa.js"), __vite__mapDeps([216,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,217]));
var SettingsLdapView = async () => await __vitePreload(() => import("./SettingsLdapView-DOse-1bN.js"), __vite__mapDeps([218,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,170,17,18,19,37,24,20,38,219,84,26,30,22,220]));
var SettingsPersonalView = async () => await __vitePreload(() => import("./SettingsPersonalView-DWGs5wge.js"), __vite__mapDeps([221,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,222,22,223]));
var SettingsUsersView = async () => await __vitePreload(() => import("./SettingsUsersView-8_Y7zQMz.js"), __vite__mapDeps([224,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,125,84,26,44,68,30,22,134,225]));
var SettingsCommunityNodesView = async () => await __vitePreload(() => import("./SettingsCommunityNodesView-3swLF8oI.js"), __vite__mapDeps([226,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,151,24,80,68,81,54,82,83,96,112,37,38,85,199,153,154,155,115,53,50,227]));
var SettingsApiView = async () => await __vitePreload(() => import("./SettingsApiView-DHCr1LrA.js"), __vite__mapDeps([228,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,196,37,24,20,38,229,26,30,22,230]));
var SettingsLogStreamingView = async () => await __vitePreload(() => import("./SettingsLogStreamingView-BVSln3cm.js"), __vite__mapDeps([231,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,196,37,24,20,38,232,26,30,22,233]));
var SetupView = async () => await __vitePreload(() => import("./SetupView-DXmGJi1C.js"), __vite__mapDeps([234,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,141,142]));
var SigninView = async () => await __vitePreload(() => import("./SigninView-Di3btl9A.js"), __vite__mapDeps([235,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,222,141,142,236]));
var SignupView = async () => await __vitePreload(() => import("./SignupView-BM4OXX-x.js"), __vite__mapDeps([237,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,141,142]));
var TemplatesCollectionView = async () => await __vitePreload(() => import("./TemplatesCollectionView-DdMjHvDQ.js"), __vite__mapDeps([238,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,40,239,240,87,23,88,241,242,20,243,21,22,244,245,246,191,247]));
var TemplatesWorkflowView = async () => await __vitePreload(() => import("./TemplatesWorkflowView-B8_w-yL7.js"), __vite__mapDeps([248,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,40,239,240,87,23,88,213,82,214,243,21,22,244,245,246,191,249]));
var SetupWorkflowFromTemplateView = async () => await __vitePreload(() => import("./SetupWorkflowFromTemplateView-B77sQQ6O.js"), __vite__mapDeps([250,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,239,240,87,23,88,20,251,246,191,252,21,22,245,253]));
var TemplatesSearchView = async () => await __vitePreload(() => import("./TemplatesSearchView-BtUlSZXh.js"), __vite__mapDeps([254,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,39,40,239,240,87,23,88,241,242,21,22,255]));
var VariablesView = async () => await __vitePreload(() => import("./VariablesView-CnlNqt-I.js"), __vite__mapDeps([256,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,39,121,42,43,26,44,45,46,47,48,49,50,51,68,30,22,137,138,257]));
var SettingsUsageAndPlan = async () => await __vitePreload(() => import("./SettingsUsageAndPlan-BcyB9_cH.js"), __vite__mapDeps([258,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,73,38,24,20,105,26,30,22,259]));
var SettingsSso = async () => await __vitePreload(() => import("./SettingsSso-LCXnYtLn.js"), __vite__mapDeps([260,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,84,26,261,68,262,30,22,263]));
var SignoutView = async () => await __vitePreload(() => import("./SignoutView-WKs5gvAj.js"), __vite__mapDeps([264,4,5,6,7,8,15,10,16,17,18,19,24,20]));
var SamlOnboarding = async () => await __vitePreload(() => import("./SamlOnboarding-EExl-EAp.js"), __vite__mapDeps([265,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,84,141,142]));
var SettingsSourceControl = async () => await __vitePreload(() => import("./SettingsSourceControl-BmJrrMbt.js"), __vite__mapDeps([266,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,26,261,68,262,30,22,267]));
var SettingsExternalSecrets = async () => await __vitePreload(() => import("./SettingsExternalSecrets-Czm8izQh.js"), __vite__mapDeps([268,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,26,30,22,269,122,270,271]));
var SettingsProvisioningView = async () => await __vitePreload(() => import("./SettingsProvisioningView-Bd7_e49M.js"), __vite__mapDeps([272,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,273]));
var WorkerView = async () => await __vitePreload(() => import("./WorkerView-a-85mW7s.js"), __vite__mapDeps([274,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,275,151,24,80,68,81,54,82,83,96,112,37,38,85,276,153,154,155,115,53,50,25,26,158,30,277]));
var WorkflowHistory = async () => await __vitePreload(() => import("./WorkflowHistory-BDm1H5BL.js"), __vite__mapDeps([278,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,152,26,213,82,214,30,22,279]));
var WorkflowOnboardingView = async () => await __vitePreload(() => import("./WorkflowOnboardingView-BZP0l2UH.js"), __vite__mapDeps([280,8,5,6,15,7,10,16,17,18,19,21,22]));
var EvaluationsView = async () => await __vitePreload(() => import("./EvaluationsView-Dr4m1cGH.js"), __vite__mapDeps([281,1,2,3,4,5,6,7,8,9,10,11,12,13,275,15,16,17,18,19,24,20,219,39,276,128,129,282,283,134,284]));
var TestRunDetailView = async () => await __vitePreload(() => import("./TestRunDetailView-CEE1M2hn.js"), __vite__mapDeps([285,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,24,20,219,39,162,282,283,134,286]));
var EvaluationRootView = async () => await __vitePreload(() => import("./EvaluationsRootView-CcJipqTv.js"), __vite__mapDeps([287,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,80,68,81,54,82,83,105,26,30,288]));
var PrebuiltAgentTemplatesView = async () => await __vitePreload(() => import("./PrebuiltAgentTemplatesView-C6IbTjn9.js"), __vite__mapDeps([289,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,87,88,46,47,290]));
function getTemplatesRedirect(defaultRedirect) {
	if (!useSettingsStore().isTemplatesEnabled) return { name: `${defaultRedirect}` || VIEWS.NOT_FOUND };
	return false;
}
const routes = [
	{
		path: "/",
		redirect: "/home/workflows",
		meta: { middleware: ["authenticated"] }
	},
	{
		path: "/collections/:id",
		name: VIEWS.COLLECTION,
		components: {
			default: TemplatesCollectionView,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			telemetry: { getProperties(route) {
				const templatesStore = useTemplatesStore();
				return {
					collection_id: route.params.id,
					wf_template_repo_session_id: templatesStore.currentSessionId
				};
			} },
			getRedirect: getTemplatesRedirect,
			middleware: ["authenticated"]
		}
	},
	{
		path: "/templates/agents",
		name: VIEWS.PRE_BUILT_AGENT_TEMPLATES,
		components: {
			default: PrebuiltAgentTemplatesView,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			getRedirect: getTemplatesRedirect,
			middleware: ["authenticated"]
		},
		beforeEnter: (_to, _from, next) => {
			const calloutHelpers = useCalloutHelpers();
			const templatesStore = useTemplatesStore();
			if (!calloutHelpers.isPreBuiltAgentsCalloutVisible.value) window.location.href = templatesStore.websiteTemplateRepositoryURL;
			else next();
		}
	},
	{
		path: "/templates/:id",
		name: VIEWS.TEMPLATE,
		components: {
			default: TemplatesWorkflowView,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			getRedirect: getTemplatesRedirect,
			telemetry: { getProperties(route) {
				const templatesStore = useTemplatesStore();
				return {
					template_id: tryToParseNumber(Array.isArray(route.params.id) ? route.params.id[0] : route.params.id),
					wf_template_repo_session_id: templatesStore.currentSessionId
				};
			} },
			middleware: ["authenticated"]
		}
	},
	{
		path: "/templates/:id/setup",
		name: VIEWS.TEMPLATE_SETUP,
		components: {
			default: SetupWorkflowFromTemplateView,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			getRedirect: getTemplatesRedirect,
			telemetry: { getProperties(route) {
				const templatesStore = useTemplatesStore();
				return {
					template_id: tryToParseNumber(Array.isArray(route.params.id) ? route.params.id[0] : route.params.id),
					wf_template_repo_session_id: templatesStore.currentSessionId
				};
			} },
			middleware: ["authenticated"]
		}
	},
	{
		path: "/templates/",
		name: VIEWS.TEMPLATES,
		components: {
			default: TemplatesSearchView,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			getRedirect: getTemplatesRedirect,
			scrollOffset: 0,
			telemetry: { getProperties() {
				return { wf_template_repo_session_id: useTemplatesStore().currentSessionId };
			} },
			setScrollPosition(pos) {
				this.scrollOffset = pos;
			},
			middleware: ["authenticated"]
		},
		beforeEnter: (_to, _from, next) => {
			const templatesStore = useTemplatesStore();
			if (!templatesStore.hasCustomTemplatesHost) window.location.href = templatesStore.websiteTemplateRepositoryURL;
			else next();
		}
	},
	{
		path: "/variables",
		name: VIEWS.VARIABLES,
		components: {
			default: VariablesView,
			sidebar: MainSidebar
		},
		meta: { middleware: ["authenticated"] }
	},
	{
		path: "/workflow/:name/debug/:executionId",
		name: VIEWS.EXECUTION_DEBUG,
		components: {
			default: NodeView,
			header: MainHeader,
			sidebar: MainSidebar,
			footer: LogsPanel
		},
		meta: {
			nodeView: true,
			keepWorkflowAlive: true,
			middleware: ["authenticated", "enterprise"],
			middlewareOptions: { enterprise: { feature: [EnterpriseEditionFeature.DebugInEditor] } }
		}
	},
	{
		path: "/workflow/:name/executions",
		name: VIEWS.WORKFLOW_EXECUTIONS,
		components: {
			default: WorkflowExecutionsView,
			header: MainHeader,
			sidebar: MainSidebar
		},
		meta: {
			keepWorkflowAlive: true,
			middleware: ["authenticated"]
		},
		children: [{
			path: "",
			name: VIEWS.EXECUTION_HOME,
			components: { executionPreview: WorkflowExecutionsLandingPage },
			meta: {
				keepWorkflowAlive: true,
				middleware: ["authenticated"]
			}
		}, {
			path: ":executionId/:nodeId?",
			name: VIEWS.EXECUTION_PREVIEW,
			components: { executionPreview: WorkflowExecutionsPreview },
			meta: {
				keepWorkflowAlive: true,
				middleware: ["authenticated"]
			}
		}]
	},
	{
		path: "/workflow/:name/evaluation",
		name: VIEWS.EVALUATION,
		components: {
			default: EvaluationRootView,
			header: MainHeader,
			sidebar: MainSidebar
		},
		props: { default: true },
		meta: {
			keepWorkflowAlive: true,
			middleware: ["authenticated"]
		},
		children: [{
			path: "",
			name: VIEWS.EVALUATION_EDIT,
			component: EvaluationsView,
			props: true
		}, {
			path: "test-runs/:runId",
			name: VIEWS.EVALUATION_RUNS_DETAIL,
			component: TestRunDetailView,
			props: true
		}]
	},
	{
		path: "/workflow/:workflowId/history/:versionId?",
		name: VIEWS.WORKFLOW_HISTORY,
		components: {
			default: WorkflowHistory,
			sidebar: MainSidebar
		},
		meta: {
			middleware: ["authenticated", "enterprise"],
			middlewareOptions: { enterprise: { feature: [EnterpriseEditionFeature.WorkflowHistory] } }
		}
	},
	{
		path: "/workflows/templates/:id",
		name: VIEWS.TEMPLATE_IMPORT,
		components: {
			default: NodeView,
			header: MainHeader,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			keepWorkflowAlive: true,
			getRedirect: getTemplatesRedirect,
			middleware: ["authenticated"]
		}
	},
	{
		path: "/workflows/onboarding/:id",
		name: VIEWS.WORKFLOW_ONBOARDING,
		components: {
			default: WorkflowOnboardingView,
			header: MainHeader,
			sidebar: MainSidebar
		},
		meta: {
			templatesEnabled: true,
			keepWorkflowAlive: true,
			getRedirect: () => getTemplatesRedirect(VIEWS.NEW_WORKFLOW),
			middleware: ["authenticated"]
		}
	},
	{
		path: "/workflow/new",
		name: VIEWS.NEW_WORKFLOW,
		components: {
			default: NodeView,
			header: MainHeader,
			sidebar: MainSidebar,
			footer: LogsPanel
		},
		meta: {
			nodeView: true,
			keepWorkflowAlive: true,
			middleware: ["authenticated"]
		}
	},
	{
		path: "/workflows/demo",
		name: VIEWS.DEMO,
		components: {
			default: NodeView,
			footer: DemoFooter
		},
		meta: {
			middleware: ["authenticated"],
			middlewareOptions: { authenticated: { bypass: () => {
				return useSettingsStore().isPreviewMode;
			} } }
		}
	},
	{
		path: "/workflow/:name/:nodeId?",
		name: VIEWS.WORKFLOW,
		components: {
			default: NodeView,
			header: MainHeader,
			sidebar: MainSidebar,
			footer: LogsPanel
		},
		meta: {
			nodeView: true,
			keepWorkflowAlive: true,
			middleware: ["authenticated"]
		}
	},
	{
		path: "/workflow",
		redirect: "/workflow/new"
	},
	{
		path: "/signin",
		name: VIEWS.SIGNIN,
		components: { default: SigninView },
		meta: {
			telemetry: { pageCategory: "auth" },
			middleware: ["guest"]
		}
	},
	{
		path: "/signup",
		name: VIEWS.SIGNUP,
		components: { default: SignupView },
		meta: {
			telemetry: { pageCategory: "auth" },
			middleware: ["guest"]
		}
	},
	{
		path: "/signout",
		name: VIEWS.SIGNOUT,
		components: { default: SignoutView },
		meta: {
			telemetry: { pageCategory: "auth" },
			middleware: ["authenticated"]
		}
	},
	{
		path: "/setup",
		name: VIEWS.SETUP,
		components: { default: SetupView },
		meta: {
			middleware: ["defaultUser"],
			telemetry: { pageCategory: "auth" }
		}
	},
	{
		path: "/forgot-password",
		name: VIEWS.FORGOT_PASSWORD,
		components: { default: ForgotMyPasswordView },
		meta: {
			middleware: ["guest"],
			telemetry: { pageCategory: "auth" }
		}
	},
	{
		path: "/change-password",
		name: VIEWS.CHANGE_PASSWORD,
		components: { default: ChangePasswordView },
		meta: {
			middleware: ["guest"],
			telemetry: { pageCategory: "auth" }
		}
	},
	{
		path: "/settings",
		name: VIEWS.SETTINGS,
		component: SettingsView,
		props: true,
		redirect: () => {
			if (useSettingsStore().settings.hideUsagePage) return { name: VIEWS.PERSONAL_SETTINGS };
			return { name: VIEWS.USAGE };
		},
		children: [
			{
				path: "usage",
				name: VIEWS.USAGE,
				components: { settingsView: SettingsUsageAndPlan },
				meta: {
					middleware: ["authenticated", "custom"],
					middlewareOptions: { custom: () => {
						return !useSettingsStore().settings.hideUsagePage;
					} },
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "usage" };
						}
					}
				}
			},
			{
				path: "personal",
				name: VIEWS.PERSONAL_SETTINGS,
				components: { settingsView: SettingsPersonalView },
				meta: {
					middleware: ["authenticated"],
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "personal" };
						}
					}
				}
			},
			{
				path: "users",
				name: VIEWS.USERS_SETTINGS,
				components: { settingsView: SettingsUsersView },
				meta: {
					middleware: ["authenticated", "rbac"],
					middlewareOptions: { rbac: { scope: ["user:create", "user:update"] } },
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "users" };
						}
					}
				}
			},
			{
				path: "project-roles",
				components: { settingsView: RouterView },
				children: [
					{
						path: "",
						name: VIEWS.PROJECT_ROLES_SETTINGS,
						component: async () => await __vitePreload(() => import("./ProjectRolesView-JblQF33a.js"), __vite__mapDeps([291,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,86,26,30,22,292]))
					},
					{
						path: "new",
						name: VIEWS.PROJECT_NEW_ROLE,
						component: async () => await __vitePreload(() => import("./ProjectRoleView-Dz82Hr5N.js"), __vite__mapDeps([293,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,86,294]))
					},
					{
						path: "edit/:roleSlug",
						name: VIEWS.PROJECT_ROLE_SETTINGS,
						component: async () => await __vitePreload(() => import("./ProjectRoleView-Dz82Hr5N.js"), __vite__mapDeps([293,1,2,3,4,5,6,7,8,9,10,11,12,13,15,16,17,18,19,37,24,20,38,86,294]))
					}
				],
				meta: {
					middleware: [
						"authenticated",
						"rbac",
						"custom"
					],
					middlewareOptions: {
						rbac: { scope: ["role:manage"] },
						custom: () => {
							return useEnvFeatureFlag().check.value("CUSTOM_ROLES");
						}
					},
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "project-roles" };
						}
					}
				}
			},
			{
				path: "api",
				name: VIEWS.API_SETTINGS,
				components: { settingsView: SettingsApiView },
				meta: {
					middleware: ["authenticated"],
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "api" };
						}
					}
				}
			},
			{
				path: "environments",
				name: VIEWS.SOURCE_CONTROL,
				components: { settingsView: SettingsSourceControl },
				meta: {
					middleware: ["authenticated", "rbac"],
					middlewareOptions: { rbac: { scope: "sourceControl:manage" } },
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "environments" };
						}
					}
				}
			},
			{
				path: "external-secrets",
				name: VIEWS.EXTERNAL_SECRETS_SETTINGS,
				components: { settingsView: SettingsExternalSecrets },
				meta: {
					middleware: ["authenticated", "rbac"],
					middlewareOptions: { rbac: { scope: ["externalSecretsProvider:list", "externalSecretsProvider:update"] } },
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "external-secrets" };
						}
					}
				}
			},
			{
				path: "sso",
				name: VIEWS.SSO_SETTINGS,
				components: { settingsView: SettingsSso },
				meta: {
					middleware: ["authenticated", "rbac"],
					middlewareOptions: { rbac: { scope: "saml:manage" } },
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "sso" };
						}
					}
				}
			},
			{
				path: "log-streaming",
				name: VIEWS.LOG_STREAMING_SETTINGS,
				components: { settingsView: SettingsLogStreamingView },
				meta: {
					middleware: ["authenticated", "rbac"],
					middlewareOptions: { rbac: { scope: "logStreaming:manage" } },
					telemetry: { pageCategory: "settings" }
				}
			},
			{
				path: "workers",
				name: VIEWS.WORKER_VIEW,
				components: { settingsView: WorkerView },
				meta: { middleware: ["authenticated"] }
			},
			{
				path: "community-nodes",
				name: VIEWS.COMMUNITY_NODES,
				components: { settingsView: SettingsCommunityNodesView },
				meta: {
					middleware: [
						"authenticated",
						"rbac",
						"custom"
					],
					middlewareOptions: {
						rbac: { scope: ["communityPackage:list", "communityPackage:update"] },
						custom: () => {
							return useSettingsStore().isCommunityNodesFeatureEnabled;
						}
					},
					telemetry: { pageCategory: "settings" }
				}
			},
			{
				path: "ldap",
				name: VIEWS.LDAP_SETTINGS,
				components: { settingsView: SettingsLdapView },
				meta: {
					middleware: ["authenticated", "rbac"],
					middlewareOptions: { rbac: { scope: "ldap:manage" } }
				}
			},
			{
				path: "provisioning",
				name: VIEWS.PROVISIONING_SETTINGS,
				components: { settingsView: SettingsProvisioningView },
				meta: {
					middleware: [
						"authenticated",
						"enterprise",
						"rbac"
					],
					middlewareOptions: {
						enterprise: { feature: "provisioning" },
						rbac: { scope: "provisioning:manage" }
					},
					telemetry: {
						pageCategory: "settings",
						getProperties() {
							return { feature: "provisioning" };
						}
					}
				}
			}
		]
	},
	{
		path: "/saml/onboarding",
		name: VIEWS.SAML_ONBOARDING,
		components: { default: SamlOnboarding },
		meta: {
			middleware: ["authenticated", "custom"],
			middlewareOptions: { custom: () => {
				const settingsStore = useSettingsStore();
				return useSSOStore().isEnterpriseSamlEnabled && !settingsStore.isCloudDeployment;
			} },
			telemetry: { pageCategory: "auth" }
		}
	},
	...projectsRoutes,
	{
		path: "/entity-not-found/:entityType(credential|workflow)",
		props: true,
		name: VIEWS.ENTITY_NOT_FOUND,
		components: {
			default: EntityNotFound,
			sidebar: MainSidebar
		}
	},
	{
		path: "/entity-not-authorized/:entityType(credential|workflow)",
		props: true,
		name: VIEWS.ENTITY_UNAUTHORIZED,
		components: {
			default: EntityUnAuthorised,
			sidebar: MainSidebar
		}
	},
	{
		path: "/:pathMatch(.*)*",
		name: VIEWS.NOT_FOUND,
		component: ErrorView,
		props: {
			messageKey: "error.pageNotFound",
			errorCode: 404,
			redirectTextKey: "error.goBack",
			redirectPage: VIEWS.HOMEPAGE
		},
		meta: {
			nodeView: true,
			telemetry: { disabled: true }
		}
	}
];
function withCanvasReadOnlyMeta(route) {
	if (!route.meta) route.meta = {};
	route.meta.readOnlyCanvas = !EDITABLE_CANVAS_VIEWS.includes(route?.name ?? "");
	if (route.children) route.children = route.children.map(withCanvasReadOnlyMeta);
	return route;
}
var router = createRouter({
	history: createWebHistory(window.BASE_PATH ?? "/"),
	scrollBehavior(to, _, savedPosition) {
		if (savedPosition === null && to.name === VIEWS.TEMPLATES && to.meta?.setScrollPosition) to.meta.setScrollPosition(0);
	},
	routes: routes.map(withCanvasReadOnlyMeta)
});
router.beforeEach(async (to, from, next) => {
	try {
		await initializeCore();
		await initializeAuthenticatedFeatures(void 0, to.name);
		if (useSettingsStore().showSetupPage) {
			if (to.name === VIEWS.SETUP) return next();
			return next({ name: VIEWS.SETUP });
		}
		const routeMiddleware = to.meta?.middleware ?? [];
		const routeMiddlewareOptions = to.meta?.middlewareOptions ?? {};
		for (const middlewareName of routeMiddleware) {
			let nextCalled = false;
			const middlewareNext = ((location) => {
				next(location);
				nextCalled = true;
			});
			const middlewareOptions = routeMiddlewareOptions[middlewareName];
			const middlewareFn = middleware[middlewareName];
			await middlewareFn(to, from, middlewareNext, middlewareOptions);
			if (nextCalled) return;
		}
		return next();
	} catch (failure) {
		const settingsStore = useSettingsStore();
		if (failure instanceof MfaRequiredError && settingsStore.isMFAEnforced) if (to.name !== VIEWS.PERSONAL_SETTINGS) return next({ name: VIEWS.PERSONAL_SETTINGS });
		else return next();
		if (isNavigationFailure(failure)) console.log(failure);
		else console.error(failure);
	}
});
router.afterEach((to, from) => {
	try {
		const telemetry = useTelemetry();
		const uiStore = useUIStore();
		const templatesStore = useTemplatesStore();
		useExternalHooks().run("main.routeChange", {
			from,
			to
		});
		uiStore.currentView = to.name ?? "";
		if (to.meta?.templatesEnabled) templatesStore.setSessionId();
		else templatesStore.resetSessionId();
		telemetry.page(to);
		const { trackResourceOpened } = useRecentResources();
		trackResourceOpened(to);
	} catch (failure) {
		if (isNavigationFailure(failure)) console.log(failure);
		else console.error(failure);
	}
});
var router_default = router;
export { registerModuleRoutes as n, router_default as t };
