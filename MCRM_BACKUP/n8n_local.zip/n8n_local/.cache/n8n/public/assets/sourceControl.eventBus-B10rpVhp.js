import { x as createEventBus } from "./truncate-Dc79aML5.js";
const sourceControlEventBus = createEventBus();
export { sourceControlEventBus as t };
