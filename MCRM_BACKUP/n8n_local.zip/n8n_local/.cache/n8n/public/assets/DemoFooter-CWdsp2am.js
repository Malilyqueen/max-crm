import { C as computed, E as createCommentVNode, P as defineComponent, T as createBlock, et as openBlock } from "./vue.runtime.esm-bundler-DDuXT-9r.js";
import "./_MapCache-BGBKpT5S.js";
import "./src-Cl0xZtCE.js";
import "./en-BYTsM8fR.js";
import "./preload-helper-CR0ecmWK.js";
import "./_plugin-vue_export-helper-BwBpWJRZ.js";
import "./truncate-Dc79aML5.js";
import "./icon-C8yfF1LY.js";
import "./overlay-DeoWJ8oB.js";
import "./empty-BuGRxzl4.js";
import "./useMessage-CVZHrsoz.js";
import { o as useWorkflowsStore } from "./useTelemetry-BxbCYDca.js";
import "./useToast-CKD06lpn.js";
import "./sanitize-html-BuXr7o4T.js";
import "./path-browserify-DsmB_HMK.js";
import "./constants-B1JYxPAR.js";
import "./merge-Db6rb1_m.js";
import "./assistant.store-D6Fihh2i.js";
import "./dateformat-D7TIhVd4.js";
import "./useDebounce-BRhQZVIC.js";
import "./useExternalHooks-ChElZw8W.js";
import "./chatPanel.store-Dt9ypdvG.js";
import "./npsSurvey.store-DTTUiGq9.js";
import "./cloudPlan.store-x1IpiElw.js";
import "./templates.store-pF0jvUy0.js";
import "./focusPanel.store-Pqc2v-Ms.js";
import "./useWorkflowSaving-DOwP3C1n.js";
import "./retry-sDkwzrPY.js";
import "./executions.store-DmR1JjSC.js";
import "./useRunWorkflow-D5rKvgfC.js";
import "./usePinnedData-_-i0LUdd.js";
import "./nodeCreator.store-DDUlc1Wi.js";
import "./nodeIcon-CyGsA5TL.js";
import "./useClipboard-BPg-srt1.js";
import "./useCanvasOperations-BxV5Dc21.js";
import { t as LogsPanel_default } from "./LogsPanel-BSFP3TRR.js";
import "./folders.store-x8KuYpUo.js";
import "./NodeIcon-Bbl9Jpsi.js";
import "./KeyboardShortcutTooltip-CXKgjDIT.js";
import "./isEmpty-CRyMT0C3.js";
import "./NDVEmptyState-CFiiknri.js";
import "./externalSecrets.ee.store-px6HohWF.js";
import "./uniqBy-C2OAfwKy.js";
import "./schemaPreview.store-BdP1Rtj4.js";
import "./FileSaver.min-CR_3Le5x.js";
import "./vue-B27A1Apg.js";
import "./vue-json-pretty-DiH9ZFoW.js";
import "./RunDataHtml-DOQ0pkg3.js";
import "./dateFormatter-jkly8a5N.js";
import "./useExecutionHelpers-5AFgT_t7.js";
import "./useKeybindings-fJZrJyDB.js";
import "./core-BfCr8skN.js";
import "./VueMarkdown-70GnkI0W.js";
import "./xml-CcxXd9zY.js";
import "./AnimatedSpinner-DRB4A7Dx.js";
import "./useLogsTreeExpand-DbXAJb89.js";
import "./core-CGHB7oTc.js";
var DemoFooter_default = /* @__PURE__ */ defineComponent({
	__name: "DemoFooter",
	setup(__props) {
		const workflowsStore = useWorkflowsStore();
		const hasExecutionData = computed(() => workflowsStore.workflowExecutionData);
		return (_ctx, _cache) => {
			return hasExecutionData.value ? (openBlock(), createBlock(LogsPanel_default, {
				key: 0,
				"is-read-only": true
			})) : createCommentVNode("", true);
		};
	}
});
export { DemoFooter_default as default };
