import { t as en_default } from "./en-BYTsM8fR.js";
export { en_default as default };
