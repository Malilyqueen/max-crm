﻿$env:N8N_USER_FOLDER="D:\Macrea\CRM\n8n_local"
$env:DB_SQLITE_FILE="D:\Macrea\CRM\n8n_local\.n8n\database.sqlite"
$env:DB_SQLITE_POOL_SIZE="5"
$env:N8N_RUNNERS_ENABLED="true"
$env:N8N_BLOCK_ENV_ACCESS_IN_NODE="false"
$env:N8N_GIT_NODE_DISABLE_BARE_REPOS="true"
$env:N8N_HOST="localhost"
$env:N8N_PORT="5678"

Write-Host "Launching n8n with data at $env:N8N_USER_FOLDER" -ForegroundColor Cyan
n8n start
