// server.js (ESM) - Version corrigée

import express from 'express';
import cors from 'cors';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { exec } from 'child_process';
import dotenv from 'dotenv';
import { say } from './utils/say.js';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
app.use(cors());
app.use(express.json());

// --- Config ---
const PORT = process.env.PORT || 3005;
const BIND_HOST = process.env.BIND_HOST || '127.0.0.1';
const TASKS_DIR = process.env.TASKS_DIR || path.join(__dirname, '..', 'ia_admin', 'tasks_autogen'); // fallback
const BACKUP_ROOT = process.env.BACKUP_ROOT || path.join(__dirname, '..', 'backups', 'react');
const REACT_SRC_DIR = process.env.REACT_SRC_DIR || path.join(__dirname, '..', 'ia-admin-ui', 'src');
const DATA_DIR = path.join(__dirname, 'data');
if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const HISTORY_PATH = path.join(DATA_DIR, 'chat-history.json');
const AGENT_IDENTITY_PATH = path.join(DATA_DIR, 'agent_identity.json');
const PROJECT_MAP_PATH = path.join(__dirname, '..', 'ia_admin_api', 'project-map.json'); // keep compatibility

// --- Chargement unique de l'identité de l'agent ---
let agentIdentity = {};
try {
  if (fs.existsSync(AGENT_IDENTITY_PATH)) {
    const raw = fs.readFileSync(AGENT_IDENTITY_PATH, 'utf8');
    agentIdentity = JSON.parse(raw);
  } else {
    throw new Error('agent_identity.json manquant');
  }
} catch (e) {
  console.error('⚠️ Impossible de lire data/agent_identity.json — vérifiez le fichier.', e.message);
  agentIdentity = {}; // ou valeurs par défaut minimales si besoin
}

// --- Helpers: safe filenames, history, read/write ---
function isSafeReactFile(filename) {
  return /^[\w\-.]+\.jsx?$/.test(filename);
}

function readJSONSafe(p, defaultValue = null) {
  try {
    if (!fs.existsSync(p)) return defaultValue;
    return JSON.parse(fs.readFileSync(p, 'utf8'));
  } catch (e) {
    console.error('readJSONSafe error', p, e.message);
    return defaultValue;
  }
}

function writeJSONSafe(p, obj) {
  try {
    fs.writeFileSync(p, JSON.stringify(obj, null, 2), 'utf8');
    return true;
  } catch (e) {
    console.error('writeJSONSafe error', p, e.message);
    return false;
  }
}

// Chat history helpers
function getHistory() {
  return readJSONSafe(HISTORY_PATH, []);
}
function saveToHistory(role, content) {
  try {
    const h = getHistory();
    h.push({ role, content, timestamp: new Date().toISOString() });
    writeJSONSafe(HISTORY_PATH, h);
  } catch (e) {
    console.error('saveToHistory error', e.message);
  }
}
function getLastMessages(n = 10) {
  const h = getHistory();
  return h.slice(-n);
}

// --- Small utilities ---
function safeJsonParse(str) {
  try { return JSON.parse(str); } catch { return null; }
}

// Build prompt for LLM using agent identity + recent history
function buildPrompt(userPrompt, chatHistory = []) {
  const identitySection = `
Tu es ${agentIdentity.nom}, un ${agentIdentity.type}.
Mission : ${agentIdentity.rôle}

Projet : ${agentIdentity.contexte_projet?.projet ?? 'non spécifié'}
Utilisation : ${agentIdentity.contexte_projet?.utilisation ?? 'non spécifié'}
Mission métier : ${agentIdentity.contexte_projet?.mission_metier ?? ''}

Voici tes permissions :
${(agentIdentity.permissions || []).map(p => `- ${p}`).join('\n')}

Objectifs :
${(agentIdentity.objectifs || []).map(o => `- ${o}`).join('\n')}

Personnalité : ${agentIdentity.personnalité || ''}
`.trim();

  const historyText = (chatHistory.length ? chatHistory.map(h => `${h.role.toUpperCase()}: ${h.content || h.message || ''}`).join('\n') : '');
  return `${identitySection}\n\nContexte récent :\n${historyText}\n\nDemande utilisateur : ${userPrompt}`;
}

// Ask OpenAI (fallback to test response if no key)
async function askOpenAI(prompt) {
  const OPENAI_API_KEY = process.env.OPENAI_API_KEY;
  if (!OPENAI_API_KEY) {
    // fallback friendly answer (keeps context)
    return `🧠 (MODE LOCAL) M.A.X. a reçu : "${prompt}". Pour des réponses enrichies, définis OPENAI_API_KEY dans .env.`;
  }

  // Using Chat Completions (gpt-3.5-turbo). Node 18+ has global fetch.
  try {
    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${OPENAI_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.5,
        max_tokens: 800
      })
    });
    const json = await resp.json();
    if (!resp.ok) {
      console.error('OpenAI error:', json);
      return `❌ Erreur OpenAI: ${json.error?.message || JSON.stringify(json)}`;
    }
    const reply = json.choices?.[0]?.message?.content ?? JSON.stringify(json);
    return reply;
  } catch (e) {
    console.error('askOpenAI error', e.message);
    return `❌ Erreur (appel OpenAI): ${e.message}`;
  }
}

// --- Endpoints ---

// health
app.get('/health', (_req, res) => res.json({ ok: true }));

// serve agent identity file
app.get('/agent-identity.json', (_req, res) => {
  if (fs.existsSync(AGENT_IDENTITY_PATH)) {
    return res.sendFile(AGENT_IDENTITY_PATH);
  }
  // fallback: return current in-memory identity
  return res.json(agentIdentity);
});

// serve project-map.json if exists
app.get('/project-map.json', (req, res) => {
  const p = path.join(process.cwd(), 'project-map.json');
  if (fs.existsSync(p)) return res.sendFile(p);
  return res.status(404).json({ error: 'project-map.json non trouvé' });
});

// list tasks
app.get('/api/tasks', (req, res) => {
  try {
    const tasksDir = TASKS_DIR;
    if (!fs.existsSync(tasksDir)) fs.mkdirSync(tasksDir, { recursive: true });
    const files = fs.readdirSync(tasksDir).filter(f => f.endsWith('.json'));
    const tasks = files.map(f => {
      const content = safeJsonParse(fs.readFileSync(path.join(tasksDir, f), 'utf8'));
      return { filename: f, content };
    });
    res.json(tasks);
  } catch (e) {
    console.error('/api/tasks', e.message);
    res.status(500).json({ error: e.message });
  }
});

// create task
app.post('/api/tasks/create', (req, res) => {
  try {
    const { name = 'task', description = '', payload = {} } = req.body;
    const timestamp = Date.now();
    const filename = `${name.replace(/[^\w\-]/g, '_')}-${timestamp}.json`;
    if (!fs.existsSync(TASKS_DIR)) fs.mkdirSync(TASKS_DIR, { recursive: true });
    const taskPath = path.join(TASKS_DIR, filename);
    const taskData = { task: name, description, action: payload.action || 'custom', createdAt: new Date().toISOString(), payload };
    fs.writeFileSync(taskPath, JSON.stringify(taskData, null, 2), 'utf8');
    saveToHistory('system', `Tâche créée: ${filename}`);
    res.json({ ok: true, filename, task: taskData });
  } catch (e) {
    console.error('/api/tasks/create', e.message);
    res.status(500).json({ error: e.message });
  }
});

// delete task
app.delete('/api/tasks/:filename', (req, res) => {
  try {
    const p = path.join(TASKS_DIR, req.params.filename);
    if (fs.existsSync(p)) fs.unlinkSync(p);
    res.json({ ok: true });
  } catch (e) {
    console.error('/api/tasks/:filename delete', e.message);
    res.status(500).json({ error: e.message });
  }
});

// validate/execute task
app.post('/api/tasks/:filename/validate', (req, res) => {
  try {
    const p = path.join(TASKS_DIR, req.params.filename);
    if (!fs.existsSync(p)) return res.status(404).json({ error: 'task not found' });
    const payload = JSON.parse(fs.readFileSync(p, 'utf8'));

    saveToHistory('system', `Validation de la tâche ${req.params.filename}`);

    // handle known actions
    if (payload.action === 'generate_project_map' || payload.task === 'generate_crm_map') {
      const structure = payload.structure || payload.payload?.structure || {};
      const outPath = path.join(process.cwd(), 'project-map.json');
      fs.writeFileSync(outPath, JSON.stringify(structure, null, 2), 'utf8');
      say(`J’ai analysé l’environnement. La carte mentale est prête.`);
      return res.json({ ok: true, action: 'generate_project_map' });
    }

    // default: mark validated
    return res.json({ ok: true, forwarded: !!process.env.N8N_WEBHOOK_URL });
  } catch (e) {
    console.error('/api/tasks/:filename/validate', e.message);
    res.status(500).json({ error: e.message });
  }
});

// list react files
app.get('/api/react-files', (req, res) => {
  try {
    const dir = REACT_SRC_DIR;
    if (!fs.existsSync(dir)) return res.status(404).json({ error: 'react src dir not found' });
    const files = fs.readdirSync(dir).filter(f => isSafeReactFile(f));
    res.json({ files });
  } catch (e) {
    console.error('/api/react-files', e.message);
    res.status(500).json({ error: e.message });
  }
});

// read react file
app.get('/api/react-file', (req, res) => {
  try {
    const name = req.query.name;
    if (!name || !isSafeReactFile(name)) return res.status(400).json({ error: 'Nom de fichier invalide' });
    const filePath = path.join(REACT_SRC_DIR, name);
    if (!fs.existsSync(filePath)) return res.status(404).json({ error: 'fichier introuvable' });
    const content = fs.readFileSync(filePath, 'utf8');
    res.send(content);
  } catch (e) {
    console.error('/api/react-file', e.message);
    res.status(500).json({ error: e.message });
  }
});

// write react file
app.post('/api/react-file/write', (req, res) => {
  try {
    const { name, content } = req.body;
    if (!name || !isSafeReactFile(name)) return res.status(400).json({ error: 'Nom de fichier invalide' });
    const filePath = path.join(REACT_SRC_DIR, name);
    fs.writeFileSync(filePath, content, 'utf8');
    saveToHistory('system', `Fichier React modifié: ${name}`);
    res.json({ ok: true });
  } catch (e) {
    console.error('/api/react-file/write', e.message);
    res.status(500).json({ error: e.message });
  }
});

// backup React source (simple copy + zip via PowerShell)
function backupReactSource() {
  try {
    if (!fs.existsSync(REACT_SRC_DIR)) return;
    if (!fs.existsSync(BACKUP_ROOT)) fs.mkdirSync(BACKUP_ROOT, { recursive: true });
    const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
    const folderName = `backup-${timestamp}`;
    const tempDir = path.join(BACKUP_ROOT, folderName);
    fs.mkdirSync(tempDir);
    const files = fs.readdirSync(REACT_SRC_DIR).filter(f => isSafeReactFile(f));
    for (const file of files) {
      fs.copyFileSync(path.join(REACT_SRC_DIR, file), path.join(tempDir, file));
    }
    const zipFile = path.join(BACKUP_ROOT, `${folderName}.zip`);
    // compress on Windows using PowerShell Compress-Archive
    exec(`powershell -Command "Compress-Archive -Path '${tempDir}\\*' -DestinationPath '${zipFile}'"`, (err) => {
      // remove temp dir afterwards
      try { fs.rmSync(tempDir, { recursive: true, force: true }); } catch {}
      if (err) return console.error('❌ Erreur compression ZIP :', err.message);
      console.log(`✅ Backup compressé : ${zipFile}`);
    });
  } catch (e) {
    console.error('backupReactSource error', e.message);
  }
}

function cleanOldBackups() {
  try {
    if (!fs.existsSync(BACKUP_ROOT)) return;
    const now = Date.now();
    fs.readdirSync(BACKUP_ROOT).forEach(file => {
      const full = path.join(BACKUP_ROOT, file);
      const stats = fs.statSync(full);
      const ageMs = now - stats.mtimeMs;
      if (ageMs > 7 * 24 * 3600 * 1000) {
        fs.rmSync(full, { recursive: true, force: true });
        console.log('🗑️ Ancien backup supprimé:', file);
      }
    });
  } catch (e) {
    console.error('cleanOldBackups error', e.message);
  }
}

// schedule backups every 48h
setInterval(() => {
  backupReactSource();
  cleanOldBackups();
}, 48 * 3600 * 1000);

// initial immediate backup
try { backupReactSource(); cleanOldBackups(); } catch (e) { /* ignore */ }

// manual backup endpoint
app.get('/api/backup-now', (req, res) => {
  try {
    backupReactSource();
    cleanOldBackups();
    res.json({ ok: true, message: 'Sauvegarde manuelle exécutée' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// check voice (attempt to run a Powershell TTS test)
app.get('/api/check-voice', (req, res) => {
  try {
    const testCommand = `powershell -Command "Add-Type -AssemblyName System.Speech; $s = New-Object System.Speech.Synthesis.SpeechSynthesizer; $s.Speak('Test vocal IA')"`; // windows only
    exec(testCommand, (err) => {
      if (err) {
        return res.json({ ok: false, message: 'Erreur lors du test vocal (PowerShell).', error: err.message });
      } else {
        return res.json({ ok: true, message: 'Synthèse vocale exécutée avec succès.' });
      }
    });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// history endpoints
app.get('/api/history', (req, res) => {
  res.json(getHistory());
});

app.post('/api/chat', (req, res) => {
  const { role = 'user', message = '' } = req.body;
  if (!message) return res.status(400).json({ error: 'message missing' });
  saveToHistory(role, message);
  res.json({ ok: true });
});

// main ask-task endpoint (uses LLM if OPENAI_API_KEY present, else fallback)
app.post('/api/ask-task', async (req, res) => {
  try {
    const userPrompt = (req.body?.prompt ?? '').toString();
    if (!userPrompt) return res.status(400).json({ reply: '❌ prompt manquant' });

    const last = getLastMessages(10);
    const fullPrompt = buildPrompt(userPrompt, last);

    const reply = await askOpenAI(fullPrompt);

    saveToHistory('user', userPrompt);
    saveToHistory('assistant', reply);

    if (req.body.speak === true) {
      say(reply); // ✅ Corrigé ici : lit la vraie réponse
    }

    res.json({ reply });
  } catch (e) {
    console.error('/api/ask-task error', e.message);
    res.status(500).json({ reply: '❌ Erreur interne M.A.X.' });
  }
});

// Legacy /api/ask simple endpoint (keeps parity)
app.post('/api/ask', async (req, res) => {
  const { message } = req.body;

  try {
    // Appel à OpenAI ou ta logique IA réelle
    const response = await askOpenAI(message);

    // ✅ Envoie de la réponse à l’utilisateur
    res.json({ response });

    // 🗣️ Synthèse vocale de la réponse (optionnelle si ENV activée)
    if (process.env.ENABLE_SPEECH === "true") {
      say(response);
    }
  } catch (err) {
    console.error("Erreur:", err);
    res.status(500).json({ error: "Erreur lors de la génération IA." });
  }
});

// Serve static files (optional) - if you want to expose React build or other static assets
// app.use(express.static(path.join(__dirname, '..', 'ia-admin-ui', 'dist')));

// Start server (force IPv4 binding to avoid ::1 issues)
app.listen(PORT, BIND_HOST, () => {
  console.log(`✅ Backend M.A.X. sur http://${BIND_HOST}:${PORT}`);
});

// route de test vocal
app.get("/api/test-voice", (req, res) => {
  console.log("🗣️ Tentative de parler...");
  say("Test vocal réussi.");
  res.send("✅ Commande vocale envoyée.");
});

// Récupérer les 5 dernières exécutions IA/CRM
app.get("/api/executions/recent", async (req, res) => {
  try {
    const raw = await fs.promises.readFile(path.join(DATA_DIR, "execution-log.json"), "utf8");
    const history = JSON.parse(raw);
    const recent = history.slice(-5).reverse();
    res.json(recent);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});
