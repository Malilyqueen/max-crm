export default {
  activeBrains: ['logistique', 'coach', 'ecommerce'],
  mcpLite: false,
  mode: 'auto' // 'ro', 'assist', 'auto'
};
