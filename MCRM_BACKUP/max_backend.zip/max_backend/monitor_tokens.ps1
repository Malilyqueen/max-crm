# Script de monitoring de la consommation de tokens M.A.X.
# Exécuter régulièrement pour détecter les dérives

$HEALTH_URL = "http://127.0.0.1:3005/api/health"

Write-Host "=== Monitoring Tokens M.A.X. ===" -ForegroundColor Cyan
Write-Host ""

try {
    $response = Invoke-RestMethod -Uri $HEALTH_URL -Method Get -TimeoutSec 5

    if ($response.ok) {
        $usage = $response.tokens

        # Calculs
        $remaining = $usage.budgetTotal - $usage.total
        $percentUsed = ($usage.total / $usage.budgetTotal) * 100
        $percentRemaining = 100 - $percentUsed
        $estimatedTasksRemaining = [math]::Floor($remaining / $usage.avgTokensPerTask)

        # Affichage
        Write-Host "📊 Budget Total: $($usage.budgetTotal | Out-String) tokens" -ForegroundColor White
        Write-Host ""

        Write-Host "✅ Tokens utilisés: $($usage.total) ($([math]::Round($percentUsed, 2))%)" -ForegroundColor $(if ($percentUsed -lt 50) { "Green" } elseif ($percentUsed -lt 80) { "Yellow" } else { "Red" })
        Write-Host "🔋 Tokens restants: $remaining ($([math]::Round($percentRemaining, 2))%)" -ForegroundColor $(if ($percentRemaining -gt 50) { "Green" } elseif ($percentRemaining -gt 20) { "Yellow" } else { "Red" })
        Write-Host ""

        Write-Host "📈 Nombre de calls: $($usage.calls)" -ForegroundColor Gray
        Write-Host "📊 Moyenne par tâche: $($usage.avgTokensPerTask) tokens" -ForegroundColor $(if ($usage.avgTokensPerTask -lt 6000) { "Green" } elseif ($usage.avgTokensPerTask -lt 10000) { "Yellow" } else { "Red" })
        Write-Host "💰 Coût total: `$$([math]::Round($usage.costUsd, 4)) USD" -ForegroundColor Cyan
        Write-Host ""

        Write-Host "🎯 Tâches restantes estimées: ~$estimatedTasksRemaining" -ForegroundColor White
        Write-Host ""

        # Analyse et alertes
        Write-Host "=== Analyse ===" -ForegroundColor Cyan
        Write-Host ""

        $efficiency = "UNKNOWN"
        $efficiencyColor = "Gray"

        if ($usage.avgTokensPerTask -lt 6000) {
            $efficiency = "🟢 EXCELLENT"
            $efficiencyColor = "Green"
            Write-Host "Efficacité: $efficiency" -ForegroundColor $efficiencyColor
            Write-Host "✓ Consommation optimale" -ForegroundColor Green
        }
        elseif ($usage.avgTokensPerTask -lt 8000) {
            $efficiency = "🟡 BON"
            $efficiencyColor = "Yellow"
            Write-Host "Efficacité: $efficiency" -ForegroundColor $efficiencyColor
            Write-Host "✓ Consommation acceptable" -ForegroundColor Yellow
        }
        elseif ($usage.avgTokensPerTask -lt 10000) {
            $efficiency = "🟠 MOYEN"
            $efficiencyColor = "DarkYellow"
            Write-Host "Efficacité: $efficiency" -ForegroundColor $efficiencyColor
            Write-Host "⚠ Consommation à surveiller" -ForegroundColor DarkYellow
            Write-Host "→ Vérifier agent_identity.json" -ForegroundColor Gray
        }
        else {
            $efficiency = "🔴 FAIBLE"
            $efficiencyColor = "Red"
            Write-Host "Efficacité: $efficiency" -ForegroundColor $efficiencyColor
            Write-Host "❌ Consommation excessive détectée!" -ForegroundColor Red
            Write-Host ""
            Write-Host "Actions recommandées:" -ForegroundColor Yellow
            Write-Host "1. Vérifier agent_identity.json pour instructions contradictoires" -ForegroundColor White
            Write-Host "2. Analyser les logs pour détecter des boucles" -ForegroundColor White
            Write-Host "3. Réduire MAX_RESPONSE_TOKENS dans .env" -ForegroundColor White
            Write-Host "4. Consulter docs/TOKEN_OPTIMIZATION.md" -ForegroundColor White
        }

        Write-Host ""

        # Alertes spécifiques
        if ($percentUsed -gt 80) {
            Write-Host "⚠️ ALERTE: Budget à 80%+ consommé!" -ForegroundColor Red
            Write-Host "→ Envisager de réinitialiser ou augmenter le budget" -ForegroundColor Gray
        }

        if ($estimatedTasksRemaining -lt 50) {
            Write-Host "⚠️ ALERTE: Moins de 50 tâches restantes" -ForegroundColor Red
            Write-Host "→ Budget presque épuisé" -ForegroundColor Gray
        }

        # Détail des tokens
        Write-Host ""
        Write-Host "=== Détail ===" -ForegroundColor Cyan
        Write-Host "Input tokens:  $($usage.inputTotal)" -ForegroundColor Gray
        Write-Host "Output tokens: $($usage.outputTotal)" -ForegroundColor Gray
        Write-Host "Ratio I/O:     $([math]::Round($usage.inputTotal / $usage.outputTotal, 2)):1" -ForegroundColor Gray

    } else {
        Write-Host "❌ Serveur ne répond pas correctement" -ForegroundColor Red
    }

} catch {
    Write-Host "❌ Erreur de connexion au serveur M.A.X." -ForegroundColor Red
    Write-Host "   $($_.Exception.Message)" -ForegroundColor Gray
    Write-Host ""
    Write-Host "Vérifier que le serveur est démarré:" -ForegroundColor Yellow
    Write-Host "   cd d:\Macrea\CRM\max_backend" -ForegroundColor White
    Write-Host "   node server.js" -ForegroundColor White
}

Write-Host ""
Write-Host "=== Fin du monitoring ===" -ForegroundColor Cyan
Write-Host ""
