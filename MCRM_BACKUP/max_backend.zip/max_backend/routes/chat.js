/**
 * chat.js
 *
 * Routes API pour le Chat M.A.X.
 * - POST /api/chat - Envoyer un message et recevoir réponse
 * - GET /api/chat/sessions - Lister les sessions
 * - GET /api/chat/session/:id - Charger une session
 * - POST /api/chat/session - Créer nouvelle session
 * - DELETE /api/chat/session/:id - Supprimer session
 */

import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// import { callHaiku } from '../lib/aiClient.js'; // COMMENTÉ pour test GPT-4 mini
import { callOpenAI } from '../lib/aiClient.js';
import {
  createSession,
  loadConversation,
  saveMessage,
  getContextMessages,
  summarizeIfNeeded,
  listSessions,
  deleteSession,
  updateSessionMode
} from '../lib/conversationService.js';
import { analyzeFile, generateEnrichmentQuestions } from '../lib/fileAnalyzer.js';
import { enrichDataset, askForContext } from '../lib/dataEnricher.js';
import { importEnrichedDataset, importLeads } from '../lib/espoImporter.js';
import { detectState, extractContextData } from '../lib/contextDetector.js';
import { getButtonsForState } from '../lib/actionMapper.js';
import { detectOperationMode, storeLeadContext, getActiveLeadContext, clearImportContext } from '../lib/sessionContext.js';
import { batchUpsertLeads, upsertLead, validateMinimalLead, findExistingLead } from '../lib/leadUpsert.js';
import { formatEnrichedLead, generateUpdateDiff, FIELD_MAPPING } from '../lib/fieldMapping.js';
import { espoFetch, espoAdminFetch } from '../lib/espoClient.js';
import { addFieldToAllLayouts } from '../lib/layoutManager.js';
import { espoRebuild, espoClearCache } from '../lib/phpExecutor.js';
import { logMaxActivity } from '../lib/activityLogger.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Charger le PROMPT_SYSTEM_MAX v2 (Admin Opérateur) + Règles opérationnelles
const PROMPT_SYSTEM_MAX = fs.readFileSync(
  path.join(__dirname, '..', 'prompts', 'max_system_prompt_v2.txt'),
  'utf-8'
);

const OPERATIONAL_RULES = fs.readFileSync(
  path.join(__dirname, '..', 'prompts', 'max_operational_rules.txt'),
  'utf-8'
);

// Combiner les prompts
const FULL_SYSTEM_PROMPT = `${PROMPT_SYSTEM_MAX}

${OPERATIONAL_RULES}`;

const router = express.Router();

// Configuration multer pour upload fichiers
const UPLOADS_DIR = path.join(__dirname, '..', 'uploads');
if (!fs.existsSync(UPLOADS_DIR)) {
  fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, UPLOADS_DIR);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, `${uniqueSuffix}-${file.originalname}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB max
  fileFilter: (req, file, cb) => {
    const allowedTypes = ['.csv', '.xlsx', '.xls'];
    const ext = path.extname(file.originalname).toLowerCase();
    if (allowedTypes.includes(ext)) {
      cb(null, true);
    } else {
      cb(new Error('Seuls les fichiers CSV et Excel sont acceptés'));
    }
  }
});

/**
 * Import des Tools M.A.X. depuis lib/maxTools.js
 */
import { MAX_TOOLS } from '../lib/maxTools.js';

/**
 * Exécuter un tool call
 */
async function executeToolCall(toolName, args, sessionId) {
  const conversation = loadConversation(sessionId);

  if (!conversation) {
    throw new Error('Session introuvable');
  }

  switch (toolName) {
    case 'get_uploaded_file_data': {
      if (!conversation.uploadedFile || !conversation.uploadedFile.analysis) {
        return {
          error: 'Aucun fichier uploadé dans cette session',
          hasFile: false
        };
      }

      const { analysis, filename } = conversation.uploadedFile;
      return {
        success: true,
        filename,
        rowCount: analysis.summary.rowCount,
        columns: analysis.columns.map(c => ({
          name: c.name,
          completionRate: c.completionRate,
          type: c.type
        })),
        sampleData: analysis.data.slice(0, 5)
      };
    }

    case 'enrich_and_import_leads': {
      if (!conversation.uploadedFile || !conversation.uploadedFile.analysis) {
        return {
          error: 'Aucun fichier à enrichir',
          success: false
        };
      }

      const { context } = args;
      const { analysis } = conversation.uploadedFile;

      // Enrichir les données
      const enrichmentResult = await enrichDataset(analysis.data, context);

      // Sauvegarder dans la session
      conversation.enrichedData = {
        enrichedLeads: enrichmentResult.enrichedLeads,
        enrichmentData: enrichmentResult.enrichmentData,
        stats: enrichmentResult.stats,
        context: context,
        enrichedAt: new Date().toISOString()
      };

      const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
      fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));

      return {
        success: true,
        enrichedCount: enrichmentResult.enrichedLeads.length,
        tags: enrichmentResult.enrichmentData.tags,
        status: enrichmentResult.enrichmentData.status,
        source: enrichmentResult.enrichmentData.source
      };
    }

    case 'import_leads_to_crm': {
      if (!conversation.enrichedData) {
        return {
          error: 'Aucune donnée enrichie à importer',
          success: false
        };
      }

      const importResult = await importEnrichedDataset(conversation.enrichedData);

      // Marquer la session comme importée
      if (importResult.ok) {
        conversation.imported = true;
        conversation.importedAt = new Date().toISOString();
        const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
        fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));
      }

      return {
        success: importResult.ok,
        stats: importResult.stats
      };
    }

    case 'propose_actions': {
      // Sauvegarder les actions proposées dans la session
      const { actions } = args;

      conversation.proposedActions = actions.map((action, index) => ({
        ...action,
        timestamp: new Date().toISOString(),
        id: action.id || `action_${Date.now()}_${index}`
      }));

      const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
      fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));

      return {
        success: true,
        actionsCount: actions.length,
        actions: conversation.proposedActions
      };
    }

    case 'query_espo_leads': {
      const { filters = {}, limit = 10, sortBy = 'createdAt', sortOrder = 'desc' } = args;

      try {
        // Construire la requête EspoCRM
        const params = new URLSearchParams({
          maxSize: limit.toString(),
          orderBy: sortBy,
          order: sortOrder
        });

        // Ajouter filtres si présents
        if (Object.keys(filters).length > 0) {
          params.append('where', JSON.stringify([filters]));
        }

        const response = await espoFetch(`/Lead?${params.toString()}`);

        // Mémoriser les IDs dans la session
        const leadIds = response.list.map(lead => lead.id);
        storeLeadContext(conversation, leadIds);

        const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
        fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));

        return {
          success: true,
          total: response.total,
          count: response.list.length,
          leads: response.list.map(lead => ({
            id: lead.id,
            name: `${lead.firstName || ''} ${lead.lastName || ''}`.trim(),
            email: lead.emailAddress,
            accountName: lead.accountName,
            createdAt: lead.createdAt
          })),
          leadIds
        };
      } catch (error) {
        console.error('[query_espo_leads] Erreur:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    case 'update_leads_in_espo': {
      const { leadIds, updates, mode = 'update_only' } = args;

      try {
        // Récupérer les IDs des leads à mettre à jour
        let targetLeadIds = leadIds;

        if (!targetLeadIds || targetLeadIds.length === 0) {
          // Utiliser le contexte mémorisé
          targetLeadIds = getActiveLeadContext(conversation);

          if (!targetLeadIds || targetLeadIds.length === 0) {
            return {
              success: false,
              error: 'Aucun lead ciblé. Utilisez d\'abord query_espo_leads ou fournissez leadIds.'
            };
          }
        }

        // Charger les leads depuis EspoCRM
        const leadsToUpdate = [];
        for (const id of targetLeadIds) {
          try {
            const lead = await espoFetch(`/Lead/${id}`);
            leadsToUpdate.push({ ...lead, ...updates });
          } catch (error) {
            console.error(`[update_leads_in_espo] Erreur chargement lead ${id}:`, error);
          }
        }

        if (leadsToUpdate.length === 0) {
          return {
            success: false,
            error: 'Aucun lead trouvé à mettre à jour'
          };
        }

        // Formatter les leads (mapping propre)
        const formattedLeads = leadsToUpdate.map(lead => formatEnrichedLead(lead));

        // Upsert avec rapport
        const forceCreate = mode === 'force_create';
        const report = await batchUpsertLeads(formattedLeads, { forceCreate });

        return {
          success: true,
          mode,
          targetCount: targetLeadIds.length,
          updated: report.updated,
          created: report.created,
          skipped: report.skipped,
          pendingConfirmation: report.pendingConfirmation,
          details: report.details
        };
      } catch (error) {
        console.error('[update_leads_in_espo] Erreur:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    case 'delete_leads_from_espo': {
      const { leadIds, confirm = false } = args;

      if (!confirm) {
        return {
          success: false,
          requiresConfirmation: true,
          message: `Suppression de ${leadIds.length} leads. Confirmez avec confirm: true`
        };
      }

      try {
        const deleted = [];
        const errors = [];

        for (const id of leadIds) {
          try {
            await espoFetch(`/Lead/${id}`, { method: 'DELETE' });
            deleted.push(id);
          } catch (error) {
            errors.push({ id, error: error.message });
          }
        }

        return {
          success: true,
          deleted: deleted.length,
          errors: errors.length,
          deletedIds: deleted,
          errorDetails: errors
        };
      } catch (error) {
        console.error('[delete_leads_from_espo] Erreur:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    case 'get_lead_diff': {
      const { leadId, proposedUpdates } = args;

      try {
        // Charger le lead existant
        const existingLead = await espoFetch(`/Lead/${leadId}`);

        // Générer le diff
        const diff = generateUpdateDiff(existingLead, proposedUpdates);

        return {
          success: true,
          leadId,
          leadName: `${existingLead.firstName || ''} ${existingLead.lastName || ''}`.trim(),
          diff: {
            added: diff.added,
            modified: diff.modified,
            unchanged: diff.unchanged
          }
        };
      } catch (error) {
        console.error('[get_lead_diff] Erreur:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    case 'create_custom_field': {
      const {
        entity = 'Lead',
        fieldName,
        label,
        type,
        options,
        maxLength,
        min,
        max
      } = args;

      try {
        console.log(`[create_custom_field] Création champ ${fieldName} (${type}) sur ${entity}`);

        // Construire le payload selon les spécifications EspoCRM
        const payload = {
          name: fieldName,
          label: label,
          type: type,
          isCustom: true
        };

        // Ajouter les propriétés spécifiques selon le type
        if (type === 'enum' || type === 'multiEnum') {
          if (options && options.length > 0) {
            payload.options = options;
          } else {
            return {
              success: false,
              error: `Le type ${type} nécessite un paramètre 'options' (array de strings)`
            };
          }
        }

        if (type === 'varchar' && maxLength) {
          payload.maxLength = maxLength;
        }

        if ((type === 'int' || type === 'float') && (min !== undefined || max !== undefined)) {
          if (min !== undefined) payload.min = min;
          if (max !== undefined) payload.max = max;
        }

        // Utiliser l'API Admin pour créer le champ
        const result = await espoAdminFetch(`/Admin/fieldManager/${entity}/${fieldName}`, {
          method: 'PUT',
          body: JSON.stringify(payload)
        });

        console.log(`[create_custom_field] Champ ${fieldName} créé avec succès`);

        return {
          success: true,
          entity,
          fieldName,
          label,
          type,
          message: `Champ custom "${label}" (${fieldName}) créé avec succès sur ${entity}`,
          details: result
        };
      } catch (error) {
        console.error('[create_custom_field] Erreur:', error);
        return {
          success: false,
          error: error.message,
          hint: 'Vérifiez que les credentials admin sont configurés dans ESPO_USERNAME/ESPO_PASSWORD'
        };
      }
    }

    case 'update_lead_fields': {
      const { leads, fields } = args;

      try {
        console.log(`[update_lead_fields] Mise à jour de ${leads.length} lead(s)`);

        const results = [];
        const missingFields = [];

        for (const leadInfo of leads) {
          try {
            // 1. Résoudre le lead par ID ou nom/email
            let leadId = leadInfo.id;
            let leadData = null;

            if (!leadId && (leadInfo.name || leadInfo.email)) {
              // Résolution par nom/email
              console.log(`[update_lead_fields] Résolution de "${leadInfo.name || leadInfo.email}"`);

              let searchParams = new URLSearchParams({
                maxSize: '1'
              });

              if (leadInfo.email) {
                searchParams.append('where[0][type]', 'equals');
                searchParams.append('where[0][attribute]', 'emailAddress');
                searchParams.append('where[0][value]', leadInfo.email);
              } else if (leadInfo.name) {
                searchParams.append('where[0][type]', 'equals');
                searchParams.append('where[0][attribute]', 'name');
                searchParams.append('where[0][value]', leadInfo.name);
              }

              const searchResult = await espoFetch(`/Lead?${searchParams.toString()}`);

              if (searchResult && searchResult.list && searchResult.list.length > 0) {
                leadData = searchResult.list[0];
                leadId = leadData.id;
                console.log(`[update_lead_fields] Lead résolu: ${leadData.name} (${leadId})`);
              } else {
                results.push({
                  success: false,
                  lead: leadInfo.name || leadInfo.email,
                  error: '404 - Lead introuvable'
                });
                continue;
              }
            } else if (leadId) {
              // Charger le lead par ID pour obtenir les infos complètes
              try {
                leadData = await espoFetch(`/Lead/${leadId}`);
              } catch (error) {
                if (error.message.includes('404')) {
                  results.push({
                    success: false,
                    lead: leadId,
                    error: '404 - Lead introuvable'
                  });
                  continue;
                }
                throw error;
              }
            }

            // 2. Vérifier les champs custom existent
            const fieldsToCheck = ['maxTags', 'objectifsBusiness', 'servicesSouhaites', 'statutActions', 'prochainesEtapes'];
            for (const field of Object.keys(fields)) {
              if (fieldsToCheck.includes(field) && leadData[field] === undefined) {
                missingFields.push(field);
              }
            }

            // 3. PATCH partiel du lead
            const updated = await espoFetch(`/Lead/${leadId}`, {
              method: 'PATCH',
              body: JSON.stringify(fields)
            });

            results.push({
              success: true,
              lead: leadData.name,
              email: leadData.emailAddress,
              account: leadData.accountName,
              tags: updated.maxTags || fields.maxTags || [],
              objectifs: updated.objectifsBusiness || fields.objectifsBusiness || '',
              services: updated.servicesSouhaites || fields.servicesSouhaites || '',
              statut: updated.statutActions || fields.statutActions || '',
              prochaines: updated.prochainesEtapes || fields.prochainesEtapes || '',
              modifiedAt: updated.modifiedAt || new Date().toISOString()
            });

            console.log(`[update_lead_fields] Lead ${leadData.name} mis à jour avec succès`);

          } catch (error) {
            console.error(`[update_lead_fields] Erreur lead:`, error);
            results.push({
              success: false,
              lead: leadInfo.name || leadInfo.email || leadInfo.id,
              error: error.message
            });
          }
        }

        // 4. Si des champs manquent, les créer automatiquement
        if (missingFields.length > 0) {
          const uniqueFields = [...new Set(missingFields)];
          console.log(`[update_lead_fields] Champs manquants détectés: ${uniqueFields.join(', ')}`);

          const fieldMappings = {
            maxTags: { label: 'Tags MAX', type: 'array' },
            objectifsBusiness: { label: 'Objectifs Business', type: 'text' },
            servicesSouhaites: { label: 'Services Souhaités', type: 'text' },
            statutActions: { label: 'Statut des Actions', type: 'varchar' },
            prochainesEtapes: { label: 'Prochaines Étapes', type: 'text' }
          };

          for (const fieldName of uniqueFields) {
            const fieldDef = fieldMappings[fieldName];
            if (fieldDef) {
              try {
                await espoAdminFetch(`/Admin/fieldManager/Lead/${fieldName}`, {
                  method: 'PUT',
                  body: JSON.stringify({
                    name: fieldName,
                    label: fieldDef.label,
                    type: fieldDef.type,
                    isCustom: true
                  })
                });
                console.log(`[update_lead_fields] Champ ${fieldName} créé automatiquement`);
              } catch (error) {
                console.error(`[update_lead_fields] Erreur création champ ${fieldName}:`, error);
              }
            }
          }

          return {
            success: false,
            message: 'Champs manquants créés. Veuillez rejouer la mise à jour.',
            createdFields: uniqueFields,
            results
          };
        }

        // 5. Retourner le résumé
        const successCount = results.filter(r => r.success).length;
        const errorCount = results.filter(r => !r.success).length;

        return {
          success: true,
          updated: successCount,
          errors: errorCount,
          results
        };

      } catch (error) {
        console.error('[update_lead_fields] Erreur globale:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    case 'get_lead_snapshot': {
      const { leads } = args;

      try {
        console.log(`[get_lead_snapshot] Snapshot de ${leads.length} lead(s)`);

        const snapshots = [];

        for (const leadInfo of leads) {
          try {
            // Résoudre le lead
            let leadId = leadInfo.id;
            let leadData = null;

            if (!leadId && (leadInfo.name || leadInfo.email)) {
              let searchParams = new URLSearchParams({ maxSize: '1' });

              if (leadInfo.email) {
                searchParams.append('where[0][type]', 'equals');
                searchParams.append('where[0][attribute]', 'emailAddress');
                searchParams.append('where[0][value]', leadInfo.email);
              } else if (leadInfo.name) {
                searchParams.append('where[0][type]', 'equals');
                searchParams.append('where[0][attribute]', 'name');
                searchParams.append('where[0][value]', leadInfo.name);
              }

              const searchResult = await espoFetch(`/Lead?${searchParams.toString()}`);

              if (searchResult && searchResult.list && searchResult.list.length > 0) {
                leadData = searchResult.list[0];
                leadId = leadData.id;
              } else {
                snapshots.push({
                  success: false,
                  lead: leadInfo.name || leadInfo.email,
                  error: 'Lead introuvable'
                });
                continue;
              }
            } else if (leadId) {
              try {
                leadData = await espoFetch(`/Lead/${leadId}`);
              } catch (error) {
                snapshots.push({
                  success: false,
                  lead: leadId,
                  error: 'Lead introuvable (404)'
                });
                continue;
              }
            }

            // Créer le snapshot avec les 5 champs clés
            snapshots.push({
              success: true,
              nom: leadData.name || '',
              email: leadData.emailAddress || '',
              compte: leadData.accountName || '',
              tags: leadData.maxTags || [],
              objectifs: leadData.objectifsBusiness || '',
              services: leadData.servicesSouhaites || '',
              statut: leadData.statutActions || '',
              prochaines: leadData.prochainesEtapes || '',
              modifiedAt: leadData.modifiedAt || ''
            });

          } catch (error) {
            console.error(`[get_lead_snapshot] Erreur:`, error);
            snapshots.push({
              success: false,
              lead: leadInfo.name || leadInfo.email || leadInfo.id,
              error: error.message
            });
          }
        }

        return {
          success: true,
          count: snapshots.length,
          snapshots
        };

      } catch (error) {
        console.error('[get_lead_snapshot] Erreur globale:', error);
        return {
          success: false,
          error: error.message
        };
      }
    }

    case 'configure_entity_layout': {
      const { entity = 'Lead', fieldName, createField = false, fieldDefinition = {} } = args;

      // Validate fieldName parameter
      if (!fieldName || typeof fieldName !== 'string' || fieldName.trim() === '' || fieldName === 'undefined' || fieldName === 'null') {
        console.error(`[configure_entity_layout] Invalid fieldName: "${fieldName}"`);
        return {
          success: false,
          error: `Invalid fieldName parameter: "${fieldName}". Field name must be a non-empty string and cannot be "undefined" or "null". Please provide a valid field name.`,
          entity,
          fieldName
        };
      }

      try {
        console.log(`[configure_entity_layout] Configuration complète pour ${fieldName} sur ${entity}`);

        const results = {
          steps: []
        };

        // Étape 1: Créer le champ si demandé
        if (createField) {
          console.log(`[configure_entity_layout] Création du champ ${fieldName}...`);

          const fieldDef = {
            type: fieldDefinition.type || 'varchar',
            maxLength: fieldDefinition.maxLength || 255,
            isCustom: true,
            ...fieldDefinition
          };

          try {
            await espoAdminFetch(`/Admin/fieldManager/${entity}/${fieldName}`, {
              method: 'PUT',
              body: JSON.stringify(fieldDef)
            });

            results.steps.push({ step: 'create_field', success: true, field: fieldName });
          } catch (error) {
            // Ignorer si le champ existe déjà
            if (error.message.includes('409') || error.message.includes('exists')) {
              results.steps.push({ step: 'create_field', success: true, field: fieldName, note: 'Already exists' });
            } else {
              throw error;
            }
          }
        }

        // Étape 2: Ajouter le champ aux layouts
        console.log(`[configure_entity_layout] Ajout de ${fieldName} aux layouts...`);

        const layoutResult = await addFieldToAllLayouts(entity, fieldName, {
          fullWidth: fieldDefinition.fullWidth !== false,
          listWidth: fieldDefinition.listWidth || 10
        });

        results.steps.push({
          step: 'add_to_layouts',
          success: layoutResult.success,
          layoutResults: layoutResult.results
        });

        // Étape 3: Clear cache
        console.log(`[configure_entity_layout] Nettoyage du cache...`);
        const cacheResult = await espoClearCache();
        results.steps.push({
          step: 'clear_cache',
          success: cacheResult.success,
          output: cacheResult.output
        });

        // Étape 4: Rebuild
        console.log(`[configure_entity_layout] Rebuild EspoCRM...`);
        const rebuildResult = await espoRebuild();
        results.steps.push({
          step: 'rebuild',
          success: rebuildResult.success,
          output: rebuildResult.output
        });

        const allSuccess = results.steps.every(step => step.success);

        return {
          success: allSuccess,
          message: allSuccess
            ? `Champ ${fieldName} configuré avec succès sur ${entity}. Layouts mis à jour et rebuild terminé.`
            : `Configuration partiellement terminée. Certaines étapes ont échoué.`,
          entity,
          fieldName,
          steps: results.steps
        };

      } catch (error) {
        console.error('[configure_entity_layout] Erreur:', error);
        return {
          success: false,
          error: error.message,
          entity,
          fieldName
        };
      }
    }

    default:
      throw new Error(`Tool inconnu: ${toolName}`);
  }
}

/**
 * POST /api/chat
 * Envoyer un message et recevoir la réponse de M.A.X.
 *
 * Body: { sessionId?, message }
 */
router.post('/', async (req, res) => {
  try {
    const { sessionId: clientSessionId, message, mode = 'assisté' } = req.body;

    if (!message || typeof message !== 'string' || !message.trim()) {
      return res.status(400).json({ ok: false, error: 'Message requis' });
    }

    // Créer ou utiliser session existante
    let sessionId = clientSessionId;
    let conversation = clientSessionId ? loadConversation(clientSessionId) : null;

    if (!sessionId || !conversation) {
      sessionId = createSession(mode);
      conversation = loadConversation(sessionId);
      console.log(`[ChatRoute] Nouvelle session créée: ${sessionId} (mode: ${mode})`);
    } else if (conversation.mode !== mode) {
      // Mettre à jour le mode si changé
      updateSessionMode(sessionId, mode);
      conversation.mode = mode;
      console.log(`[ChatRoute] Mode mis à jour: ${sessionId} -> ${mode}`);
    }

    // Sauvegarder message utilisateur
    const userMessage = {
      role: 'user',
      content: message.trim(),
      timestamp: new Date().toISOString()
    };

    saveMessage(sessionId, userMessage);

    // Vérifier si résumé nécessaire (async, ne bloque pas la réponse)
    summarizeIfNeeded(sessionId).catch(err =>
      console.error('[ChatRoute] Erreur résumé:', err)
    );

    // Obtenir contexte pour l'IA (Function Calling gère maintenant l'enrichissement)
    const contextMessages = getContextMessages(sessionId);

    // System prompt pour M.A.X. (adapté au mode d'exécution)
    const currentMode = conversation.mode || 'assisté';

    let modeInstructions = '';
    if (currentMode === 'assisté') {
      modeInstructions = `\n\n⚠️ MODE ASSISTÉ ACTIF:
- TOUJOURS demander confirmation explicite avant d'exécuter toute action (import CRM, création campagne, modifications données)
- Utiliser des formulations comme: "Souhaitez-vous que j'insère ces leads dans EspoCRM?" ou "Dois-je procéder à l'import?"
- JAMAIS simuler ou annoncer qu'une action a été faite sans confirmation utilisateur
- Marquer clairement les actions RÉELLES avec ✅ et les suggestions avec 💡`;
    } else if (currentMode === 'auto') {
      modeInstructions = `\n\n⚡ MODE AUTO ACTIF:
- Exécuter automatiquement les actions appropriées quand le contexte est clair
- Annoncer l'action avant de l'exécuter
- Marquer clairement les actions RÉELLES avec ✅ ACTION EXÉCUTÉE
- Toujours fournir des liens directs vers les ressources créées (EspoCRM, etc.)`;
    } else if (currentMode === 'conseil') {
      modeInstructions = `\n\n💡 MODE CONSEIL ACTIF:
- UNIQUEMENT fournir des conseils, recommandations et stratégies
- JAMAIS exécuter d'actions réelles
- JAMAIS simuler ou annoncer qu'une action a été faite
- Toujours marquer tes réponses avec 💡 SUGGESTION
- Si l'utilisateur demande une action, expliquer que le mode Conseil ne permet pas l'exécution`;
    }

    // Contexte session pour informer M.A.X. de l'état actuel
    let sessionContext = '';
    if (conversation.enrichedData && conversation.imported) {
      sessionContext = `\n\n📌 CONTEXTE SESSION ACTUEL:
- Un fichier CSV a été uploadé et analysé
- Les leads ont été enrichis avec succès
- ✅ L'IMPORT DANS ESPOCRM A DÉJÀ ÉTÉ EFFECTUÉ le ${new Date(conversation.importedAt).toLocaleString('fr-FR')}
- Les leads sont maintenant dans le CRM et prêts pour la prospection
- NE PROPOSE PLUS l'import, il est déjà fait !`;
    } else if (conversation.enrichedData) {
      sessionContext = `\n\n📌 CONTEXTE SESSION ACTUEL:
- Un fichier CSV a été uploadé et analysé
- Les leads ont été enrichis avec succès
- ⏳ L'import dans EspoCRM est en attente de confirmation utilisateur`;
    } else if (conversation.uploadedFile) {
      sessionContext = `\n\n📌 CONTEXTE SESSION ACTUEL:
- Un fichier CSV a été uploadé et analysé
- Les leads sont prêts à être enrichis dès que l'utilisateur fournira le contexte (secteur, origine, etc.)`;
    }

    // Utiliser le prompt complet avec les règles opérationnelles
    const systemPrompt = `${FULL_SYSTEM_PROMPT}${sessionContext}${modeInstructions}`;

    // Appeler GPT-4 mini (OpenAI) avec support Function Calling
    let result = await callOpenAI({
      system: systemPrompt,
      messages: contextMessages,
      max_tokens: 1024,
      temperature: 0.7,
      tools: MAX_TOOLS
    });

    /* CLAUDE HAIKU (commenté)
    const result = await callHaiku({
      system: systemPrompt,
      messages: contextMessages,
      max_tokens: 1024,
      temperature: 0.7
    });
    */

    // Gérer les tool_calls si présents
    if (result.tool_calls && result.tool_calls.length > 0) {
      console.log(`[ChatRoute] Tool calls détectés: ${result.tool_calls.map(tc => tc.function.name).join(', ')}`);

      // Exécuter chaque tool call
      const toolResults = [];
      for (const toolCall of result.tool_calls) {
        const toolName = toolCall.function.name;
        const args = JSON.parse(toolCall.function.arguments);

        console.log(`[ChatRoute] Exécution tool: ${toolName}`, args);

        try {
          const toolResult = await executeToolCall(toolName, args, sessionId);
          toolResults.push({
            tool_call_id: toolCall.id,
            role: 'tool',
            name: toolName,
            content: JSON.stringify(toolResult)
          });
        } catch (toolError) {
          console.error(`[ChatRoute] Erreur tool ${toolName}:`, toolError);
          toolResults.push({
            tool_call_id: toolCall.id,
            role: 'tool',
            name: toolName,
            content: JSON.stringify({ error: toolError.message })
          });
        }
      }

      // Ajouter le message assistant avec tool_calls et les résultats au contexte
      const messagesWithTools = [
        ...contextMessages,
        {
          role: 'assistant',
          content: result.text || null,
          tool_calls: result.tool_calls
        },
        ...toolResults
      ];

      // Rappeler l'IA avec les résultats des tools
      result = await callOpenAI({
        system: systemPrompt,
        messages: messagesWithTools,
        max_tokens: 1024,
        temperature: 0.7,
        tools: MAX_TOOLS
      });
    }

    // Sauvegarder réponse assistant
    const assistantMessage = {
      role: 'assistant',
      content: result.text,
      timestamp: new Date().toISOString(),
      tokens: result.usage
    };

    saveMessage(sessionId, assistantMessage);

    // 🚀 DÉTECTION AUTOMATIQUE DE L'ÉTAT ET GÉNÉRATION DES BOUTONS
    // Analyser le message de M.A.X. pour détecter l'état de la conversation
    const detectedState = detectState(result.text);
    const contextData = extractContextData(result.text);

    console.log(`[ChatRoute] État détecté: ${detectedState}`, contextData);

    // Générer les boutons appropriés selon l'état détecté
    let actions = undefined;
    if (currentMode === 'assisté' || currentMode === 'auto') {
      const buttons = getButtonsForState(detectedState, contextData);

      if (buttons && buttons.length > 0) {
        actions = buttons.map(btn => ({
          label: btn.label,
          action: btn.action,
          style: btn.style || 'secondary',
          description: btn.description,
          data: { sessionId }
        }));
      }
    }

    // Retourner réponse M.A.X. avec boutons contextuels automatiques
    res.json({
      ok: true,
      sessionId,
      response: result.text,
      actions,
      state: detectedState,
      tokens: result.usage,
      messageCount: loadConversation(sessionId)?.messages.length || 0
    });

  } catch (error) {
    console.error('[ChatRoute] Erreur:', error);

    // Gestion erreur budget
    if (error.code === 'BUDGET_EXCEEDED') {
      return res.status(429).json({
        ok: false,
        error: 'Budget tokens IA dépassé. Contactez votre administrateur.',
        code: 'BUDGET_EXCEEDED'
      });
    }

    res.status(500).json({
      ok: false,
      error: error.message || 'Erreur lors du traitement du message'
    });
  }
});

/**
 * GET /api/chat/sessions
 * Lister toutes les sessions de conversation
 */
router.get('/sessions', (req, res) => {
  try {
    const sessions = listSessions();
    res.json({ ok: true, sessions });
  } catch (error) {
    console.error('[ChatRoute] Erreur listage sessions:', error);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * GET /api/chat/session/:id
 * Charger une session spécifique
 */
router.get('/session/:id', (req, res) => {
  try {
    const { id } = req.params;
    const conversation = loadConversation(id);

    if (!conversation) {
      return res.status(404).json({ ok: false, error: 'Session introuvable' });
    }

    res.json({ ok: true, conversation });
  } catch (error) {
    console.error('[ChatRoute] Erreur chargement session:', error);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * POST /api/chat/session
 * Créer une nouvelle session
 */
router.post('/session', (req, res) => {
  try {
    const sessionId = createSession();
    res.json({ ok: true, sessionId });
  } catch (error) {
    console.error('[ChatRoute] Erreur création session:', error);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * DELETE /api/chat/session/:id
 * Supprimer une session
 */
router.delete('/session/:id', (req, res) => {
  try {
    const { id } = req.params;
    const deleted = deleteSession(id);

    if (!deleted) {
      return res.status(404).json({ ok: false, error: 'Session introuvable' });
    }

    res.json({ ok: true, message: 'Session supprimée' });
  } catch (error) {
    console.error('[ChatRoute] Erreur suppression session:', error);
    res.status(500).json({ ok: false, error: error.message });
  }
});

/**
 * POST /api/chat/upload
 * Upload et analyse d'un fichier CSV/Excel
 *
 * Body: multipart/form-data
 * - file: Fichier CSV/Excel
 * - sessionId: ID de session (optionnel)
 * - context: Contexte utilisateur (optionnel)
 */
router.post('/upload', upload.single('file'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ ok: false, error: 'Fichier requis' });
    }

    const { sessionId: clientSessionId, context = '', mode = 'assisté' } = req.body;
    const { filename, originalname, path: filePath } = req.file;

    console.log(`[ChatRoute] Upload fichier: ${originalname} (${filename})`);

    // Créer ou utiliser session existante
    let sessionId = clientSessionId;
    let conversation = clientSessionId ? loadConversation(clientSessionId) : null;

    if (!sessionId || !conversation) {
      sessionId = createSession(mode);
      conversation = loadConversation(sessionId);
      console.log(`[ChatRoute] Nouvelle session créée: ${sessionId} (mode: ${mode})`);
    } else if (conversation.mode !== mode) {
      // Mettre à jour le mode si changé
      updateSessionMode(sessionId, mode);
      conversation.mode = mode;
      console.log(`[ChatRoute] Mode mis à jour: ${sessionId} -> ${mode}`);
    }

    // Lire et analyser le fichier
    const fileContent = fs.readFileSync(filePath);
    const analysis = await analyzeFile(fileContent, originalname);

    console.log(`[ChatRoute] Analyse terminée: ${analysis.summary.rowCount} lignes, ${analysis.summary.columnCount} colonnes`);

    // Générer message M.A.X. INTELLIGENT via IA avec PROMPT_SYSTEM_MAX
    const maxMessage = await generateAIAnalysisMessage(analysis, originalname);

    // Générer questions pour enrichissement
    const questions = generateEnrichmentQuestions(analysis);

    // Sauvegarder message utilisateur (upload)
    saveMessage(sessionId, {
      role: 'user',
      content: `[Fichier uploadé: ${originalname}]`,
      timestamp: new Date().toISOString(),
      attachments: [{
        name: originalname,
        type: req.file.mimetype,
        size: req.file.size,
        uploadedFilename: filename
      }]
    });

    // Sauvegarder réponse M.A.X.
    saveMessage(sessionId, {
      role: 'assistant',
      content: maxMessage,
      timestamp: new Date().toISOString(),
      metadata: {
        analysis: {
          rowCount: analysis.summary.rowCount,
          columnCount: analysis.summary.columnCount,
          quality: analysis.summary.quality,
          issues: analysis.summary.issues
        },
        questions
      },
      actions: generateFileActions(analysis, filename, conversation.mode || 'assisté')
    });

    // Stocker analyse dans session pour utilisation ultérieure
    if (conversation) {
      conversation.uploadedFile = {
        filename,
        originalname,
        analysis,
        uploadedAt: new Date().toISOString()
      };
      const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
      fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));
    }

    res.json({
      ok: true,
      sessionId,
      analysis: {
        summary: analysis.summary,
        columns: analysis.columns,
        missingFields: analysis.missingFields,
        quality: analysis.quality
      },
      message: maxMessage,
      questions,
      actions: generateFileActions(analysis, filename)
    });

  } catch (error) {
    console.error('[ChatRoute] Erreur upload:', error);
    res.status(500).json({
      ok: false,
      error: error.message || 'Erreur lors de l\'analyse du fichier'
    });
  }
});

/**
 * POST /api/chat/enrich
 * Enrichir les données avec le contexte utilisateur
 *
 * Body: { sessionId, context }
 */
router.post('/enrich', async (req, res) => {
  try {
    const { sessionId, context } = req.body;

    if (!sessionId || !context) {
      return res.status(400).json({ ok: false, error: 'Session et contexte requis' });
    }

    const conversation = loadConversation(sessionId);
    if (!conversation || !conversation.uploadedFile) {
      return res.status(400).json({ ok: false, error: 'Aucun fichier uploadé dans cette session' });
    }

    const { analysis, filename } = conversation.uploadedFile;

    console.log(`[ChatRoute] Enrichissement avec contexte: "${context.slice(0, 100)}..."`);

    // Enrichir les données
    const enrichmentResult = await enrichDataset(analysis.data, context);

    // Générer message M.A.X.
    const maxMessage = generateEnrichmentMessage(enrichmentResult, context, conversation.mode || 'assisté');

    // Sauvegarder message utilisateur (contexte)
    saveMessage(sessionId, {
      role: 'user',
      content: context,
      timestamp: new Date().toISOString()
    });

    // Adapter les actions selon le mode
    let actions = [];

    if (conversation.mode === 'assisté') {
      // Mode Assisté: Boutons de confirmation explicites
      actions = [
        {
          label: '✅ Oui, importer dans EspoCRM',
          action: 'confirm-import-espo',
          data: { sessionId }
        },
        {
          label: '❌ Non, ne pas importer',
          action: 'cancel-import',
          data: { sessionId }
        },
        {
          label: '📥 Télécharger CSV enrichi',
          action: 'download-enriched',
          data: { sessionId }
        }
      ];
    } else if (conversation.mode === 'auto') {
      // Mode Auto: Pas de boutons, l'import sera automatique
      actions = [];
    } else {
      // Mode Conseil: Seulement téléchargement
      actions = [
        {
          label: '💡 Télécharger CSV enrichi',
          action: 'download-enriched',
          data: { sessionId }
        }
      ];
    }

    // Sauvegarder réponse M.A.X.
    saveMessage(sessionId, {
      role: 'assistant',
      content: maxMessage,
      timestamp: new Date().toISOString(),
      metadata: {
        enrichment: enrichmentResult.stats
      },
      actions
    });

    // Stocker données enrichies dans session
    conversation.enrichedData = {
      leads: enrichmentResult.enrichedLeads,
      enrichmentData: enrichmentResult.enrichmentData,
      stats: enrichmentResult.stats,
      context,
      enrichedAt: new Date().toISOString()
    };

    const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
    fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));

    res.json({
      ok: true,
      sessionId,
      message: maxMessage,
      stats: enrichmentResult.stats,
      enrichmentData: enrichmentResult.enrichmentData,
      actions // Utiliser les actions définies selon le mode
    });

  } catch (error) {
    console.error('[ChatRoute] Erreur enrichissement:', error);
    res.status(500).json({
      ok: false,
      error: error.message || 'Erreur lors de l\'enrichissement'
    });
  }
});

/**
 * Génère un message d'analyse via IA (GPT-4 mini) avec PROMPT_SYSTEM_MAX
 * L'IA analyse les données et génère une réponse intelligente et proactive
 */
async function generateAIAnalysisMessage(analysis, filename) {
  const { summary, columns, missingFields, data } = analysis;

  // Préparer les données structurées pour l'IA
  const analysisData = {
    filename,
    rowCount: summary.rowCount,
    columnCount: summary.columnCount,
    columns: columns.map(c => ({
      name: c.name,
      completionRate: c.completionRate,
      type: c.type
    })),
    missingFields: missingFields.map(f => f.label),
    sampleData: data.slice(0, 3) // 3 premières lignes comme échantillon
  };

  // Appeler l'IA avec le FULL_SYSTEM_PROMPT (inclut règles opérationnelles)
  try {
    const result = await callOpenAI({
      system: FULL_SYSTEM_PROMPT,
      messages: [{
        role: 'user',
        content: `Un fichier CSV vient d'être uploadé. Voici l'analyse structurée:\n\n${JSON.stringify(analysisData, null, 2)}\n\nGénère ton message d'analyse intelligent selon les instructions du prompt système.`
      }],
      max_tokens: 512,
      temperature: 0.7
    });

    return result.text;
  } catch (error) {
    console.error('[generateAIAnalysisMessage] Erreur IA:', error);
    // Fallback vers la version JavaScript en cas d'erreur
    return generateAnalysisMessage(analysis);
  }
}

/**
 * Génère un message d'analyse INTELLIGENT - CONSTRUCTION DIRECTE (pas d'IA)
 * Plus fiable : pas d'hallucination possible sur les chiffres
 * FALLBACK utilisé uniquement si l'IA échoue
 */
function generateAnalysisMessage(analysis) {
  const { summary, columns, missingFields, quality, data } = analysis;

  // Analyse intelligente des données
  const rowCount = summary.rowCount;

  // DEBUG: Afficher les vraies valeurs
  console.log('[generateAnalysisMessage] summary.rowCount =', summary.rowCount);
  console.log('[generateAnalysisMessage] data.length =', data.length);

  // Détecter les champs critiques et leur complétude
  const emailCol = columns.find(c => c.name.toLowerCase().includes('email'));
  const phoneCol = columns.find(c => c.name.toLowerCase().includes('phone') || c.name.toLowerCase().includes('tel'));
  const titleCol = columns.find(c => c.name.toLowerCase().includes('title') || c.name.toLowerCase().includes('poste'));
  const companyCol = columns.find(c => c.name.toLowerCase().includes('company') || c.name.toLowerCase().includes('entreprise'));

  // Analyser les postes pour détecter décideurs
  let decideursCount = 0;
  if (titleCol) {
    data.forEach(row => {
      const title = (row[titleCol.name] || '').toLowerCase();
      if (title.includes('fondateur') || title.includes('propriétaire') ||
          title.includes('ceo') || title.includes('directeur') || title.includes('gérant')) {
        decideursCount++;
      }
    });
  }

  // Déduire contexte B2B/B2C
  const hasCompany = companyCol && companyCol.completionRate > 50;
  const hasBusinessTitles = decideursCount > 0;
  const contextType = (hasCompany || hasBusinessTitles) ? 'B2B' : 'B2C';

  // Construction du message intelligent
  let message = `J'ai analysé les **${rowCount} leads** :\n\n`;

  message += `**Observations :**\n`;

  // Stats précises
  if (emailCol) {
    message += `• Email : ${emailCol.completionRate}% rempli (${Math.round(rowCount * emailCol.completionRate / 100)}/${rowCount})\n`;
  }
  if (phoneCol) {
    message += `• Téléphone : ${phoneCol.completionRate}% rempli (${Math.round(rowCount * phoneCol.completionRate / 100)}/${rowCount})\n`;
  }

  // Déduction intelligente
  if (decideursCount > 0) {
    message += `• ${decideursCount} décideur${decideursCount > 1 ? 's' : ''} détecté${decideursCount > 1 ? 's' : ''} (fondateur/directeur) → profil ${contextType} prioritaire\n`;
  } else if (contextType === 'B2B') {
    message += `• Profil ${contextType} détecté\n`;
  }

  // Champs manquants
  if (missingFields.length > 0) {
    const topMissing = missingFields.slice(0, 2).map(f => f.label).join(', ');
    message += `• Champs manquants : ${topMissing}\n`;
  }

  message += `\n**Je peux :**\n`;

  // Actions concrètes basées sur l'analyse
  if (phoneCol && phoneCol.completionRate < 80) {
    const missing = rowCount - Math.round(rowCount * phoneCol.completionRate / 100);
    message += `- Enrichir les ${missing} téléphones manquants via LinkedIn (15 min)\n`;
  }

  if (missingFields.length > 0) {
    message += `- Compléter les champs manquants (secteur, description)\n`;
  }

  if (decideursCount > 0) {
    message += `- Créer un score de priorité (décideurs = chauds)\n`;
  } else {
    message += `- Qualifier les leads selon leur potentiel\n`;
  }

  // Question ciblée
  message += `\n`;
  if (contextType === 'B2B') {
    message += `**D'où viennent ces contacts ?** (Salon, LinkedIn, formulaire web ?)`;
  } else {
    message += `**Quel est le contexte de ces leads ?**`;
  }

  return message;
}

/**
 * Génère le message d'enrichissement pour M.A.X.
 */
function generateEnrichmentMessage(enrichmentResult, context, mode = 'assisté') {
  const { enrichedLeads, enrichmentData, stats } = enrichmentResult;

  let message = `Parfait! 🎯 Voici ce que j'ai fait:\n\n`;

  message += `**✅ Enrichissement automatique:**\n`;

  if (enrichmentData.tags) {
    message += `- Tags: "${enrichmentData.tags.join('", "')}"\n`;
  }
  if (enrichmentData.source) {
    message += `- Source: "${enrichmentData.source}"\n`;
  }
  if (enrichmentData.status) {
    message += `- Statut: "${enrichmentData.status}"\n`;
  }
  if (enrichmentData.description) {
    message += `- Description: "${enrichmentData.description}"\n`;
  }

  message += `\n**📊 Résultats:**\n`;
  message += `- ${stats.totalLeads} leads traités\n`;
  message += `- ${stats.fieldsAdded.description} descriptions ajoutées\n`;
  message += `- ${stats.fieldsAdded.tags} tags ajoutés\n`;
  message += `- ${stats.fieldsAdded.status} statuts attribués\n`;
  message += `- ${stats.fieldsAdded.source} sources définies\n\n`;

  // Message adapté au mode
  if (mode === 'assisté') {
    message += `**🤝 Confirmation requise:**\n`;
    message += `Souhaitez-vous que j'importe ces ${stats.totalLeads} leads enrichis dans EspoCRM?\n\n`;
    message += `Les données seront insérées avec les tags, statuts et sources ci-dessus.`;
  } else if (mode === 'auto') {
    message += `**⚡ Import automatique en cours...**`;
  } else {
    message += `**💡 Suggestion:**\n`;
    message += `Vous pouvez maintenant télécharger le CSV enrichi ou l'importer manuellement dans EspoCRM.`;
  }

  return message;
}

/**
 * POST /api/chat/import
 * Importer les leads enrichis dans EspoCRM
 *
 * Body: { sessionId }
 */
router.post('/import', async (req, res) => {
  try {
    const { sessionId } = req.body;

    if (!sessionId) {
      return res.status(400).json({ ok: false, error: 'Session requise' });
    }

    const conversation = loadConversation(sessionId);
    if (!conversation || !conversation.enrichedData) {
      return res.status(400).json({ ok: false, error: 'Aucune donnée enrichie dans cette session' });
    }

    const { enrichedData } = conversation;

    console.log(`[ChatRoute] Import de ${enrichedData.enrichedLeads?.length || 0} leads dans EspoCRM...`);

    // Importer dans EspoCRM
    const importResult = await importEnrichedDataset(enrichedData);

    if (!importResult.ok) {
      throw new Error('Erreur lors de l\'import EspoCRM');
    }

    // Générer message M.A.X.
    const maxMessage = generateImportMessage(importResult);

    // Sauvegarder réponse M.A.X.
    saveMessage(sessionId, {
      role: 'assistant',
      content: maxMessage,
      timestamp: new Date().toISOString(),
      metadata: {
        importStats: importResult.stats
      }
    });

    res.json({
      ok: true,
      sessionId,
      message: maxMessage,
      stats: importResult.stats,
      segments: importResult.segments
    });

  } catch (error) {
    console.error('[ChatRoute] Erreur import:', error);
    res.status(500).json({
      ok: false,
      error: error.message || 'Erreur lors de l\'import'
    });
  }
});

/**
 * Génère les actions disponibles pour le fichier
 */
function generateFileActions(analysis, filename, mode = 'assisté') {
  const actions = [];

  // En mode 'assisté', ne pas afficher de boutons d'upload
  // L'enrichissement se fera automatiquement quand l'utilisateur fournira le contexte
  if (mode === 'assisté') {
    return []; // Pas de boutons, attendre le contexte utilisateur
  }

  // En mode 'conseil', ne pas proposer d'actions d'exécution
  if (mode === 'conseil') {
    // Seulement l'action preview en lecture seule
    actions.push({
      label: '💡 Voir aperçu données',
      action: 'preview-data',
      data: { filename }
    });
    return actions;
  }

  // Mode 'auto' - Actions d'import disponibles
  // Action enrichissement si données manquantes
  if (analysis.missingFields.length > 0) {
    actions.push({
      label: 'Enrichir les données',
      action: 'enrich-data',
      data: { filename }
    });
  }

  // Action import direct si qualité suffisante
  if (analysis.summary.quality !== 'poor') {
    actions.push({
      label: 'Importer tel quel',
      action: 'import-as-is',
      data: { filename }
    });
  }

  // Action preview
  actions.push({
    label: 'Voir aperçu données',
    action: 'preview-data',
    data: { filename }
  });

  return actions;
}

/**
 * Génère le message d'import pour M.A.X.
 */
function generateImportMessage(importResult) {
  const { stats, segments } = importResult;
  const espoBaseUrl = process.env.ESPO_BASE_URL || 'http://127.0.0.1:8081/espocrm';

  let message = `✅ **ACTION RÉELLE EXÉCUTÉE** - Import terminé avec succès!\n\n`;

  message += `**📊 Résultats:**\n`;
  message += `- ${stats.imported} leads importés dans EspoCRM\n`;

  if (stats.failed > 0) {
    message += `- ${stats.failed} leads en échec\n`;
  }

  if (stats.segmentsCreated > 0) {
    message += `- ${stats.segmentsCreated} segment(s) créé(s)\n\n`;

    message += `**🎯 Segments créés:**\n`;
    segments.forEach(seg => {
      message += `- ${seg.name}`;
      if (seg.id) {
        message += ` - [Voir dans EspoCRM](${espoBaseUrl}/#TargetList/view/${seg.id})`;
      }
      message += `\n`;
    });
  }

  message += `\n**🔗 Liens rapides:**\n`;
  message += `- [Voir tous les Leads dans EspoCRM](${espoBaseUrl}/#Lead)\n`;
  message += `- [Dashboard CRM](${espoBaseUrl}/#Dashboard)\n`;

  message += `\n💡 **Prochaines étapes suggérées:**\n`;
  message += `1. Consulter vos leads dans EspoCRM\n`;
  message += `2. Configurer une campagne de suivi\n`;
  message += `3. Assigner les leads à vos commerciaux\n\n`;
  message += `Vos données sont maintenant dans EspoCRM! 🚀`;

  return message;
}

/**
 * POST /api/chat/action
 * Gère les actions des boutons (confirm-import-espo, cancel-import, download-enriched)
 */
router.post('/action', async (req, res) => {
  try {
    const { action, sessionId } = req.body;

    console.log(`[ChatRoute] Action reçue: ${action} pour session ${sessionId}`);

    if (!sessionId) {
      return res.status(400).json({ ok: false, error: 'Session requise' });
    }

    const conversation = loadConversation(sessionId);
    if (!conversation) {
      return res.status(400).json({ ok: false, error: 'Session introuvable' });
    }

    switch (action) {
      case 'confirm-import-espo': {
        // Vérifier qu'il y a des données enrichies
        if (!conversation.enrichedData) {
          return res.status(400).json({ ok: false, error: 'Aucune donnée enrichie disponible' });
        }

        const { enrichedData } = conversation;
        console.log(`[ChatRoute] Import de ${enrichedData.enrichedLeads?.length || 0} leads dans EspoCRM...`);

        // Importer dans EspoCRM
        const importResult = await importEnrichedDataset(enrichedData);

        if (!importResult.ok) {
          throw new Error('Erreur lors de l\'import EspoCRM');
        }

        // Marquer la session comme importée
        conversation.imported = true;
        conversation.importedAt = new Date().toISOString();
        const sessionFile = path.join(__dirname, '..', 'conversations', `${sessionId}.json`);
        fs.writeFileSync(sessionFile, JSON.stringify(conversation, null, 2));

        // Générer message M.A.X.
        const maxMessage = generateImportMessage(importResult);

        // Sauvegarder réponse M.A.X.
        saveMessage(sessionId, {
          role: 'assistant',
          content: maxMessage,
          timestamp: new Date().toISOString(),
          metadata: {
            importStats: importResult.stats
          }
        });

        return res.json({
          ok: true,
          sessionId,
          message: maxMessage,
          stats: importResult.stats
        });
      }

      case 'cancel-import': {
        const cancelMessage = "D'accord, import annulé. Les données restent disponibles si vous changez d'avis.";

        saveMessage(sessionId, {
          role: 'assistant',
          content: cancelMessage,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message: cancelMessage
        });
      }

      case 'download-enriched': {
        if (!conversation.enrichedData) {
          return res.status(400).json({ ok: false, error: 'Aucune donnée enrichie disponible' });
        }

        // Générer CSV enrichi
        const { enrichedLeads } = conversation.enrichedData;

        // Convertir en CSV
        const csv = await import('papaparse');
        const csvContent = csv.default.unparse(enrichedLeads);

        // Retourner le CSV
        res.setHeader('Content-Type', 'text/csv');
        res.setHeader('Content-Disposition', `attachment; filename="leads_enriched_${Date.now()}.csv"`);
        return res.send(csvContent);
      }

      // Nouvelles actions contextuelles
      case 'start-enrichment': {
        const message = "Pour enrichir vos leads, j'ai besoin de quelques informations :\n\n" +
          "• **Objectifs** : Que recherchent ces leads ? (ex: 'Augmenter ventes', 'Remplir carnet RDV')\n" +
          "• **Budget moyen** : Quel est leur budget estimé ?\n" +
          "• **Services souhaités** : Quels services les intéressent ?\n\n" +
          "Donnez-moi ces informations et je vais enrichir les leads.";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'execute-enrichment': {
        const message = "✅ Enrichissement en cours...\n\n" +
          "Je suis en train d'ajouter les informations manquantes aux leads. " +
          "Cette opération peut prendre quelques instants.\n\n" +
          "💡 **Astuce** : Pendant ce temps, vous pouvez préparer votre première campagne de contact.";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'skip-enrichment': {
        const message = "D'accord, on passe l'enrichissement pour le moment.\n\n" +
          "Que souhaitez-vous faire maintenant ?";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'setup-workflows': {
        const message = "⚡ **Configuration des workflows automatiques**\n\n" +
          "Je vous propose plusieurs workflows adaptés à vos leads :\n\n" +
          "1. **Relance J+3** : Contact initial 3 jours après import\n" +
          "2. **Séquence nurturing** : 5 emails sur 2 semaines\n" +
          "3. **Rappel RDV** : Relance automatique des RDV non confirmés\n\n" +
          "Lequel souhaitez-vous activer ?";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'segment-leads': {
        const message = "🎯 **Segmentation des leads**\n\n" +
          "Je vais créer des segments intelligents basés sur :\n" +
          "• Potentiel de conversion\n" +
          "• Secteur d'activité\n" +
          "• Taille d'entreprise\n\n" +
          "Voulez-vous que je procède ?";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'create-campaign': {
        const message = "✉️ **Création de campagne email**\n\n" +
          "Je vais créer une séquence personnalisée pour vos leads.\n\n" +
          "Quel type de campagne souhaitez-vous ?\n" +
          "• **Découverte** : Présentation de vos services\n" +
          "• **Promotion** : Offre spéciale limitée\n" +
          "• **Nurturing** : Contenu éducatif progressif";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'show-enrichment-details': {
        const message = "📋 **Détails de l'enrichissement**\n\n" +
          "Voici ce qui sera ajouté à vos leads :\n\n" +
          "• **Champs ajoutés** : Objectifs, Budget, Services souhaités\n" +
          "• **Source de données** : Analyse contextuelle + bases publiques\n" +
          "• **Coût** : Variable selon nombre de champs manquants\n" +
          "• **Délai** : ~2 minutes pour 10 leads\n\n" +
          "Souhaitez-vous continuer ?";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      case 'activate-workflow':
      case 'customize-workflow':
      case 'skip-workflow': {
        const message = "Cette fonctionnalité sera bientôt disponible. 🚀\n\n" +
          "En attendant, que souhaitez-vous faire avec vos leads ?";

        saveMessage(sessionId, {
          role: 'assistant',
          content: message,
          timestamp: new Date().toISOString()
        });

        return res.json({
          ok: true,
          sessionId,
          message
        });
      }

      default:
        return res.status(400).json({ ok: false, error: `Action inconnue: ${action}` });
    }

  } catch (error) {
    console.error('[ChatRoute] Erreur action:', error);
    res.status(500).json({
      ok: false,
      error: error.message || 'Erreur lors de l\'exécution de l\'action'
    });
  }
});

export default router;
