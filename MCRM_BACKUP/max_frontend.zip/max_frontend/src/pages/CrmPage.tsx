import { useState } from 'react';
import { useAppCtx } from '../store/useAppCtx';
import { ActionModal } from '../components/ActionModal';
import { triggerN8n } from '../lib/api';

interface Contact {
  id: string;
  name: string;
  email: string;
  phone: string;
  company: string;
  status: 'Lead chaud' | 'Lead tiède' | 'Lead froid' | 'Client' | 'Devis en attente';
  maxScore: number;
  lastInteraction: string;
  segments?: string[];
}

interface MaxTask {
  id: string;
  title: string;
  description: string;
  type: 'suggested' | 'automatic';
  priority: 'HAUTE' | 'MOYENNE' | 'AUTO' | 'WORKFLOW' | 'TERMINÉ';
  actionCode: string;
  completed?: boolean;
}

const AUTO_WHITELIST = ["wf-relance-j3", "tag-hot", "email-seq-optimize"];

const mockContacts: Contact[] = [
  {
    id: '1',
    name: 'Ali Hassan',
    email: 'ali.hassan@logistic-pro.com',
    phone: '+33 6 45 67 89 01',
    company: 'Logistic Pro SARL',
    status: 'Devis en attente',
    maxScore: 78,
    lastInteraction: '2025-11-06T14:00:00Z',
    segments: ['contacté par mail', 'appelé', 'converti']
  },
  {
    id: '2',
    name: 'Marie Dupont',
    email: 'marie.dupont@email.com',
    phone: '+33 6 12 34 56 78',
    company: 'TechCorp',
    status: 'Lead chaud',
    maxScore: 85,
    lastInteraction: '2024-01-15T14:30:00Z'
  },
  {
    id: '3',
    name: 'Jean Martin',
    email: 'jean.martin@email.com',
    phone: '+33 6 98 76 54 32',
    company: 'Innovate Ltd',
    status: 'Lead tiède',
    maxScore: 62,
    lastInteraction: '2024-01-14T09:15:00Z'
  }
];

const mockTasks: MaxTask[] = [
  {
    id: '1',
    title: 'Relancer devis Paris → Lyon',
    description: 'Relance du devis de transport Paris-Lyon en attente',
    type: 'suggested',
    priority: 'HAUTE',
    actionCode: 'relance-devis-paris-lyon'
  },
  {
    id: '2',
    title: 'Confirmer enlèvement demain 10h',
    description: 'Confirmation de l\'enlèvement prévu demain à 10h',
    type: 'suggested',
    priority: 'MOYENNE',
    actionCode: 'confirmer-enlevement'
  },
  {
    id: '3',
    title: 'Mettre à jour le statut transport',
    description: 'Mise à jour automatique du statut de transport',
    type: 'automatic',
    priority: 'AUTO',
    actionCode: 'update-statut-transport'
  },
  {
    id: '4',
    title: 'Activer suivi GPS temps réel',
    description: 'Activation du suivi GPS en temps réel pour ce transport',
    type: 'automatic',
    priority: 'WORKFLOW',
    actionCode: 'activer-gps-suivi'
  },
  {
    id: '5',
    title: 'Tag #devis-confirmé',
    description: 'Le devis a été confirmé et taggé automatiquement',
    type: 'automatic',
    priority: 'TERMINÉ',
    actionCode: 'tag-devis-confirme',
    completed: true
  }
];

export function CrmPage() {
  const { apiBase, tenant, role, preview, mode } = useAppCtx();
  const [selectedContact, setSelectedContact] = useState<Contact>(mockContacts[0]);
  const [searchTerm, setSearchTerm] = useState('');
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedTask, setSelectedTask] = useState<MaxTask | null>(null);

  const filteredContacts = mockContacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.company.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExecuteTask = async (task: MaxTask) => {
    const isAdmin = (role || "").toLowerCase() === "admin";
    const shouldAutoExecute = mode === 'auto' && isAdmin && AUTO_WHITELIST.includes(task.actionCode);

    if (shouldAutoExecute) {
      // Auto-execute without modal
      try {
        const ctx = { apiBase, tenant, role, preview: false }; // Force preview false for auto mode
        const res = await triggerN8n(task.actionCode, 'auto', { taskId: task.id, contactId: selectedContact.id }, ctx);
        if (res.ok) {
          console.log('Auto-executed task:', task.actionCode);
        } else {
          console.error('Auto-execution failed:', res.error);
        }
      } catch (err) {
        console.error('Auto-execution error:', err);
      }
    } else {
      // Show modal for manual execution
      setSelectedTask(task);
      setShowActionModal(true);
    }
  };

  const handleAudit = (task: MaxTask) => {
    alert(`Audit de la tâche "${task.title}"`);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Devis en attente': return 'badge-warning';
      case 'Lead chaud': return 'badge-danger';
      case 'Lead tiède': return 'badge-warning';
      case 'Lead froid': return 'badge-info';
      case 'Client': return 'badge-success';
      default: return 'badge-muted';
    }
  };

  const getRelativeTime = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffDays === 0) return 'Aujourd\'hui';
    if (diffDays === 1) return 'Il y a 1 jour';
    if (diffDays < 7) return `Il y a ${diffDays} jours`;
    return time.toLocaleDateString('fr-FR');
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'HAUTE': return 'bg-red-500/20 text-red-400 border border-red-500/30';
      case 'MOYENNE': return 'bg-orange-500/20 text-orange-400 border border-orange-500/30';
      case 'AUTO': return 'bg-indigo-500/20 text-indigo-400 border border-indigo-500/30';
      case 'WORKFLOW': return 'bg-purple-500/20 text-purple-400 border border-purple-500/30';
      case 'TERMINÉ': return 'bg-green-500/20 text-green-400 border border-green-500/30';
      default: return 'badge-muted';
    }
  };

  return (
    <div className="mx-section">
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Contact Details - 5 columns */}
        <div className="lg:col-span-5 space-y-6">
          {/* Search */}
          <div className="card">
            <div className="card-content">
              <input
                type="text"
                placeholder="Rechercher un contact..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-4 py-3 rounded-lg border border-stroke bg-bg-primary text-text placeholder-muted focus:outline-none focus:ring-2 focus:ring-accent-cyan"
              />
            </div>
          </div>

          {/* Contact List */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Contacts</h3>
            </div>
            <div className="card-content">
              <div className="space-y-3 max-h-96 overflow-y-auto">
                {filteredContacts.map((contact) => (
                  <div
                    key={contact.id}
                    onClick={() => setSelectedContact(contact)}
                    className={`p-4 rounded-lg border cursor-pointer transition-all ${
                      selectedContact.id === contact.id
                        ? 'border-accent-cyan bg-accent-cyan/5'
                        : 'border-stroke bg-bg-primary hover:bg-bg-primary/80'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-2">
                      <h4 className="font-medium text-text">{contact.name}</h4>
                      <span className={`badge ${getStatusColor(contact.status)}`}>
                        {contact.status}
                      </span>
                    </div>
                    <div className="text-muted text-sm">{contact.company}</div>
                    <div className="text-muted text-sm">{contact.email}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Selected Contact Details */}
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Fiche Contact</h3>
            </div>
            <div className="card-content">
              <div className="space-y-4">
                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Nom</div>
                  <div className="text-text font-medium">{selectedContact.name}</div>
                </div>

                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Email</div>
                  <div className="text-text">{selectedContact.email}</div>
                </div>

                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Téléphone</div>
                  <div className="text-text">{selectedContact.phone}</div>
                </div>

                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Entreprise</div>
                  <div className="text-text">{selectedContact.company}</div>
                </div>

                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Statut</div>
                  <span className={`badge ${getStatusColor(selectedContact.status)}`}>
                    {selectedContact.status}
                  </span>
                </div>

                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Score M.A.X.</div>
                  <div className="flex items-center gap-2">
                    <div className="text-text font-medium">{selectedContact.maxScore}/100</div>
                    <div className="flex-1 bg-stroke rounded-full h-2">
                      <div
                        className="bg-gradient-to-r from-accent-cyan to-accent-purple h-2 rounded-full transition-all duration-300"
                        style={{ width: `${selectedContact.maxScore}%` }}
                      />
                    </div>
                  </div>
                </div>

                <div>
                  <div className="text-muted uppercase text-xs tracking-wide mb-1">Dernière interaction</div>
                  <div className="text-text">{getRelativeTime(selectedContact.lastInteraction)}</div>
                </div>

                {selectedContact.segments && selectedContact.segments.length > 0 && (
                  <div>
                    <div className="text-muted uppercase text-xs tracking-wide mb-2">Segments</div>
                    <div className="flex flex-wrap gap-2">
                      {selectedContact.segments.map((segment, idx) => (
                        <span key={idx} className="px-3 py-1 rounded-full text-xs font-medium bg-cyan-500/10 text-cyan-400 border border-cyan-500/30">
                          {segment}
                        </span>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* M.A.X. Tasks - 7 columns */}
        <div className="lg:col-span-7">
          <div className="card">
            <div className="card-header">
              <h3 className="card-title">Tâches M.A.X.</h3>
            </div>
            <div className="card-content">
              <div className="space-y-4">
                {mockTasks.map((task) => (
                  <div key={task.id} className="subcard">
                    <div className="mb-3">
                      <h4 className="font-medium text-text mb-2">{task.title}</h4>
                      <span className={`px-3 py-1 rounded-full text-xs font-medium uppercase ${getPriorityColor(task.priority)}`}>
                        {task.priority}
                      </span>
                    </div>

                    <div className="flex gap-2">
                      {task.completed ? (
                        <div className="flex-1 flex items-center justify-center py-2 text-green-400">
                          <svg className="w-5 h-5 mr-2" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                          Terminé
                        </div>
                      ) : (
                        <button
                          onClick={() => handleExecuteTask(task)}
                          className="flex-1 bg-gradient-to-r from-cyan-400 to-purple-500 text-white px-6 py-2 rounded-lg hover:shadow-lg transition-all font-medium"
                        >
                          Exécuter
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Action Modal */}
      {showActionModal && selectedTask && (
        <ActionModal
          code={selectedTask.actionCode}
          defaultMode="auto"
          payload={{ taskId: selectedTask.id, taskTitle: selectedTask.title, contactId: selectedContact.id }}
          onDone={() => {
            setShowActionModal(false);
            setSelectedTask(null);
          }}
        />
      )}
    </div>
  );
}