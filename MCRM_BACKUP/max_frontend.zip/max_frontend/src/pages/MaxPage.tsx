import { useState, useEffect } from 'react';
import { useAppCtx } from '../store/useAppCtx';
import { askMAX, getExecutionLog, triggerN8n } from '../lib/api';
import { ActionModal } from '../components/ActionModal';
import { TaskTray } from '../components/TaskTray';
import { CardSection } from '../components/ui/CardSection';
import ChatPanel from '../components/ChatPanel';
import { ExecutionLog } from '../components/ExecutionLog';
import { HistoryList } from '../components/HistoryList';
import { NumberBadge } from '../components/NumberBadge';

interface LogEntry {
  ts: number;
  message: string;
  status: 'EN COURS' | 'TERMINÉ' | 'ÉCHEC';
  statusLabel: string;
  id: string;
}

interface QuickAction {
  id: string;
  title: string;
  desc: string;
  code: string;
}

interface Message {
  id: string;
  text: string;
  role: 'user' | 'assistant';
}

interface Task {
  id: string;
  title: string;
  status: 'running' | 'completed' | 'failed';
  statusLabel: string;
  progress: number;
}

const quickActions: QuickAction[] = [
  { id: '1', title: 'Relancer 4 devis transport en attente', desc: 'Relancer les devis en attente de confirmation', code: 'relance-devis' },
  { id: '2', title: 'Créer une propriété "Type de marchandise"', desc: 'Ajouter un champ personnalisé pour le type de marchandise', code: 'create-property-marchandise' },
  { id: '3', title: 'Activer relance J+2 sur devis non confirmés', desc: 'Workflow de relance automatique après 2 jours', code: 'relance-j2-auto' },
  { id: '4', title: 'Tag automatique #client-récurrent sur 3+ envois', desc: 'Identifier et taguer les clients récurrents', code: 'auto-tag-recurrent' },
  { id: '5', title: 'Créer un workflow de confirmation automatique', desc: 'Automatiser la confirmation des enlèvements', code: 'workflow-confirmation-auto' }
];

const suggestions = [
  "Quelles sont les prochaines actions recommandées ?",
  "Analyser les leads chauds de cette semaine",
  "Créer un workflow de relance automatique"
];

export function MaxPage() {
  const { apiBase, tenant, role, preview, mode } = useAppCtx();
  const [messages, setMessages] = useState<Message[]>([
    { id: '1', text: "Assistant M.A.X. connecté.\nSaisissez une commande ou une question pour obtenir des suggestions automatiques.", role: 'assistant' }
  ]);
  const [input, setInput] = useState('');
  const [log, setLog] = useState<LogEntry[]>([
    { ts: Date.now() - 300000, message: 'Relance automatique J+3 exécutée', status: 'TERMINÉ', statusLabel: 'TERMINÉ', id: '1' },
    { ts: Date.now() - 180000, message: 'Tag automatique #chaud appliqué', status: 'TERMINÉ', statusLabel: 'TERMINÉ', id: '2' },
    { ts: Date.now() - 60000, message: 'Analyse des leads en cours...', status: 'EN COURS', statusLabel: 'EN COURS', id: '3' }
  ]);
  const [loading, setLoading] = useState(false);
  const [showActionModal, setShowActionModal] = useState(false);
  const [selectedAction, setSelectedAction] = useState<QuickAction | null>(null);
  const [tasks, setTasks] = useState<Task[]>([
    { id: '1', title: 'Analyse des leads', status: 'running', statusLabel: 'EN COURS', progress: 65 },
    { id: '2', title: 'Relance automatique', status: 'completed', statusLabel: 'TERMINÉ', progress: 100 },
    { id: '3', title: 'Segmentation IA', status: 'failed', statusLabel: 'ÉCHEC', progress: 0 }
  ]);

  const ctx = { apiBase, tenant, role, preview };

  const statusToBadge = (status: string) => {
    switch (status) {
      case 'EN COURS': return 'badge-warn';
      case 'TERMINÉ': return 'badge-success';
      case 'ÉCHEC': return 'badge-danger';
      default: return 'badge-muted';
    }
  };

  const taskStatusToBadge = (status: string) => {
    switch (status) {
      case 'running': return 'badge-warn';
      case 'completed': return 'badge-success';
      case 'failed': return 'badge-danger';
      default: return 'badge-muted';
    }
  };

  const fetchLog = async () => {
    try {
      const res = await getExecutionLog(ctx);
      if (res.ok) {
        setLog(res.log || []);
      }
    } catch (err) {
      console.error('Failed to load log:', err);
    }
  };

  useEffect(() => {
    fetchLog();
    const interval = setInterval(fetchLog, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleSend = async () => {
    if (!input.trim()) return;
    setLoading(true);
    try {
      const res = await askMAX({ question: input }, ctx);
      if (res.ok) {
        setMessages((prev) => [
          ...prev,
          { id: Date.now().toString(), text: input, role: 'user' },
          { id: (Date.now() + 1).toString(), text: res.answer || 'Désolé, je n\'ai pas pu traiter votre demande.', role: 'assistant' }
        ]);
        setInput('');
      } else {
        setMessages((prev) => [
          ...prev,
          { id: Date.now().toString(), text: input, role: 'user' },
          { id: (Date.now() + 1).toString(), text: 'Erreur lors de la communication avec M.A.X.', role: 'assistant' }
        ]);
      }
    } catch (err) {
      console.error('Ask MAX error:', err);
      setMessages((prev) => [
        ...prev,
        { id: Date.now().toString(), text: input, role: 'user' },
        { id: (Date.now() + 1).toString(), text: 'Erreur de connexion.', role: 'assistant' }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleActionClick = async (action: QuickAction) => {
    const isAdmin = (role || "").toLowerCase() === "admin";
    const shouldAutoExecute = mode === 'auto' && isAdmin && ["wf-relance-j3", "tag-hot", "email-seq-optimize"].includes(action.code);

    if (shouldAutoExecute) {
      // Auto-execute without modal
      try {
        const autoCtx = { ...ctx, preview: false }; // Force preview false for auto mode
        const res = await triggerN8n(action.code, 'auto', { actionId: action.id }, autoCtx);
        if (res.ok) {
          console.log('Auto-executed action:', action.code);
        } else {
          console.error('Auto-execution failed:', res.error);
        }
      } catch (err) {
        console.error('Auto-execution error:', err);
      }
    } else {
      // Show modal for manual execution
      setSelectedAction(action);
      setShowActionModal(true);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
  };

  const openAudit = (id: string) => {
    alert(`Audit de la tâche ${id}`);
  };

  return (
    <div className="mx-section">
      <h1 className="mx-heading mb-6">Espace M.A.X.</h1>

      <div className="grid grid-cols-12 gap-6">
        {/* Actions rapides */}
        <section className="col-span-12 lg:col-span-7">
          <div className="mx-card p-4 md:p-5">
            <h2 className="mx-subtle mb-3">Suggestions & actions rapides</h2>
            <div className="space-y-3">
              {quickActions.map((a, index)=>(
                <button
                  key={a.id}
                  onClick={() => handleActionClick(a)}
                  className="w-full mx-card p-4 text-left hover:shadow-glow transition-all flex items-center gap-4"
                >
                  <NumberBadge number={index + 1} />
                  <div className="flex-1">
                    <div className="font-medium">{a.title}</div>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Chat (plus large, bien visible) */}
        <aside className="col-span-12 lg:col-span-5">
          <div className="mx-card p-4 md:p-5 h-full">
            <h2 className="mx-subtle mb-3">Chat intelligent M.A.X.</h2>
            <ChatPanel />
          </div>
        </aside>

        {/* Historique + Log */}
        <section className="col-span-12 lg:col-span-6">
          <div className="mx-card p-4 md:p-5 h-full">
            <h3 className="mb-3 font-medium">Historique des propositions</h3>
            <HistoryList />
          </div>
        </section>
        <section className="col-span-12 lg:col-span-6">
          <div className="mx-card p-4 md:p-5 h-full">
            <h3 className="mb-3 font-medium">Log d'exécution</h3>
            <ExecutionLog />
          </div>
        </section>
      </div>
    </div>
  );
}