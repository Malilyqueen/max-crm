import { useState, useEffect } from 'react';
import { useAppCtx } from '../store/useAppCtx';
import { getReporting } from '../lib/api';
import { DashboardPanel } from '../components/DashboardPanel';

interface ActivityItem {
  ts: number;
  event: string;
  details: any;
}

export function DashboardPage() {
  const { apiBase, tenant, role, preview, flags } = useAppCtx();
  const [activity, setActivity] = useState<ActivityItem[]>([]);

  const ctx = { apiBase, tenant, role, preview };

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await getReporting(ctx, flags.useMocks);
        if (res.ok) {
          setActivity(res.activity || []);
        }
      } catch (err) {
        console.error('Failed to load reporting:', err);
      }
    };
    fetchData();
  }, [flags.useMocks]);

  return (
    <div className="mx-section">
      <DashboardPanel />
      <div className="mt-6">
        <h3 className="text-macrea-text mb-4">Recent Activity</h3>
        <div className="space-y-2">
          {activity.slice(0, 10).map((item, i) => (
            <div key={i} className="bg-macrea-card border border-macrea-line p-4 rounded">
              <div className="text-macrea-text">{new Date(item.ts).toLocaleString()}: {item.event}</div>
              <div className="text-macrea-mute">{JSON.stringify(item.details)}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}