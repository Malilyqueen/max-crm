/**
 * ChatPage - Interface de conversation avec M.A.X.
 *
 * Design aéré full-screen pour conversations fluides
 */

import { useState, useRef, useEffect, useCallback } from 'react';
import { useAppCtx } from '../store/useAppCtx';
import { useDebounce } from '../hooks/useDebounce';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  tokens?: number;
  attachments?: Array<{
    name: string;
    type: string;
    size: number;
    url?: string;
  }>;
  actions?: Array<{
    label: string;
    action: string;
    data?: any;
  }>;
}

const QUICK_SUGGESTIONS = [
  { icon: '📊', text: 'Analyser mes leads de la semaine', category: 'Analyse' },
  { icon: '✉️', text: 'Créer une campagne email', category: 'Créa' },
  { icon: '📈', text: 'Voir mes KPIs du mois', category: 'Reporting' },
  { icon: '🎯', text: 'Optimiser mon pipeline', category: 'CRM' },
  { icon: '⚡', text: 'Automatiser une tâche récurrente', category: 'Automation' },
  { icon: '🔍', text: 'Rechercher un contact', category: 'CRM' }
];

const STORAGE_KEY = 'max_chat_session';
const STORAGE_MESSAGES_KEY = 'max_chat_messages';
const STORAGE_MODE_KEY = 'max_chat_mode';

type ExecutionMode = 'assisté' | 'auto' | 'conseil';

export function ChatPage() {
  const { apiBase } = useAppCtx();
  const [sessionId, setSessionId] = useState<string | null>(() => {
    // Restaurer sessionId depuis LocalStorage
    return localStorage.getItem(STORAGE_KEY);
  });
  const [executionMode, setExecutionMode] = useState<ExecutionMode>(() => {
    // Restaurer mode depuis LocalStorage
    const stored = localStorage.getItem(STORAGE_MODE_KEY);
    return (stored as ExecutionMode) || 'assisté';
  });
  const [messages, setMessages] = useState<Message[]>(() => {
    // Restaurer messages depuis LocalStorage
    const stored = localStorage.getItem(STORAGE_MESSAGES_KEY);
    if (stored) {
      try {
        const parsed = JSON.parse(stored);
        return parsed.map((m: any) => ({
          ...m,
          timestamp: new Date(m.timestamp)
        }));
      } catch (e) {
        console.error('[ChatPage] Erreur parsing messages:', e);
      }
    }
    // Message de bienvenue par défaut
    return [
      {
        id: '1',
        role: 'assistant',
        content: 'Bonjour! Je suis M.A.X., votre copilote IA pour le CRM. Comment puis-je vous aider aujourd\'hui?',
        timestamp: new Date()
      }
    ];
  });
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll vers le bas
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  // Sauvegarder messages dans LocalStorage à chaque changement
  useEffect(() => {
    localStorage.setItem(STORAGE_MESSAGES_KEY, JSON.stringify(messages));
  }, [messages]);

  // Sauvegarder sessionId dans LocalStorage à chaque changement
  useEffect(() => {
    if (sessionId) {
      localStorage.setItem(STORAGE_KEY, sessionId);
    }
  }, [sessionId]);

  // Sauvegarder mode dans LocalStorage à chaque changement
  useEffect(() => {
    localStorage.setItem(STORAGE_MODE_KEY, executionMode);
  }, [executionMode]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Auto-resize textarea
  useEffect(() => {
    if (inputRef.current) {
      inputRef.current.style.height = 'auto';
      inputRef.current.style.height = `${Math.min(inputRef.current.scrollHeight, 200)}px`;
    }
  }, [input]);

  // Gestion upload fichiers
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = Array.from(e.dataTransfer.files);
    setUploadedFiles(prev => [...prev, ...files]);
  };

  const removeFile = (index: number) => {
    setUploadedFiles(prev => prev.filter((_, i) => i !== index));
  };

  const handleSend = async () => {
    if ((!input.trim() && uploadedFiles.length === 0) || isTyping) return;

    // Upload fichier si présent
    if (uploadedFiles.length > 0) {
      await handleFileUpload();
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: input.trim(),
      timestamp: new Date()
    };

    // Ajouter message utilisateur immédiatement
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsTyping(true);

    try {
      // Appel à l'API chat avec sessionId et mode
      const res = await fetch(`${apiBase}/api/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          sessionId: sessionId || undefined,
          message: userMessage.content,
          mode: executionMode
        })
      });

      const data = await res.json();

      if (!data.ok) {
        throw new Error(data.error || 'Erreur serveur');
      }

      // Mettre à jour sessionId si nouveau
      if (data.sessionId && data.sessionId !== sessionId) {
        setSessionId(data.sessionId);
      }

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.response,
        timestamp: new Date(),
        tokens: data.tokens?.total_tokens,
        actions: data.actions
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('[ChatPage] Erreur:', error);

      // Message d'erreur
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: error instanceof Error && error.message.includes('Budget')
          ? '⚠️ Budget tokens IA dépassé. Contactez votre administrateur.'
          : '⚠️ Erreur lors du traitement de votre message. Veuillez réessayer.',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleFileUpload = async () => {
    if (uploadedFiles.length === 0) return;

    const file = uploadedFiles[0];
    setIsTyping(true);

    try {
      const formData = new FormData();
      formData.append('file', file);
      formData.append('sessionId', sessionId || '');
      formData.append('mode', executionMode);

      const res = await fetch(`${apiBase}/api/chat/upload`, {
        method: 'POST',
        body: formData
      });

      const data = await res.json();

      if (!data.ok) {
        throw new Error(data.error || 'Erreur upload');
      }

      // Mettre à jour sessionId
      if (data.sessionId && data.sessionId !== sessionId) {
        setSessionId(data.sessionId);
      }

      // Ajouter message utilisateur (fichier uploadé)
      const userMessage: Message = {
        id: Date.now().toString(),
        role: 'user',
        content: `[Fichier uploadé: ${file.name}]`,
        timestamp: new Date(),
        attachments: [{
          name: file.name,
          type: file.type,
          size: file.size
        }]
      };

      // Ajouter réponse M.A.X.
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.message,
        timestamp: new Date(),
        actions: data.actions
      };

      setMessages(prev => [...prev, userMessage, assistantMessage]);
      setUploadedFiles([]);
      setInput('');

    } catch (error) {
      console.error('[ChatPage] Erreur upload:', error);

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `⚠️ Erreur lors de l'upload: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  // Handler optimisé avec async/await + loading + mesure performance
  const handleActionRaw = useCallback(async (action: any) => {
    const startTime = performance.now();
    console.log('[ChatPage] Action cliquée:', action);

    // Protection contre exécution si déjà en cours
    if (isTyping) {
      console.log('[ChatPage] Action ignorée (traitement en cours)');
      return;
    }

    // Actions locales (sans appel API)
    if (action.action === 'enrich-data') {
      setInput('Enrichis ces données avec le contexte suivant: ');
      inputRef.current?.focus();
      return;
    }

    if (action.action === 'cancel-import') {
      const userMessage: Message = {
        id: Date.now().toString(),
        role: 'user',
        content: 'Non, ne pas importer',
        timestamp: new Date()
      };

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: 'Très bien, j\'ai annulé l\'import. Les données enrichies sont conservées dans cette session.',
        timestamp: new Date()
      };

      setMessages(prev => [...prev, userMessage, assistantMessage]);
      return;
    }

    // Actions nécessitant appel API
    setIsTyping(true);

    // Message temporaire immédiat (feedback < 50ms)
    const tempId = 'temp-' + Date.now();
    const tempMessage: Message = {
      id: tempId,
      role: 'assistant',
      content: '⏳ Traitement en cours...',
      timestamp: new Date()
    };
    setMessages(prev => [...prev, tempMessage]);

    try {
      let data;

      // Route vers le bon endpoint selon l'action
      if (action.action === 'confirm-import-espo' || action.action === 'import-to-espo') {
        // Import EspoCRM
        const res = await fetch(`${apiBase}/api/chat/import`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ sessionId })
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        data = await res.json();

      } else {
        // Toutes les autres actions contextuelles
        const res = await fetch(`${apiBase}/api/chat/action`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            sessionId,
            action: action.action,
            data: action.data
          })
        });

        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        data = await res.json();
      }

      const endTime = performance.now();
      const duration = Math.round(endTime - startTime);
      console.log(`[Performance] Action "${action.action}": ${duration}ms`);

      if (!data.ok) {
        throw new Error(data.error || 'Erreur serveur');
      }

      // Remplacer message temporaire par vraie réponse
      const assistantMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: data.message || '✅ Action exécutée',
        timestamp: new Date(),
        actions: data.actions
      };

      setMessages(prev =>
        prev.filter(m => m.id !== tempId).concat(assistantMessage)
      );

    } catch (error) {
      console.error('[ChatPage] Erreur action:', error);

      // Remplacer message temporaire par erreur
      const errorMessage: Message = {
        id: Date.now().toString(),
        role: 'assistant',
        content: `⚠️ Erreur lors de l'exécution de "${action.label}": ${
          error instanceof Error ? error.message : 'Erreur inconnue'
        }`,
        timestamp: new Date(),
        actions: [
          { label: '🔄 Réessayer', action: action.action, data: action.data },
          { label: '❌ Annuler', action: 'cancel' }
        ]
      };

      setMessages(prev =>
        prev.filter(m => m.id !== tempId).concat(errorMessage)
      );

    } finally {
      setIsTyping(false);
    }
  }, [isTyping, sessionId, apiBase]);

  // Appliquer debounce (300ms) pour éviter doubles clics
  const handleAction = useDebounce(handleActionRaw, 300);

  const handleImportToEspo = async () => {
    if (!sessionId) {
      alert('Session invalide');
      return;
    }

    setIsTyping(true);

    try {
      const res = await fetch(`${apiBase}/api/chat/import`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sessionId })
      });

      const data = await res.json();

      if (!data.ok) {
        throw new Error(data.error || 'Erreur import');
      }

      // Ajouter message M.A.X. avec résultat
      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: data.message,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, assistantMessage]);

    } catch (error) {
      console.error('[ChatPage] Erreur import:', error);

      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: `⚠️ Erreur lors de l'import: ${error instanceof Error ? error.message : 'Erreur inconnue'}`,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsTyping(false);
    }
  };

  const handleSuggestionClick = (suggestion: string) => {
    setInput(suggestion);
    inputRef.current?.focus();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  return (
    <div className="flex flex-col h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="flex-shrink-0 bg-slate-900/80 backdrop-blur border-b border-slate-700/50 shadow-lg">
        <div className="max-w-5xl mx-auto px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-white font-bold text-xl shadow-lg shadow-cyan-500/30">
                M
              </div>
              <div>
                <h1 className="text-xl font-bold text-white">Chat M.A.X.</h1>
                <div className="flex items-center gap-2 mt-0.5">
                  <div className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></div>
                  <span className="text-xs text-slate-400">En ligne</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-3 text-xs text-slate-400">
              <span className="px-3 py-1.5 bg-slate-800/60 border border-slate-700 rounded-lg">
                💬 {messages.length - 1} messages
              </span>
            </div>
          </div>
        </div>
      </header>

      {/* Mode Selector */}
      <div className="flex-shrink-0 bg-slate-900/60 backdrop-blur border-b border-slate-700/30 px-6 py-3">
        <div className="max-w-5xl mx-auto">
          <div className="flex items-center gap-6">
            <span className="text-xs font-semibold text-slate-400 uppercase tracking-wide">Mode d'exécution:</span>
            <div className="flex items-center gap-3">
              {/* Mode Assisté */}
              <button
                onClick={() => setExecutionMode('assisté')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  executionMode === 'assisté'
                    ? 'bg-cyan-600 text-white shadow-lg shadow-cyan-500/30'
                    : 'bg-slate-800/60 text-slate-400 hover:bg-slate-700/60 hover:text-slate-300 border border-slate-700'
                }`}
              >
                <span className="mr-2">🤝</span>
                Assisté
              </button>

              {/* Mode Auto */}
              <button
                onClick={() => setExecutionMode('auto')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  executionMode === 'auto'
                    ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/30'
                    : 'bg-slate-800/60 text-slate-400 hover:bg-slate-700/60 hover:text-slate-300 border border-slate-700'
                }`}
              >
                <span className="mr-2">⚡</span>
                Auto
              </button>

              {/* Mode Conseil */}
              <button
                onClick={() => setExecutionMode('conseil')}
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
                  executionMode === 'conseil'
                    ? 'bg-purple-600 text-white shadow-lg shadow-purple-500/30'
                    : 'bg-slate-800/60 text-slate-400 hover:bg-slate-700/60 hover:text-slate-300 border border-slate-700'
                }`}
              >
                <span className="mr-2">💡</span>
                Conseil
              </button>
            </div>

            {/* Mode Description */}
            <div className="ml-auto text-xs text-slate-500">
              {executionMode === 'assisté' && '🤝 Demande confirmation avant chaque action'}
              {executionMode === 'auto' && '⚡ Exécute automatiquement les actions'}
              {executionMode === 'conseil' && '💡 Conseils uniquement, pas d\'exécution'}
            </div>
          </div>
        </div>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto">
        <div className="max-w-4xl mx-auto px-6 py-8 space-y-6">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex items-start gap-4 ${
                message.role === 'user' ? 'flex-row-reverse' : 'flex-row'
              }`}
            >
              {/* Avatar */}
              <div
                className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold shadow-lg ${
                  message.role === 'assistant'
                    ? 'bg-gradient-to-br from-cyan-400 to-blue-500 text-white shadow-cyan-500/30'
                    : 'bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-purple-500/30'
                }`}
              >
                {message.role === 'assistant' ? 'M' : 'U'}
              </div>

              {/* Message Bubble */}
              <div
                className={`flex flex-col max-w-2xl ${
                  message.role === 'user' ? 'items-end' : 'items-start'
                }`}
              >
                <div
                  className={`px-6 py-4 rounded-2xl shadow-lg ${
                    message.role === 'assistant'
                      ? 'bg-slate-800/60 border border-slate-700/50 text-slate-100'
                      : 'bg-gradient-to-br from-cyan-600 to-blue-600 text-white'
                  }`}
                >
                  <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>

                  {/* Attachments */}
                  {message.attachments && message.attachments.length > 0 && (
                    <div className="mt-3 pt-3 border-t border-white/10">
                      {message.attachments.map((att, idx) => (
                        <div key={idx} className="flex items-center gap-2 text-xs">
                          <span>📎</span>
                          <span>{att.name}</span>
                          <span className="text-white/60">({(att.size / 1024).toFixed(1)} KB)</span>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                {message.actions && message.actions.length > 0 && (
                  <div className="flex flex-wrap gap-2 mt-3">
                    {message.actions.map((action, idx) => (
                      <button
                        key={idx}
                        onClick={() => handleAction(action)}
                        disabled={isTyping}
                        className={`px-4 py-2 text-white text-sm rounded-lg font-medium transition-all shadow-lg ${
                          isTyping
                            ? 'bg-slate-600 cursor-not-allowed opacity-50'
                            : 'bg-cyan-600 hover:bg-cyan-500 shadow-cyan-500/20 hover:shadow-cyan-500/40'
                        }`}
                      >
                        {action.label}
                      </button>
                    ))}
                  </div>
                )}

                <div className="flex items-center gap-2 mt-2 px-2 text-xs text-slate-500">
                  <span>{message.timestamp.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' })}</span>
                  {message.tokens && (
                    <>
                      <span>•</span>
                      <span>{message.tokens} tokens</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          ))}

          {/* Typing Indicator */}
          {isTyping && (
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-cyan-400 to-blue-500 flex items-center justify-center text-sm font-bold text-white shadow-lg shadow-cyan-500/30">
                M
              </div>
              <div className="px-6 py-4 rounded-2xl bg-slate-800/60 border border-slate-700/50">
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '0ms' }}></div>
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '150ms' }}></div>
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-bounce" style={{ animationDelay: '300ms' }}></div>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>

      {/* Quick Suggestions */}
      {messages.length === 1 && (
        <div className="flex-shrink-0 bg-slate-900/40 backdrop-blur border-t border-slate-700/30 px-6 py-4">
          <div className="max-w-4xl mx-auto">
            <p className="text-xs text-slate-400 mb-3 font-semibold uppercase tracking-wide">Suggestions rapides</p>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {QUICK_SUGGESTIONS.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSuggestionClick(suggestion.text)}
                  className="flex items-center gap-3 px-4 py-3 bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700/50 hover:border-cyan-500/50 rounded-lg transition-all group text-left"
                >
                  <span className="text-2xl">{suggestion.icon}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs text-slate-400 group-hover:text-cyan-400 transition-colors">{suggestion.category}</p>
                    <p className="text-sm text-slate-200 truncate">{suggestion.text}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Input Area */}
      <div
        className={`flex-shrink-0 bg-slate-900/80 backdrop-blur border-t border-slate-700/50 px-6 py-4 shadow-2xl ${
          isDragging ? 'bg-cyan-900/30 border-cyan-500' : ''
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
      >
        <div className="max-w-4xl mx-auto">
          {/* Uploaded Files Preview */}
          {uploadedFiles.length > 0 && (
            <div className="mb-3 flex flex-wrap gap-2">
              {uploadedFiles.map((file, idx) => (
                <div key={idx} className="flex items-center gap-2 px-3 py-2 bg-slate-800/60 border border-slate-700 rounded-lg">
                  <span className="text-sm text-slate-300">📄 {file.name}</span>
                  <span className="text-xs text-slate-500">({(file.size / 1024).toFixed(1)} KB)</span>
                  <button
                    onClick={() => removeFile(idx)}
                    className="ml-2 text-slate-400 hover:text-red-400 transition-colors"
                  >
                    ✕
                  </button>
                </div>
              ))}
            </div>
          )}

          {/* Drag & Drop Hint */}
          {isDragging && (
            <div className="mb-3 p-6 border-2 border-dashed border-cyan-500 rounded-xl bg-cyan-500/10 text-center">
              <p className="text-cyan-400 font-medium">📂 Déposez votre fichier CSV ici</p>
            </div>
          )}

          <div className="flex items-end gap-3">
            <div className="flex-1 relative">
              <textarea
                ref={inputRef}
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder={uploadedFiles.length > 0 ? "Décrivez le contexte de ces leads..." : "Tapez votre message... (Shift+Enter pour nouvelle ligne)"}
                rows={1}
                className="w-full bg-slate-800/60 border border-slate-700/50 focus:border-cyan-500/50 rounded-xl px-5 py-3 text-slate-100 placeholder-slate-500 resize-none focus:outline-none focus:ring-2 focus:ring-cyan-500/20 transition-all"
                style={{ minHeight: '48px', maxHeight: '200px' }}
              />
            </div>

            {/* File Upload Button */}
            <input
              ref={fileInputRef}
              type="file"
              accept=".csv,.xlsx,.xls"
              onChange={handleFileSelect}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-shrink-0 px-4 py-3 bg-slate-800/60 hover:bg-slate-700/60 border border-slate-700 hover:border-cyan-500/50 text-slate-300 rounded-xl transition-all flex items-center gap-2"
              title="Uploader un fichier CSV"
            >
              <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" />
              </svg>
            </button>

            <button
              onClick={handleSend}
              disabled={(!input.trim() && uploadedFiles.length === 0) || isTyping}
              className="flex-shrink-0 px-6 py-3 bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 disabled:from-slate-700 disabled:to-slate-700 text-white rounded-xl font-medium shadow-lg shadow-cyan-500/30 disabled:shadow-none transition-all disabled:cursor-not-allowed flex items-center gap-2"
            >
              {isTyping ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                  <span>Envoi...</span>
                </>
              ) : (
                <>
                  <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8" />
                  </svg>
                  <span>Envoyer</span>
                </>
              )}
            </button>
          </div>

          <p className="mt-2 text-xs text-slate-500 text-center">
            M.A.X. peut faire des erreurs. Vérifiez les informations importantes.
          </p>
        </div>
      </div>
    </div>
  );
}
