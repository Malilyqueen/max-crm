import { useState, useEffect, useMemo, useRef } from 'react';
import { useAppCtx } from '../store/useAppCtx';
import { getDashboard, getReporting } from '../lib/api';
import { RangeSelector } from '../components/RangeSelector';
import { MaxActionsTimeline } from '../components/MaxActionsTimeline';

interface DashboardData {
  ok: boolean;
  range: string;
  kpis: {
    calls_attempted: number;
    calls_connected: number;
    email_opens: number;
    email_clicks: number;
    delta?: {
      calls_attempted: number;
      calls_connected: number;
      email_opens: number;
      email_clicks: number;
    };
  };
  timeline: Array<{ ts: string; channel: string; event: string; count: number }>;
}

interface ReportingData {
  ok: boolean;
  events: Array<{
    ts: string;
    type: string;
    title: string;
    meta: Record<string, any>;
  }>;
}

export function ReportingPage() {
  const { apiBase, tenant, role, preview, flags } = useAppCtx();
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [reportingData, setReportingData] = useState<ReportingData | null>(null);
  const [loading, setLoading] = useState(false);
  const [range, setRange] = useState('7d');
  const mounted = useRef(true);

  const ctx = { apiBase, tenant, role, preview };

  useEffect(() => {
    mounted.current = true;
    return () => { mounted.current = false; };
  }, []);

  async function fetchData(nextRange = range) {
    try {
      setLoading(true);
      const res = await getDashboard(ctx, nextRange, flags.useMocks);
      if (!mounted.current) return;
      setDashboardData(res);
    } catch (e) {
      console.error("[Reporting] fetchData error:", (e as Error)?.message || e);
      if (!mounted.current) return;
      // Dernier recours : valeur vide
      setDashboardData({
        ok: true,
        range: nextRange,
        kpis: {
          calls_attempted: 0, calls_connected: 0, email_opens: 0, email_clicks: 0,
          delta: { calls_attempted: 0, calls_connected: 0, email_opens: 0, email_clicks: 0 }
        },
        timeline: []
      });
    } finally {
      if (mounted.current) setLoading(false);
    }
  }

  useEffect(() => { fetchData(range); }, [range, ctx?.tenant, ctx?.role, ctx?.preview, flags?.useMocks]);

  // Changement de période : ATTENDRE la fin du setRange + fetch
  async function handleRangeChange(next: string) {
    setRange(next);
    await fetchData(next);
  }

  // Memoized calculations
  const kpiData = useMemo(() => {
    if (!dashboardData?.kpis) return null;

    const { kpis } = dashboardData;
    const delta = dashboardData.kpis.delta || {};
    return {
      leads: {
        value: kpis.calls_attempted,
        delta: (delta as any).calls_attempted || 0,
        label: 'Leads entrants'
      },
      conversion: {
        value: kpis.calls_attempted > 0 ? Math.round((kpis.calls_connected / kpis.calls_attempted) * 100) : 0,
        delta: (delta as any).calls_connected || 0,
        label: 'Taux de conversion',
        suffix: '%' as const
      },
      response: {
        value: 2.3, // Mock for now
        delta: -0.08,
        label: 'Temps de réponse moyen',
        suffix: 'h' as const
      },
      automations: {
        value: kpis.email_clicks,
        delta: (delta as any).email_clicks || 0,
        label: 'Automations lancées'
      }
    };
  }, [dashboardData]);

  const getDeltaColor = (delta: number) => {
    if (delta > 0) return 'text-green-400';
    if (delta < 0) return 'text-red-400';
    return 'text-macrea-mute';
  };

  const formatDelta = (delta: number) => {
    const sign = delta > 0 ? '+' : '';
    return `${sign}${(delta * 100).toFixed(0)}%`;
  };

  const exportToCSV = () => {
    if (!dashboardData || !kpiData) return;

    const csvData = [
      ['Métrique', 'Valeur', 'Évolution'],
      ['Leads entrants', kpiData.leads.value, formatDelta(kpiData.leads.delta)],
      ['Taux de conversion', `${kpiData.conversion.value}%`, formatDelta(kpiData.conversion.delta)],
      ['Temps de réponse moyen', `${kpiData.response.value}h`, formatDelta(kpiData.response.delta)],
      ['Automations lancées', kpiData.automations.value, formatDelta(kpiData.automations.delta)],
      [],
      ['Timeline'],
      ['Date/Heure', 'Canal', 'Événement', 'Nombre']
    ];

    dashboardData.timeline.forEach(item => {
      csvData.push([
        new Date(item.ts).toLocaleString(),
        item.channel,
        item.event,
        item.count.toString()
      ]);
    });

    const csvContent = csvData.map(row => row.map(cell => `"${cell}"`).join(',')).join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `reporting-${range}-${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'workflow':
        return (
          <svg className="w-5 h-5 text-macrea-neon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        );
      case 'chat':
        return (
          <svg className="w-5 h-5 text-macrea-neon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z" />
          </svg>
        );
      case 'action':
        return (
          <svg className="w-5 h-5 text-macrea-neon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
          </svg>
        );
      case 'import':
        return (
          <svg className="w-5 h-5 text-macrea-neon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
          </svg>
        );
      default:
        return (
          <svg className="w-5 h-5 text-macrea-neon" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
        );
    }
  };

  const getRelativeTime = (timestamp: string) => {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

    if (diffMins < 1) return 'À l\'instant';
    if (diffMins < 60) return `Il y a ${diffMins} min`;
    if (diffHours < 24) return `Il y a ${diffHours} h`;
    return `Il y a ${diffDays} j`;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[400px]">
        <div className="text-macrea-mute">Chargement du reporting...</div>
      </div>
    );
  }

  if (!dashboardData || !kpiData) {
    return (
      <div className="space-y-4">
        <RangeSelector value={range} onChange={handleRangeChange} />
        <div className="flex flex-col items-center justify-center min-h-[400px] space-y-4">
          <div className="text-macrea-mute text-center">
            <div className="text-lg font-medium mb-2">Aucune donnée disponible</div>
            <div className="text-sm">Il n'y a pas encore de données pour cette période.</div>
          </div>
          <button
            onClick={() => fetchData(range)}
            className="px-4 py-2 bg-macrea-neon text-macrea-bg rounded-lg hover:bg-macrea-neon/90 transition-colors"
            aria-label="Rafraîchir les données"
          >
            Rafraîchir
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-section">
      <div className="space-y-8">
      {/* Header with Range Selector and Export */}
      <div className="flex items-center justify-between">
        <RangeSelector value={range} onChange={handleRangeChange} />
        <button
          onClick={exportToCSV}
          className="px-4 py-2 bg-macrea-neon text-macrea-bg rounded-lg hover:bg-macrea-neon/90 transition-colors flex items-center gap-2"
          aria-label="Exporter les données en CSV"
        >
          <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
          </svg>
          Exporter CSV
        </button>
      </div>

      {/* KPI Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {Object.entries(kpiData).map(([key, kpi]) => (
          <div key={key} className="relative overflow-hidden rounded-xl2 border border-macrea-line/70 bg-macrea-card/70 shadow-inset hover:shadow-glow transition-shadow p-4">
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-macrea-neon/50 to-macrea-rose/50"></div>
            <div className="pt-4">
              <div className="text-sm uppercase tracking-wider text-macrea-mute">{kpi.label}</div>
              <div className="text-3xl font-extrabold text-macrea-neon drop-shadow">
                {kpi.value}{('suffix' in kpi) ? kpi.suffix : ''}
              </div>
              <div className={`text-xs mt-1 ${getDeltaColor(kpi.delta)}`}>
                {formatDelta(kpi.delta)} vs période précédente
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* M.A.X. Actions Timeline */}
      <div>
        <MaxActionsTimeline />
      </div>

      {/* Timeline Activity Chart */}
      {dashboardData.timeline && dashboardData.timeline.length > 0 && (
        <div>
          <h2 className="text-xl font-semibold text-macrea-text mb-4">Activité par heure</h2>
          <div className="space-y-3">
            {dashboardData.timeline.slice(0, 10).map((item, i) => {
              const maxCount = Math.max(...dashboardData.timeline.map(t => t.count));
              const percentage = maxCount > 0 ? (item.count / maxCount) * 100 : 0;

              return (
                <div key={i} className="flex items-center gap-4 p-3 bg-macrea-bg2/30 rounded-lg border border-macrea-line/30">
                  <div className="w-24 text-sm text-macrea-mute">
                    {new Date(item.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-macrea-text text-sm">{item.event} ({item.channel})</span>
                      <span className="text-macrea-mute text-xs">{item.count}</span>
                    </div>
                    <div className="w-full bg-macrea-bg2/50 rounded-full h-2">
                      <div
                        className="bg-macrea-neon h-2 rounded-full transition-all duration-300"
                        style={{ width: `${percentage}%` }}
                        title={`${item.count} événements`}
                      ></div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Activité récente */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-macrea-text">Activité récente</h2>
          <button className="px-4 py-2 text-macrea-neon hover:bg-macrea-neon/10 rounded-lg transition-colors">
            Voir tout
          </button>
        </div>

        <div className="space-y-3">
          {reportingData?.events && reportingData.events.length > 0 ? (
            reportingData.events.slice(0, 8).map((event, i) => (
              <div key={i} className="flex items-center gap-4 p-4 bg-macrea-bg2/30 rounded-lg border border-macrea-line/30">
                <div className="w-10 h-10 rounded-full bg-macrea-neon/20 flex items-center justify-center">
                  {getActivityIcon(event.type)}
                </div>
                <div className="flex-1">
                  <div className="text-macrea-text font-medium">{event.title}</div>
                  <div className="text-macrea-mute text-sm">{getRelativeTime(event.ts)}</div>
                </div>
                <span className={`px-2 py-1 text-xs rounded-full ${
                  event.type === 'workflow' ? 'bg-blue-500/10 text-blue-400' :
                  event.type === 'chat' ? 'bg-green-500/10 text-green-400' :
                  event.type === 'action' ? 'bg-yellow-500/10 text-yellow-400' :
                  'bg-purple-500/10 text-purple-400'
                }`}>
                  {event.type}
                </span>
              </div>
            ))
          ) : (
            <div className="text-center py-8 text-macrea-mute">
              Aucune activité récente pour cette période.
            </div>
          )}
        </div>
      </div>
      </div>
    </div>
  );
}