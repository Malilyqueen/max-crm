import { AppShell } from './pages/AppShell';

export default function App() {
  return <AppShell />;
}
