import React, { useEffect, useRef, useState } from "react";
import { api, askMAX } from "../lib/api";

const LS_KEY = "max.chat.v1";

function normalizeMsg(m) {
  if (typeof m === "string") {
    try { return normalizeMsg(JSON.parse(m)); } catch { return { role: "assistant", text: m }; }
  }
  const role = m?.role || m?.author || (m?.isUser ? "user" : "assistant");
  const text = m?.text ?? m?.message ?? m?.content ?? m?.answer ?? "";
  const task = m?.task ?? m?.data?.task ?? m?.payload?.task ?? null;
  return { role: role === "user" ? "user" : "assistant", text: String(text || ""), task };
}
function normalizeHistory(payload) {
  if (!payload) return [];
  const arr = Array.isArray(payload) ? payload :
              Array.isArray(payload?.messages) ? payload.messages :
              Array.isArray(payload?.history) ? payload.history : [];
  return arr.map(normalizeMsg).filter(m => m.text.trim() !== "");
}
function extractAnswer(data) {
  if (typeof data === "string") {
    try { return extractAnswer(JSON.parse(data)); } catch { return data; }
  }
  return String((data?.text ?? data?.answer ?? "") || "");
}
function loadLocal() {
  try { const raw = localStorage.getItem(LS_KEY); return raw ? JSON.parse(raw) : []; } catch { return []; }
}
function saveLocal(msgs) {
  try { localStorage.setItem(LS_KEY, JSON.stringify(msgs)); } catch { void 0; }
}
function mergeUnique(a = [], b = []) {
  const seen = new Set();
  const out = [];
  [...a, ...b].forEach(m => {
    const key = `${m.role}:${m.text}`;
    if (!seen.has(key)) { seen.add(key); out.push(m); }
  });
  return out;
}

export default function ChatPanel() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const listRef = useRef(null);

  // 1) Charger depuis localStorage immédiatement (pour ne rien perdre après F5)
  useEffect(() => {
    setMessages(loadLocal());
  }, []);

  // 2) Puis fusionner avec l'historique serveur si dispo
  useEffect(() => {
    api.get("/api/history")
      .then(d => {
        const server = normalizeHistory(d);
        setMessages(prev => {
          const merged = mergeUnique(prev, server);
          saveLocal(merged);
          return merged;
        });
      })
      .catch(() => { return null; });
  }, []);

  // Auto-scroll + sauvegarde locale à chaque maj
  useEffect(() => {
    listRef.current?.scrollTo({ top: listRef.current.scrollHeight, behavior: "smooth" });
    saveLocal(messages);
  }, [messages, loading]);

  async function onSend(e) {
    e?.preventDefault?.();
    const content = input.trim();
    if (!content || loading) return;

    const userMsg = { role: "user", text: content };
    setMessages(prev => [...prev, userMsg]);
    setInput("");
    setLoading(true);

    try {
      // 1) check EspoCRM status
      let crmOnline = false;
      try {
        const r = await fetch('/api/__espo-status', { cache: 'no-store' });
        const j = await r.json();
        crmOnline = !!j?.ok;
      } catch {
        crmOnline = false;
      }

      // 2) send to /api/ask with context
      const body = { message: content, mode: 'assist', context: { crmOnline } };
      const res = await fetch('/api/ask', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body)
      });
      const data = await res.json();

      const text = extractAnswer(data) || "[Réponse vide]";
      // si la réponse contient un objet `task`, on le conserve pour affichage d'appel à l'action
      const task = data?.task ?? data?.result?.task ?? null;
      setMessages(prev => [...prev, { role: "assistant", text, ...(task ? { task } : {}) }]);
    } catch (err) {
      setMessages(prev => [...prev, { role: "assistant", text: "❌ Erreur: " + (err.message || err) }]);
    } finally {
      setLoading(false);
    }
  }

  function clearLocal() {
    localStorage.removeItem(LS_KEY);
    setMessages([]);
  }

  return (
    <div className="flex flex-col gap-4">
      <div className="mx-card p-4 h-[340px] overflow-y-auto">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[80%] rounded-2xl px-4 py-3 ${msg.role === "user" ? "bg-white/90 text-slate-900" : "glass"}`}>
              <p className="text-sm leading-6 whitespace-pre-wrap">{msg.text}</p>
            </div>
            {/* Task callout: only for assistant messages that include a task object */}
            {msg.task && msg.role !== 'user' ? (
              <div className="w-full mt-2">
                <TaskCallout task={msg.task} onInsert={(note) => setMessages(prev => [...prev, { role: 'assistant', text: note }])} />
              </div>
            ) : null}
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="max-w-[80%] rounded-2xl px-4 py-3 glass text-sm">… M.A.X. réfléchit</div>
          </div>
        )}
      </div>

      <form onSubmit={onSend} className="mt-3 flex items-end gap-2">
        <textarea
          rows="1"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Écris ici…"
          className="flex-1 glass rounded-2xl px-4 py-3 text-sm outline-none resize-none leading-6"
        />
        <button className="btn rounded-2xl px-4 py-3 bg-gradient-to-br from-indigo-400 to-cyan-300 text-slate-900 font-semibold">
          Envoyer
        </button>
      </form>
    </div>
  );
}

function TaskCallout({ task, onInsert }) {
  async function onValidate() {
    try {
      const res = await api.post('/api/actions/dispatch', task);
      // res may be { ok:true, result: { summary, affectedCount } } or { ok:true, summary, affectedCount }
      const summary = res?.result?.summary ?? res?.summary ?? 'Action exécutée';
      const affected = res?.result?.affectedCount ?? res?.affectedCount ?? 0;
      const note = `✅ ${summary} (affectés: ${affected})`;
      if (typeof onInsert === 'function') onInsert(note);
    } catch (e) {
      const note = `❌ Erreur exécution: ${e?.message || e}`;
      if (typeof onInsert === 'function') onInsert(note);
    }
  }

  return (
    <div className="mt-2 rounded-lg border p-3 text-sm bg-white/5">
      <div className="font-medium">Action proposée :</div>
      <pre className="text-xs opacity-80 whitespace-pre-wrap">{JSON.stringify(task, null, 2)}</pre>
      <button onClick={onValidate} className="mt-2 px-3 py-1 rounded-md border">
        Valider l’action
      </button>
    </div>
  );
}
