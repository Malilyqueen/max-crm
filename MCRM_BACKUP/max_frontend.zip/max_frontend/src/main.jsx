import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import "./index.css";

// Dev bootstrap: set default tenant key if missing
if (!localStorage.getItem("TENANT_KEY")) {
	localStorage.setItem("TENANT_KEY", "damath_xxx_change_me");
}

ReactDOM.createRoot(document.getElementById("root")).render(<App/>);
