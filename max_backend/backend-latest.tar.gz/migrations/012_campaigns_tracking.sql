/**
 * Migration 012: Campaigns Tracking
 *
 * Structure minimaliste pour tracking des campagnes bulk
 * Compatible avec message_events existant
 */

-- Table: campaigns
-- Stocke les campagnes d'envoi en masse (Email/SMS/WhatsApp)
CREATE TABLE IF NOT EXISTS campaigns (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id VARCHAR(100) NOT NULL,

  -- Identification
  name VARCHAR(255) NOT NULL,
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('email', 'sms', 'whatsapp')),

  -- Contenu
  subject VARCHAR(500), -- Email only
  content_preview TEXT, -- Premiers 200 chars du message

  -- Segment
  segment_criteria JSONB, -- Stockage des critères de segmentation

  -- Stats rapides (dénormalisées pour performance)
  total_recipients INTEGER DEFAULT 0,
  total_sent INTEGER DEFAULT 0,
  total_delivered INTEGER DEFAULT 0,
  total_failed INTEGER DEFAULT 0,
  total_opened INTEGER DEFAULT 0, -- Email only
  total_clicked INTEGER DEFAULT 0, -- Email only
  total_read INTEGER DEFAULT 0, -- WhatsApp only
  total_replied INTEGER DEFAULT 0, -- SMS/WhatsApp only

  -- Status
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'sending', 'sent', 'failed', 'cancelled')),

  -- Metadata
  meta JSONB, -- Flexible: template_id, tags, custom fields

  -- Audit
  created_by VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  sent_at TIMESTAMP WITH TIME ZONE,
  completed_at TIMESTAMP WITH TIME ZONE,

  -- Indexes inline
  CONSTRAINT campaigns_tenant_check CHECK (tenant_id IS NOT NULL AND tenant_id != '')
);

-- Indexes for campaigns
CREATE INDEX idx_campaigns_tenant_created ON campaigns(tenant_id, created_at DESC);
CREATE INDEX idx_campaigns_channel ON campaigns(channel);
CREATE INDEX idx_campaigns_status ON campaigns(status);
CREATE INDEX idx_campaigns_sent_at ON campaigns(sent_at DESC) WHERE sent_at IS NOT NULL;

-- Add campaign_id to message_events
ALTER TABLE message_events
ADD COLUMN IF NOT EXISTS campaign_id UUID REFERENCES campaigns(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_message_events_campaign ON message_events(campaign_id) WHERE campaign_id IS NOT NULL;

-- Vue: Campagnes récentes avec stats
CREATE OR REPLACE VIEW campaigns_recent AS
SELECT
  c.id,
  c.tenant_id,
  c.name,
  c.channel,
  c.subject,
  c.content_preview,
  c.total_recipients,
  c.total_sent,
  c.total_delivered,
  c.total_failed,
  c.total_opened,
  c.total_clicked,
  c.total_read,
  c.total_replied,
  c.status,
  c.sent_at,
  c.created_at,
  -- Taux calculés
  CASE
    WHEN c.total_sent > 0 THEN ROUND((c.total_delivered::NUMERIC / c.total_sent::NUMERIC) * 100, 2)
    ELSE 0
  END AS delivery_rate,
  CASE
    WHEN c.total_delivered > 0 THEN ROUND((c.total_opened::NUMERIC / c.total_delivered::NUMERIC) * 100, 2)
    ELSE 0
  END AS open_rate,
  CASE
    WHEN c.total_opened > 0 THEN ROUND((c.total_clicked::NUMERIC / c.total_opened::NUMERIC) * 100, 2)
    ELSE 0
  END AS click_rate
FROM campaigns c
WHERE c.status = 'sent'
ORDER BY c.sent_at DESC
LIMIT 50;

-- Fonction: Mettre à jour les stats de campagne
CREATE OR REPLACE FUNCTION update_campaign_stats(p_campaign_id UUID)
RETURNS void AS $$
BEGIN
  UPDATE campaigns
  SET
    total_sent = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND direction = 'out'
        AND status IN ('sent', 'queued', 'delivered', 'read', 'opened', 'clicked')
    ),
    total_delivered = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND status IN ('delivered', 'read', 'opened', 'clicked')
    ),
    total_failed = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND status IN ('failed', 'bounced', 'blocked', 'rejected')
    ),
    total_opened = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND status IN ('opened', 'clicked')
    ),
    total_clicked = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND status = 'clicked'
    ),
    total_read = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND status = 'read'
    ),
    total_replied = (
      SELECT COUNT(*)
      FROM message_events
      WHERE campaign_id = p_campaign_id
        AND direction = 'in'
    )
  WHERE id = p_campaign_id;
END;
$$ LANGUAGE plpgsql;

-- Trigger: Auto-update campaign stats on message_events change
CREATE OR REPLACE FUNCTION trigger_update_campaign_stats()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.campaign_id IS NOT NULL THEN
    PERFORM update_campaign_stats(NEW.campaign_id);
  END IF;

  IF TG_OP = 'UPDATE' AND OLD.campaign_id IS DISTINCT FROM NEW.campaign_id THEN
    IF OLD.campaign_id IS NOT NULL THEN
      PERFORM update_campaign_stats(OLD.campaign_id);
    END IF;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER message_events_update_campaign_stats
AFTER INSERT OR UPDATE ON message_events
FOR EACH ROW
WHEN (NEW.campaign_id IS NOT NULL)
EXECUTE FUNCTION trigger_update_campaign_stats();

-- Comments
COMMENT ON TABLE campaigns IS 'Tracking des campagnes bulk (Email/SMS/WhatsApp)';
COMMENT ON COLUMN campaigns.segment_criteria IS 'Critères de segmentation: status[], tags[], source, leadIds[]';
COMMENT ON COLUMN campaigns.meta IS 'Metadata flexible: template_id, notes, custom fields';
COMMENT ON COLUMN campaigns.total_recipients IS 'Nombre de leads visés par le segment';
COMMENT ON FUNCTION update_campaign_stats IS 'Recalcule les stats d''une campagne depuis message_events';