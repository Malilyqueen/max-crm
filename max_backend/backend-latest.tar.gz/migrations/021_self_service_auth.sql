-- =====================================================
-- Migration: Self-Service Onboarding System
-- Version: 021
-- Description: Remplace auth hardcodé par Supabase Auth + DB
-- =====================================================

-- ============================================================
-- Table: users (utilisateurs authentifiés)
-- ============================================================
CREATE TABLE IF NOT EXISTS users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,

  -- Profil
  name VARCHAR(255) NOT NULL,
  phone VARCHAR(50),
  avatar_url TEXT,

  -- État
  is_active BOOLEAN DEFAULT true,
  email_verified BOOLEAN DEFAULT false,
  last_login_at TIMESTAMPTZ,

  -- Méta
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_users_active ON users(is_active);

-- ============================================================
-- Table: tenants (organisations/entreprises)
-- ============================================================
CREATE TABLE IF NOT EXISTS tenants (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  slug VARCHAR(100) NOT NULL UNIQUE, -- ex: "macrea", "demo_client"

  -- Infos entreprise
  name VARCHAR(255) NOT NULL,
  domain VARCHAR(255), -- ex: "macrea.fr"
  logo_url TEXT,

  -- Plan et billing
  plan VARCHAR(50) DEFAULT 'starter', -- 'starter' (131€) ou 'starter_whatsapp' (164€)
  plan_started_at TIMESTAMPTZ DEFAULT NOW(),
  plan_expires_at TIMESTAMPTZ,

  -- CRM EspoCRM configuration
  crm_url TEXT, -- URL de l'instance EspoCRM (NULL = utiliser fallback env)
  crm_api_key TEXT, -- API Key EspoCRM
  crm_status VARCHAR(50) DEFAULT 'pending', -- 'pending', 'provisioning', 'active', 'error', 'suspended'
  crm_error TEXT, -- Message d'erreur si crm_status = 'error'
  crm_provisioned_at TIMESTAMPTZ, -- Date de provisioning

  -- État
  is_active BOOLEAN DEFAULT true,
  is_provisioned BOOLEAN DEFAULT false, -- CRM provisionné?

  -- Méta
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),
  created_by UUID REFERENCES users(id)
);

-- Index
CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);
CREATE INDEX IF NOT EXISTS idx_tenants_active ON tenants(is_active);
CREATE INDEX IF NOT EXISTS idx_tenants_plan ON tenants(plan);

-- ============================================================
-- Table: memberships (lien user <-> tenant avec rôle)
-- ============================================================
CREATE TABLE IF NOT EXISTS memberships (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,

  -- Rôle
  role VARCHAR(50) DEFAULT 'admin', -- 'owner', 'admin', 'user'

  -- État
  is_active BOOLEAN DEFAULT true,

  -- Méta
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW(),

  -- Contrainte: un user ne peut avoir qu'un membership par tenant
  UNIQUE(user_id, tenant_id)
);

-- Index
CREATE INDEX IF NOT EXISTS idx_memberships_user ON memberships(user_id);
CREATE INDEX IF NOT EXISTS idx_memberships_tenant ON memberships(tenant_id);

-- ============================================================
-- Table: tenant_plans (définition des plans)
-- ============================================================
CREATE TABLE IF NOT EXISTS tenant_plans (
  id VARCHAR(50) PRIMARY KEY, -- 'starter', 'starter_whatsapp'
  name VARCHAR(100) NOT NULL,
  price_eur DECIMAL(10,2) NOT NULL,

  -- Features incluses
  whatsapp_enabled BOOLEAN DEFAULT false,
  sms_enabled BOOLEAN DEFAULT true,
  email_enabled BOOLEAN DEFAULT true,
  campaigns_enabled BOOLEAN DEFAULT true,

  -- WhatsApp specifique
  whatsapp_messages_included INTEGER DEFAULT 0,

  -- Description
  description TEXT,

  -- Méta
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insérer les plans par défaut
INSERT INTO tenant_plans (id, name, price_eur, whatsapp_enabled, whatsapp_messages_included, description)
VALUES
  ('starter', 'Starter', 131.00, false, 0, 'CRM complet sans WhatsApp'),
  ('starter_whatsapp', 'Starter + WhatsApp', 164.00, true, 100, 'CRM complet avec WhatsApp Pro (100 msg/mois inclus)')
ON CONFLICT (id) DO UPDATE SET
  price_eur = EXCLUDED.price_eur,
  whatsapp_enabled = EXCLUDED.whatsapp_enabled,
  whatsapp_messages_included = EXCLUDED.whatsapp_messages_included,
  description = EXCLUDED.description;

-- ============================================================
-- Vue: user_with_tenant (pour login rapide)
-- ============================================================
CREATE OR REPLACE VIEW user_with_tenant AS
SELECT
  u.id AS user_id,
  u.email,
  u.password_hash,
  u.name AS user_name,
  u.is_active AS user_active,
  t.id AS tenant_id,
  t.slug AS tenant_slug,
  t.name AS tenant_name,
  t.plan,
  t.is_active AS tenant_active,
  t.is_provisioned,
  m.role,
  m.is_active AS membership_active
FROM users u
JOIN memberships m ON m.user_id = u.id
JOIN tenants t ON t.id = m.tenant_id
WHERE u.is_active = true
  AND m.is_active = true;

-- ============================================================
-- Fonction: create_tenant_with_owner
-- Crée un tenant + membership owner en une transaction
-- ============================================================
CREATE OR REPLACE FUNCTION create_tenant_with_owner(
  p_user_id UUID,
  p_tenant_name VARCHAR(255),
  p_tenant_slug VARCHAR(100),
  p_plan VARCHAR(50) DEFAULT 'starter'
)
RETURNS TABLE(
  tenant_id UUID,
  membership_id UUID,
  success BOOLEAN,
  error_message TEXT
) AS $$
DECLARE
  v_tenant_id UUID;
  v_membership_id UUID;
  v_plan_exists BOOLEAN;
BEGIN
  -- Vérifier que le plan existe
  SELECT EXISTS(SELECT 1 FROM tenant_plans WHERE id = p_plan AND is_active = true) INTO v_plan_exists;

  IF NOT v_plan_exists THEN
    RETURN QUERY SELECT NULL::UUID, NULL::UUID, false, 'Plan invalide: ' || p_plan;
    RETURN;
  END IF;

  -- Vérifier que le slug n'existe pas
  IF EXISTS(SELECT 1 FROM tenants WHERE slug = p_tenant_slug) THEN
    RETURN QUERY SELECT NULL::UUID, NULL::UUID, false, 'Ce nom d''entreprise est déjà pris';
    RETURN;
  END IF;

  -- Créer le tenant
  INSERT INTO tenants (name, slug, plan, created_by)
  VALUES (p_tenant_name, p_tenant_slug, p_plan, p_user_id)
  RETURNING id INTO v_tenant_id;

  -- Créer le membership owner
  INSERT INTO memberships (user_id, tenant_id, role)
  VALUES (p_user_id, v_tenant_id, 'owner')
  RETURNING id INTO v_membership_id;

  -- Créer l'entrée tenant_features (synchronisé avec le plan)
  INSERT INTO tenant_features (tenant_id, whatsapp_enabled, sms_enabled, email_enabled, campaigns_enabled)
  SELECT
    p_tenant_slug,
    tp.whatsapp_enabled,
    tp.sms_enabled,
    tp.email_enabled,
    tp.campaigns_enabled
  FROM tenant_plans tp
  WHERE tp.id = p_plan
  ON CONFLICT (tenant_id) DO UPDATE SET
    whatsapp_enabled = EXCLUDED.whatsapp_enabled,
    sms_enabled = EXCLUDED.sms_enabled,
    email_enabled = EXCLUDED.email_enabled,
    campaigns_enabled = EXCLUDED.campaigns_enabled,
    updated_at = NOW();

  -- Créer l'entrée whatsapp_billing si WhatsApp activé
  IF EXISTS(SELECT 1 FROM tenant_plans WHERE id = p_plan AND whatsapp_enabled = true) THEN
    INSERT INTO whatsapp_billing (
      tenant_id,
      subscription_active,
      included_messages,
      subscription_started_at,
      subscription_expires_at
    )
    SELECT
      p_tenant_slug,
      true,
      tp.whatsapp_messages_included,
      NOW(),
      NOW() + INTERVAL '1 month'
    FROM tenant_plans tp
    WHERE tp.id = p_plan
    ON CONFLICT (tenant_id) DO UPDATE SET
      subscription_active = true,
      included_messages = EXCLUDED.included_messages,
      included_messages_used = 0,
      subscription_started_at = NOW(),
      subscription_expires_at = NOW() + INTERVAL '1 month',
      updated_at = NOW();
  ELSE
    -- Créer entrée inactive pour WhatsApp (visible mais bloqué)
    INSERT INTO whatsapp_billing (tenant_id, subscription_active, included_messages)
    VALUES (p_tenant_slug, false, 0)
    ON CONFLICT (tenant_id) DO NOTHING;
  END IF;

  RETURN QUERY SELECT v_tenant_id, v_membership_id, true, NULL::TEXT;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- Fonction: provision_tenant_crm
-- Marque le tenant comme provisionné (appelé après setup initial)
-- ============================================================
CREATE OR REPLACE FUNCTION provision_tenant_crm(p_tenant_slug VARCHAR(100))
RETURNS BOOLEAN AS $$
BEGIN
  UPDATE tenants
  SET is_provisioned = true, updated_at = NOW()
  WHERE slug = p_tenant_slug;

  RETURN FOUND;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- Fonction: get_user_for_login
-- Récupère les infos user pour authentification
-- ============================================================
CREATE OR REPLACE FUNCTION get_user_for_login(p_email VARCHAR(255))
RETURNS TABLE(
  user_id UUID,
  email VARCHAR(255),
  password_hash VARCHAR(255),
  user_name VARCHAR(255),
  tenant_slug VARCHAR(100),
  tenant_name VARCHAR(255),
  role VARCHAR(50),
  plan VARCHAR(50),
  is_provisioned BOOLEAN
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    u.id,
    u.email,
    u.password_hash,
    u.name,
    t.slug,
    t.name,
    m.role,
    t.plan,
    t.is_provisioned
  FROM users u
  JOIN memberships m ON m.user_id = u.id AND m.is_active = true
  JOIN tenants t ON t.id = m.tenant_id AND t.is_active = true
  WHERE u.email = p_email AND u.is_active = true
  LIMIT 1;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- Migration des données existantes
-- ============================================================

-- Créer le tenant macrea s'il n'existe pas dans la nouvelle table
DO $$
DECLARE
  v_user_id UUID;
  v_tenant_id UUID;
BEGIN
  -- Créer l'utilisateur admin@macrea.fr
  INSERT INTO users (id, email, password_hash, name)
  VALUES (
    'a0000000-0000-0000-0000-000000000001'::UUID,
    'admin@macrea.fr',
    '$2b$10$uqTA8M3exzcDBy4PgwdYb.QixVnsJ4WfCEdMgZd5J8Qbj21fUJS9O', -- admin123
    'Admin MaCréa'
  )
  ON CONFLICT (email) DO NOTHING;

  -- Créer le tenant macrea
  INSERT INTO tenants (id, slug, name, plan, is_provisioned)
  VALUES (
    'b0000000-0000-0000-0000-000000000001'::UUID,
    'macrea',
    'MaCréa',
    'starter_whatsapp',
    true
  )
  ON CONFLICT (slug) DO NOTHING;

  -- Créer le membership
  INSERT INTO memberships (user_id, tenant_id, role)
  VALUES (
    'a0000000-0000-0000-0000-000000000001'::UUID,
    'b0000000-0000-0000-0000-000000000001'::UUID,
    'owner'
  )
  ON CONFLICT (user_id, tenant_id) DO NOTHING;

  -- Créer l'utilisateur demo@democlient.com
  INSERT INTO users (id, email, password_hash, name)
  VALUES (
    'a0000000-0000-0000-0000-000000000002'::UUID,
    'demo@democlient.com',
    '$2b$10$yU.SodR882sVQ4MqsGpCLuzYCLo9woyV1P9I1WxpjFbiket.hZNC.', -- demo123
    'Demo User'
  )
  ON CONFLICT (email) DO NOTHING;

  -- Créer le tenant demo_client
  INSERT INTO tenants (id, slug, name, plan, is_provisioned)
  VALUES (
    'b0000000-0000-0000-0000-000000000002'::UUID,
    'demo_client',
    'Demo Client',
    'starter',
    true
  )
  ON CONFLICT (slug) DO NOTHING;

  -- Créer le membership
  INSERT INTO memberships (user_id, tenant_id, role)
  VALUES (
    'a0000000-0000-0000-0000-000000000002'::UUID,
    'b0000000-0000-0000-0000-000000000002'::UUID,
    'owner'
  )
  ON CONFLICT (user_id, tenant_id) DO NOTHING;
END $$;

-- ============================================================
-- RLS (Row Level Security) - Isolation par tenant
-- ============================================================

-- Note: RLS est activé uniquement si vous utilisez Supabase avec anon/authenticated roles
-- Pour le backend Node.js avec service role, RLS n'est pas appliqué (bypass)

-- Activer RLS sur les tables sensibles
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE tenants ENABLE ROW LEVEL SECURITY;
ALTER TABLE memberships ENABLE ROW LEVEL SECURITY;

-- Policy: Un user ne peut voir que ses propres données
CREATE POLICY users_self_access ON users
  FOR ALL
  USING (id = auth.uid())
  WITH CHECK (id = auth.uid());

-- Policy: Un user ne peut voir que les tenants dont il est membre
CREATE POLICY tenants_member_access ON tenants
  FOR SELECT
  USING (
    id IN (
      SELECT tenant_id FROM memberships
      WHERE user_id = auth.uid() AND is_active = true
    )
  );

-- Policy: Un user ne peut voir que ses propres memberships
CREATE POLICY memberships_self_access ON memberships
  FOR ALL
  USING (user_id = auth.uid())
  WITH CHECK (user_id = auth.uid());

-- RLS sur whatsapp_billing (isolation par tenant_id)
ALTER TABLE whatsapp_billing ENABLE ROW LEVEL SECURITY;

CREATE POLICY whatsapp_billing_tenant_access ON whatsapp_billing
  FOR ALL
  USING (
    tenant_id IN (
      SELECT t.slug FROM tenants t
      JOIN memberships m ON m.tenant_id = t.id
      WHERE m.user_id = auth.uid() AND m.is_active = true
    )
  );

-- RLS sur tenant_features (isolation par tenant_id)
ALTER TABLE tenant_features ENABLE ROW LEVEL SECURITY;

CREATE POLICY tenant_features_tenant_access ON tenant_features
  FOR ALL
  USING (
    tenant_id IN (
      SELECT t.slug FROM tenants t
      JOIN memberships m ON m.tenant_id = t.id
      WHERE m.user_id = auth.uid() AND m.is_active = true
    )
  );

-- Note: Les policies ci-dessus utilisent auth.uid() de Supabase
-- Pour fonctionner, le frontend doit utiliser supabase-js avec un token JWT Supabase
-- Le backend Node.js utilise le service_role qui bypass RLS

-- ============================================================
-- Commentaires
-- ============================================================
COMMENT ON TABLE users IS 'Utilisateurs authentifiés du système';
COMMENT ON TABLE tenants IS 'Organisations/entreprises avec leur plan';
COMMENT ON TABLE memberships IS 'Lien user<->tenant avec rôle';
COMMENT ON TABLE tenant_plans IS 'Définition des plans disponibles';
COMMENT ON FUNCTION create_tenant_with_owner IS 'Crée un tenant + owner en transaction atomique';
COMMENT ON FUNCTION provision_tenant_crm IS 'Marque un tenant comme provisionné dans le CRM';
COMMENT ON FUNCTION get_user_for_login IS 'Récupère les infos user pour authentification';