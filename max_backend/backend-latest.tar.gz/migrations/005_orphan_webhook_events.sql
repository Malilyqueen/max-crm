-- Migration: Create orphan_webhook_events table
-- Purpose: Store webhook events that couldn't be matched to a tenant
-- Security: NEVER write to a tenant without proper resolution

-- Table for orphan/unmatched webhook events
CREATE TABLE IF NOT EXISTS orphan_webhook_events (
  id TEXT PRIMARY KEY,
  channel TEXT NOT NULL, -- 'email' | 'sms' | 'whatsapp'
  provider TEXT NOT NULL, -- 'mailjet' | 'twilio' | 'greenapi'
  reason TEXT NOT NULL, -- 'no_match' | 'ambiguous' | 'no_tenant_id'
  contact_identifier TEXT, -- email, phone, or waId that couldn't be matched
  provider_message_id TEXT, -- MessageID/SID from provider
  candidates JSONB, -- If ambiguous, list of {leadId, tenantId} candidates
  raw_payload JSONB, -- Full webhook payload for debugging
  created_at TIMESTAMPTZ DEFAULT NOW(),

  -- For analytics/monitoring
  resolved_at TIMESTAMPTZ, -- If manually resolved later
  resolved_to_tenant TEXT, -- Which tenant it was resolved to (if any)
  resolved_by TEXT -- Who resolved it (admin email)
);

-- Indexes for monitoring and cleanup
CREATE INDEX IF NOT EXISTS idx_orphan_webhook_channel ON orphan_webhook_events(channel);
CREATE INDEX IF NOT EXISTS idx_orphan_webhook_reason ON orphan_webhook_events(reason);
CREATE INDEX IF NOT EXISTS idx_orphan_webhook_created_at ON orphan_webhook_events(created_at);
CREATE INDEX IF NOT EXISTS idx_orphan_webhook_provider_message_id ON orphan_webhook_events(provider_message_id);

-- Comment
COMMENT ON TABLE orphan_webhook_events IS 'Stores webhook events that could not be matched to a specific tenant. Critical for security audit and debugging cross-tenant issues.';
