-- Migration 010: Table tenant_settings
-- Paramètres généraux par tenant (dont email reply-to pour Mode 1)

CREATE TABLE IF NOT EXISTS tenant_settings (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL UNIQUE,

  -- Email settings (Mode 1)
  email_reply_to VARCHAR(255), -- Email de réponse (OBLIGATOIRE pour Mode 1)
  email_from_name VARCHAR(255), -- Nom expéditeur custom (optionnel)

  -- Quota monitoring
  email_quota_limit INTEGER DEFAULT 1000, -- Quota emails/mois (défaut: 1000)
  email_quota_alerts BOOLEAN DEFAULT TRUE, -- Alertes quota
  email_quota_alert_threshold INTEGER DEFAULT 900, -- Seuil alerte (défaut: 90%)

  -- Metadata
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

-- Index
CREATE INDEX idx_tenant_settings_tenant ON tenant_settings(tenant_id);

-- Trigger updated_at
CREATE OR REPLACE FUNCTION update_tenant_settings_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_tenant_settings_updated_at
  BEFORE UPDATE ON tenant_settings
  FOR EACH ROW
  EXECUTE FUNCTION update_tenant_settings_updated_at();

-- Commentaires
COMMENT ON TABLE tenant_settings IS 'Paramètres généraux par tenant';
COMMENT ON COLUMN tenant_settings.email_reply_to IS 'Email de réponse (REPLY-TO) utilisé en Mode 1 (default) - OBLIGATOIRE';
COMMENT ON COLUMN tenant_settings.email_from_name IS 'Nom expéditeur personnalisé (optionnel, défaut: M.A.X. CRM)';
COMMENT ON COLUMN tenant_settings.email_quota_limit IS 'Quota emails/mois inclus (défaut: 1000)';
COMMENT ON COLUMN tenant_settings.email_quota_alerts IS 'Activer alertes quota (email + UI)';
COMMENT ON COLUMN tenant_settings.email_quota_alert_threshold IS 'Seuil alerte en nombre d''emails (défaut: 900 = 90%)';

-- Fonction helper: Créer settings par défaut pour un tenant
CREATE OR REPLACE FUNCTION ensure_tenant_settings(p_tenant_id VARCHAR(100))
RETURNS VOID AS $$
BEGIN
  INSERT INTO tenant_settings (tenant_id, email_quota_limit)
  VALUES (p_tenant_id, 1000)
  ON CONFLICT (tenant_id) DO NOTHING;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION ensure_tenant_settings IS 'Crée un enregistrement tenant_settings par défaut si inexistant';

-- Données exemple (à supprimer en production)
-- INSERT INTO tenant_settings (tenant_id, email_reply_to, email_from_name)
-- VALUES ('macrea-admin', 'jules@studiomacrea.cloud', 'MaCréa Team');
