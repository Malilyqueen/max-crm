-- =====================================================
-- Migration: Fix create_tenant_with_owner function
-- Version: 022
-- Description: Corriger l'ambiguité de colonne tenant_id
-- =====================================================

-- D'abord supprimer la fonction existante (signature differente)
DROP FUNCTION IF EXISTS create_tenant_with_owner(UUID, VARCHAR, VARCHAR, VARCHAR);

-- Recreer la fonction avec des noms de colonnes non ambigus
CREATE OR REPLACE FUNCTION create_tenant_with_owner(
  p_user_id UUID,
  p_tenant_name VARCHAR(255),
  p_tenant_slug VARCHAR(100),
  p_plan VARCHAR(50) DEFAULT 'starter'
)
RETURNS TABLE(
  out_tenant_id UUID,
  out_membership_id UUID,
  out_success BOOLEAN,
  out_error_message TEXT
) AS $$
DECLARE
  v_tenant_id UUID;
  v_membership_id UUID;
  v_plan_exists BOOLEAN;
BEGIN
  -- Verifier que le plan existe
  SELECT EXISTS(SELECT 1 FROM tenant_plans WHERE id = p_plan AND is_active = true) INTO v_plan_exists;

  IF NOT v_plan_exists THEN
    RETURN QUERY SELECT NULL::UUID, NULL::UUID, false, 'Plan invalide: ' || p_plan;
    RETURN;
  END IF;

  -- Verifier que le slug n'existe pas
  IF EXISTS(SELECT 1 FROM tenants WHERE slug = p_tenant_slug) THEN
    RETURN QUERY SELECT NULL::UUID, NULL::UUID, false, 'Ce nom d''entreprise est deja pris';
    RETURN;
  END IF;

  -- Creer le tenant
  INSERT INTO tenants (name, slug, plan, created_by)
  VALUES (p_tenant_name, p_tenant_slug, p_plan, p_user_id)
  RETURNING id INTO v_tenant_id;

  -- Creer le membership owner
  INSERT INTO memberships (user_id, tenant_id, role)
  VALUES (p_user_id, v_tenant_id, 'owner')
  RETURNING id INTO v_membership_id;

  -- Creer l'entree tenant_features (synchronise avec le plan)
  INSERT INTO tenant_features (tenant_id, whatsapp_enabled, sms_enabled, email_enabled, campaigns_enabled)
  SELECT
    p_tenant_slug,
    tp.whatsapp_enabled,
    tp.sms_enabled,
    tp.email_enabled,
    tp.campaigns_enabled
  FROM tenant_plans tp
  WHERE tp.id = p_plan
  ON CONFLICT (tenant_id) DO UPDATE SET
    whatsapp_enabled = EXCLUDED.whatsapp_enabled,
    sms_enabled = EXCLUDED.sms_enabled,
    email_enabled = EXCLUDED.email_enabled,
    campaigns_enabled = EXCLUDED.campaigns_enabled,
    updated_at = NOW();

  -- Creer l'entree whatsapp_billing si WhatsApp active
  IF EXISTS(SELECT 1 FROM tenant_plans WHERE id = p_plan AND whatsapp_enabled = true) THEN
    INSERT INTO whatsapp_billing (
      tenant_id,
      subscription_active,
      included_messages,
      subscription_started_at,
      subscription_expires_at
    )
    SELECT
      p_tenant_slug,
      true,
      tp.whatsapp_messages_included,
      NOW(),
      NOW() + INTERVAL '1 month'
    FROM tenant_plans tp
    WHERE tp.id = p_plan
    ON CONFLICT (tenant_id) DO UPDATE SET
      subscription_active = true,
      included_messages = EXCLUDED.included_messages,
      included_messages_used = 0,
      subscription_started_at = NOW(),
      subscription_expires_at = NOW() + INTERVAL '1 month',
      updated_at = NOW();
  ELSE
    -- Creer entree inactive pour WhatsApp (visible mais bloque)
    INSERT INTO whatsapp_billing (tenant_id, subscription_active, included_messages)
    VALUES (p_tenant_slug, false, 0)
    ON CONFLICT (tenant_id) DO NOTHING;
  END IF;

  RETURN QUERY SELECT v_tenant_id, v_membership_id, true, NULL::TEXT;
END;
$$ LANGUAGE plpgsql;