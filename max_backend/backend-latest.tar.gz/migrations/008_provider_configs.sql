/**
 * Migration 008: Provider Configurations Self-Service
 *
 * Objectif: Permettre aux tenants de configurer leurs propres credentials
 * pour Mailjet, Twilio, Green-API sans intervention MaCréa.
 *
 * Sécurité: Credentials chiffrés en AES-256-GCM côté application
 * (la colonne encrypted_config stocke le blob chiffré, jamais du plaintext)
 */

-- Table principale: configurations providers par tenant
CREATE TABLE IF NOT EXISTS tenant_provider_configs (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL,

  -- Provider type: 'mailjet', 'sendgrid', 'smtp', 'gmail', 'twilio_sms', 'twilio_whatsapp', 'greenapi_whatsapp'
  provider_type VARCHAR(50) NOT NULL,

  -- Nom custom optionnel (ex: "Mailjet Production", "Twilio Dev")
  provider_name VARCHAR(255),

  -- Credentials CHIFFRÉES en AES-256-GCM (JSON stringifié puis chiffré)
  -- Ex pour Mailjet: {"apiKey": "...", "apiSecret": "..."}
  -- Ex pour Twilio: {"accountSid": "...", "authToken": "...", "phoneNumber": "+33..."}
  -- Ex pour Green-API: {"instanceId": "...", "token": "..."}
  encrypted_config TEXT NOT NULL,

  -- Statut du test de connexion
  connection_status VARCHAR(20) DEFAULT 'non_testé' CHECK (connection_status IN ('non_testé', 'success', 'failed')),

  -- Dernière erreur de test (si failed)
  last_test_error TEXT,

  -- Timestamp du dernier test
  last_tested_at TIMESTAMP,

  -- Provider actif pour ce tenant (un seul actif par provider_type)
  is_active BOOLEAN DEFAULT false,

  -- Métadonnées
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  created_by VARCHAR(100), -- user_id qui a créé la config
  updated_by VARCHAR(100), -- user_id de la dernière modification

  -- Contraintes
  UNIQUE (tenant_id, provider_type, provider_name),

  -- Index pour recherche rapide
  CHECK (LENGTH(encrypted_config) > 0)
);

-- Index pour recherche rapide par tenant
CREATE INDEX IF NOT EXISTS idx_provider_configs_tenant
  ON tenant_provider_configs(tenant_id);

-- Index pour récupérer le provider actif d'un tenant
CREATE INDEX IF NOT EXISTS idx_provider_configs_active
  ON tenant_provider_configs(tenant_id, provider_type, is_active);

-- Trigger pour mettre à jour updated_at automatiquement
CREATE OR REPLACE FUNCTION update_provider_config_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_provider_config_timestamp
  BEFORE UPDATE ON tenant_provider_configs
  FOR EACH ROW
  EXECUTE FUNCTION update_provider_config_timestamp();

-- Contrainte: Un seul provider actif par type et par tenant
-- (géré au niveau application car contrainte partielle complexe en SQL)

-- Commentaires pour documentation
COMMENT ON TABLE tenant_provider_configs IS
  'Configurations des providers (email, SMS, WhatsApp) par tenant. Credentials stockés chiffrés en AES-256-GCM.';

COMMENT ON COLUMN tenant_provider_configs.encrypted_config IS
  'JSON chiffré contenant les credentials. JAMAIS stocker en plaintext. Déchiffré uniquement en mémoire applicative.';

COMMENT ON COLUMN tenant_provider_configs.connection_status IS
  'Statut du dernier test de connexion: non_testé (jamais testé), success (OK), failed (échec)';

COMMENT ON COLUMN tenant_provider_configs.is_active IS
  'Un seul provider actif par type et par tenant. Utilisé pour les envois automatiques.';

-- Grant permissions (ajuster selon votre setup)
-- GRANT SELECT, INSERT, UPDATE, DELETE ON tenant_provider_configs TO your_app_user;
-- GRANT USAGE, SELECT ON SEQUENCE tenant_provider_configs_id_seq TO your_app_user;