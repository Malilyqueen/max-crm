-- Migration 005: Création table tenant_features
-- Date: 2026-01-12
-- Objectif: Feature flags par tenant (whatsapp_enabled pour billing +15€/mois)

-- Table tenant_features
CREATE TABLE IF NOT EXISTS tenant_features (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(255) NOT NULL UNIQUE,

  -- Feature flags
  whatsapp_enabled BOOLEAN DEFAULT false,
  sms_enabled BOOLEAN DEFAULT false,
  email_enabled BOOLEAN DEFAULT false,
  campaigns_enabled BOOLEAN DEFAULT false,

  -- Limites mensuelles (optionnel pour phase future)
  whatsapp_monthly_limit INTEGER DEFAULT NULL, -- NULL = illimité
  sms_monthly_limit INTEGER DEFAULT NULL,
  email_monthly_limit INTEGER DEFAULT NULL,

  -- Méta
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  updated_by VARCHAR(255)
);

-- Index pour recherche rapide par tenant
CREATE INDEX IF NOT EXISTS idx_tenant_features_tenant ON tenant_features(tenant_id);

-- Commentaires
COMMENT ON TABLE tenant_features IS 'Feature flags par tenant pour contrôle billing et activation canaux';
COMMENT ON COLUMN tenant_features.whatsapp_enabled IS 'WhatsApp activé (+15€/mois)';
COMMENT ON COLUMN tenant_features.sms_enabled IS 'SMS activé (inclus de base ou add-on)';
COMMENT ON COLUMN tenant_features.email_enabled IS 'Email activé (inclus de base)';
COMMENT ON COLUMN tenant_features.campaigns_enabled IS 'Module campagnes activé (futur)';

-- Trigger pour auto-update updated_at
CREATE OR REPLACE FUNCTION update_tenant_features_timestamp()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_tenant_features_updated_at
  BEFORE UPDATE ON tenant_features
  FOR EACH ROW
  EXECUTE FUNCTION update_tenant_features_timestamp();

-- Données initiales: Activer tous les features pour tenant 'macrea' (admin/dev)
INSERT INTO tenant_features (tenant_id, whatsapp_enabled, sms_enabled, email_enabled, campaigns_enabled)
VALUES ('macrea', true, true, true, true)
ON CONFLICT (tenant_id) DO UPDATE SET
  whatsapp_enabled = true,
  sms_enabled = true,
  email_enabled = true,
  campaigns_enabled = true,
  updated_at = NOW();

-- Notes de déploiement:
-- 1. Pour activer WhatsApp pour un tenant:
--    UPDATE tenant_features SET whatsapp_enabled = true WHERE tenant_id = 'client_xyz';
-- 2. Pour désactiver (non paiement):
--    UPDATE tenant_features SET whatsapp_enabled = false WHERE tenant_id = 'client_xyz';
-- 3. Vérifier état d'un tenant:
--    SELECT tenant_id, whatsapp_enabled, sms_enabled FROM tenant_features WHERE tenant_id = 'client_xyz';