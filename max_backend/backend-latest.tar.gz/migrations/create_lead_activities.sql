-- Migration: Système d'Alertes Vivantes M.A.X.
-- Table: lead_activities
-- Track TOUTES les interactions avec les leads

CREATE TABLE IF NOT EXISTS lead_activities (
  id VARCHAR(17) PRIMARY KEY,
  lead_id VARCHAR(17) NOT NULL,
  channel ENUM('whatsapp', 'email', 'call', 'manual') NOT NULL,
  direction ENUM('in', 'out') NOT NULL,
  status ENUM('sent', 'delivered', 'replied', 'no_answer', 'read', 'clicked') DEFAULT 'sent',
  message_preview TEXT,
  metadata JSON,
  timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,

  INDEX idx_lead_timestamp (lead_id, timestamp DESC),
  INDEX idx_channel (channel),
  INDEX idx_status (status),
  INDEX idx_direction (direction)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Table: max_alerts
-- Alertes générées automatiquement par M.A.X.

CREATE TABLE IF NOT EXISTS max_alerts (
  id VARCHAR(17) PRIMARY KEY,
  lead_id VARCHAR(17) NOT NULL,
  type ENUM('NoContact7d', 'NoReply3d', 'NoFollowup7d', 'PreferredChannel', 'HotLead24h', 'StaleLead30d') NOT NULL,
  severity ENUM('info', 'medium', 'high', 'urgent') NOT NULL,
  message TEXT NOT NULL,
  suggested_action VARCHAR(255),
  metadata JSON,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME DEFAULT NULL,

  INDEX idx_lead (lead_id),
  INDEX idx_type (type),
  INDEX idx_unresolved (resolved_at),
  INDEX idx_severity (severity),
  INDEX idx_created (created_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Vue: Alertes actives (non résolues)
CREATE OR REPLACE VIEW active_alerts AS
SELECT
  a.*,
  l.name AS lead_name,
  l.emailAddress AS lead_email,
  l.phoneNumber AS lead_phone
FROM max_alerts a
LEFT JOIN lead l ON a.lead_id = l.id
WHERE a.resolved_at IS NULL
ORDER BY
  FIELD(a.severity, 'urgent', 'high', 'medium', 'info'),
  a.created_at DESC;
