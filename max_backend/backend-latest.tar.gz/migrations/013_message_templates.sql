/**
 * Migration 013: Message Templates
 *
 * Permet la persistance des templates Email/SMS/WhatsApp
 * Remplace les templates hardcodés dans TemplatesSection.tsx
 *
 * Utilisé par:
 * - Pilote Automatique (sélection de template)
 * - MAX (création de brouillons via chat)
 * - Campagnes (sélection de template existant)
 */

-- Table: message_templates
CREATE TABLE IF NOT EXISTS message_templates (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id VARCHAR(100) NOT NULL,

  -- Identification
  channel VARCHAR(20) NOT NULL CHECK (channel IN ('email', 'sms', 'whatsapp')),
  name VARCHAR(255) NOT NULL,
  category VARCHAR(50) DEFAULT 'general' CHECK (category IN ('vente', 'support', 'marketing', 'facturation', 'securite', 'general')),

  -- Contenu
  subject VARCHAR(500), -- Email only
  content TEXT NOT NULL,

  -- Variables détectées (ex: ["firstName", "company", "appointmentDate"])
  variables JSONB DEFAULT '[]'::jsonb,

  -- Metadata WhatsApp (optionnel)
  whatsapp_from VARCHAR(50), -- ex: whatsapp:+14155238886
  whatsapp_content_sid VARCHAR(100), -- Twilio Content SID

  -- Statut
  status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'archived')),

  -- Origine
  created_by VARCHAR(255), -- 'user' ou 'max'

  -- Audit
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  -- Contraintes
  CONSTRAINT message_templates_tenant_check CHECK (tenant_id IS NOT NULL AND tenant_id != ''),
  CONSTRAINT message_templates_content_check CHECK (content IS NOT NULL AND content != '')
);

-- Indexes
CREATE INDEX idx_message_templates_tenant ON message_templates(tenant_id);
CREATE INDEX idx_message_templates_channel ON message_templates(channel);
CREATE INDEX idx_message_templates_status ON message_templates(status);
CREATE INDEX idx_message_templates_category ON message_templates(category);
CREATE INDEX idx_message_templates_tenant_channel ON message_templates(tenant_id, channel);

-- Trigger: Auto-update updated_at
CREATE OR REPLACE FUNCTION update_message_templates_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER message_templates_updated_at
BEFORE UPDATE ON message_templates
FOR EACH ROW
EXECUTE FUNCTION update_message_templates_updated_at();

-- Fonction: Extraire les variables d'un template
-- Détecte les patterns {{variableName}}
CREATE OR REPLACE FUNCTION extract_template_variables(template_content TEXT)
RETURNS JSONB AS $$
DECLARE
  variables JSONB := '[]'::jsonb;
  matches TEXT[];
  match TEXT;
BEGIN
  -- Regex pour trouver tous les {{xxx}}
  SELECT ARRAY(
    SELECT DISTINCT (regexp_matches(template_content, '\{\{([a-zA-Z_][a-zA-Z0-9_]*)\}\}', 'g'))[1]
  ) INTO matches;

  IF matches IS NOT NULL THEN
    FOREACH match IN ARRAY matches
    LOOP
      variables := variables || to_jsonb(match);
    END LOOP;
  END IF;

  RETURN variables;
END;
$$ LANGUAGE plpgsql IMMUTABLE;

-- Trigger: Auto-extract variables on insert/update
CREATE OR REPLACE FUNCTION auto_extract_template_variables()
RETURNS TRIGGER AS $$
BEGIN
  -- Combiner subject + content pour l'extraction
  NEW.variables := extract_template_variables(
    COALESCE(NEW.subject, '') || ' ' || COALESCE(NEW.content, '')
  );
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER message_templates_extract_variables
BEFORE INSERT OR UPDATE ON message_templates
FOR EACH ROW
EXECUTE FUNCTION auto_extract_template_variables();

-- Comments
COMMENT ON TABLE message_templates IS 'Templates réutilisables pour Email/SMS/WhatsApp';
COMMENT ON COLUMN message_templates.variables IS 'Variables détectées automatiquement: ["firstName", "company", ...]';
COMMENT ON COLUMN message_templates.status IS 'draft=brouillon MAX, active=utilisable, archived=désactivé';
COMMENT ON COLUMN message_templates.created_by IS 'user=créé manuellement, max=généré par M.A.X.';
COMMENT ON FUNCTION extract_template_variables IS 'Extrait les {{variables}} d''un template';
