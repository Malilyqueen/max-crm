-- Migration 007 FIX: Corriger user_id INTEGER -> VARCHAR
-- Le système d'auth JWT utilise des user_id string ("user_admin_001")
-- mais le schéma SQL attendait des INTEGER

-- 1. Modifier support_tickets.user_id
ALTER TABLE support_tickets
  ALTER COLUMN user_id TYPE VARCHAR(100) USING user_id::VARCHAR;

-- 2. Modifier support_messages.user_id
ALTER TABLE support_messages
  ALTER COLUMN user_id TYPE VARCHAR(100) USING user_id::VARCHAR;

-- Vérification
DO $$
BEGIN
  RAISE NOTICE '✅ Migration 007 FIX appliquée : user_id est maintenant VARCHAR(100)';
  RAISE NOTICE 'Tables modifiées: support_tickets, support_messages';
END $$;