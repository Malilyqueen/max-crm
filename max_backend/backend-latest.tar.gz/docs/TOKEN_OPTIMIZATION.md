# Optimisation de la consommation de tokens M.A.X.

## Problème identifié (11 Nov 2025)

**Avant optimisation:**
- 13,289 tokens par tâche
- Messages vides répétés
- Boucles infinies sur tâches impossibles
- Budget épuisé rapidement

**Après optimisation:**
- **5,994 tokens** par tâche de création de champ complet
- Réduction de **55%**
- Pas de boucles, pas de messages vides
- Exécution réussie du premier coup

---

## Causes principales de gaspillage de tokens

### 1. Instructions contradictoires dans `agent_identity.json`

**❌ Problème:**
```json
{
  "ce_que_je_ne_peux_pas_faire": [
    "Modifier les layouts - ❌ Nécessite l'interface graphique"
  ]
}
```

M.A.X. perd des tokens à expliquer pourquoi il ne peut pas faire quelque chose qu'il PEUT faire maintenant.

**✅ Solution:**
```json
{
  "capacites_local_admin": {
    "ce_que_je_peux_faire": [
      "Modifier les layouts directement via JSON (✅ Filesystem)",
      "Automatisation COMPLÈTE : Champ → Layouts → Rebuild"
    ],
    "workflow_automatise": "utilise configure_entity_layout avec createField=true"
  }
}
```

### 2. Outils manquants dans la liste `allowed`

**❌ Problème:**
```json
{
  "tools": {
    "allowed": ["update_lead_fields", "get_lead_snapshot"]
  }
}
```

M.A.X. ne sait pas qu'il a accès à `configure_entity_layout`.

**✅ Solution:**
```json
{
  "tools": {
    "allowed": ["update_lead_fields", "get_lead_snapshot", "configure_entity_layout"],
    "preferred": {
      "for_field_creation_with_visibility": "configure_entity_layout"
    }
  }
}
```

### 3. Limit de tokens trop élevée par défaut

**❌ Problème:**
```javascript
// aiClient.js
max_tokens = 1024  // Valeur par défaut
```

**✅ Solution:**
```javascript
// aiClient.js
max_tokens = Number(process.env.MAX_RESPONSE_TOKENS) || 900
```

Et dans `.env`:
```env
MAX_RESPONSE_TOKENS=900
```

---

## Meilleures pratiques pour éviter le gaspillage

### 1. Toujours mettre à jour `agent_identity.json` après chaque nouvelle feature

**Checklist:**
- [ ] Ajouter le nouveau tool à `tools.allowed`
- [ ] Mettre à jour `capacites_local_admin` (ou équivalent)
- [ ] Supprimer les anciennes limitations devenues obsolètes
- [ ] Ajouter des exemples d'usage si complexe

### 2. Utiliser des prompts système concis

**❌ Mauvais:**
```
"Pour créer un champ, vous devez d'abord vérifier s'il existe, puis si non, le créer via l'API admin en utilisant les credentials, puis attendre la confirmation, puis..."
```

**✅ Bon:**
```
"Pour créer et rendre visible un champ: utilise configure_entity_layout avec createField=true."
```

### 3. Définir des workflows clairs

**Structure recommandée dans `agent_identity.json`:**
```json
{
  "workflows": {
    "create_visible_field": {
      "tool": "configure_entity_layout",
      "params": {
        "entity": "Lead",
        "fieldName": "nomDuChamp",
        "createField": true,
        "fieldDefinition": {
          "type": "varchar",
          "label": "Label"
        }
      },
      "steps": "createField → addToLayouts → clearCache → rebuild",
      "tokens_expected": "~6000"
    }
  }
}
```

### 4. Monitorer la consommation

**Ajouter des logs dans le code:**
```javascript
// routes/chat.js
console.log(`[ChatRoute] Tokens utilisés: ${result.usage.total_tokens}`);
console.log(`[ChatRoute] Tools appelés: ${toolCalls.map(t => t.name).join(', ')}`);
```

**Vérifier régulièrement:**
```bash
curl http://127.0.0.1:3005/api/health
# Vérifie tokens_used, calls, avgTokensPerTask
```

### 5. Limiter la profondeur de contexte

**Dans `conversationService.js`:**
```javascript
export function getContextMessages(conversation, limit = 10) {
  // Limite à 10 messages au lieu de tout l'historique
  return conversation.messages.slice(-limit);
}
```

Moins de contexte = moins de tokens input.

---

## Métriques cibles

### Par type de tâche

| Tâche | Tokens attendus | Acceptable | ⚠️ Alert |
|-------|----------------|------------|----------|
| Créer champ simple | 3,000 - 4,000 | 5,000 | > 6,000 |
| Créer champ + layouts + rebuild | 5,000 - 7,000 | 8,000 | > 10,000 |
| Update lead data (1 lead) | 2,000 - 3,000 | 4,000 | > 5,000 |
| Batch update (10 leads) | 4,000 - 6,000 | 7,000 | > 9,000 |
| Snapshot simple | 1,500 - 2,500 | 3,000 | > 4,000 |

### Budget global

**Budget total**: 1,000,000 tokens

**Avec optimisation actuelle (5,994 tokens/tâche):**
- **166 tâches** de création de champs possibles
- Si moyenne 3,000 tokens/tâche: **333 tâches**
- Si dérive vers 10,000 tokens/tâche: **100 tâches** (alerte!)

**Seuils d'alerte:**
- 🟢 < 5,000 tokens/tâche = OK
- 🟡 5,000 - 8,000 tokens/tâche = Acceptable
- 🟠 8,000 - 12,000 tokens/tâche = À surveiller
- 🔴 > 12,000 tokens/tâche = PROBLÈME (investiguer)

---

## Outils de diagnostic

### 1. Script PowerShell de monitoring

Créer `monitor_tokens.ps1`:
```powershell
$response = Invoke-RestMethod -Uri "http://127.0.0.1:3005/api/health"

$usage = $response.tokens
$remaining = $usage.budgetTotal - $usage.total
$percentUsed = ($usage.total / $usage.budgetTotal) * 100

Write-Host "Tokens utilisés: $($usage.total) / $($usage.budgetTotal)" -ForegroundColor Cyan
Write-Host "Restants: $remaining ($([math]::Round(100 - $percentUsed, 2))%)" -ForegroundColor Green
Write-Host "Moyenne par tâche: $($usage.avgTokensPerTask)" -ForegroundColor Yellow
Write-Host "Nombre de calls: $($usage.calls)" -ForegroundColor Gray

if ($usage.avgTokensPerTask -gt 8000) {
    Write-Host "⚠️ ALERTE: Consommation élevée!" -ForegroundColor Red
}
```

### 2. Route d'analyse dans le backend

Ajouter dans `routes/health.js`:
```javascript
router.get('/token-analysis', (req, res) => {
  const state = loadTokenState();

  const analysis = {
    ...state,
    efficiency: state.avgTokensPerTask < 6000 ? 'GOOD' :
                state.avgTokensPerTask < 10000 ? 'ACCEPTABLE' : 'POOR',
    estimatedRemainingTasks: Math.floor((state.budgetTotal - state.total) / state.avgTokensPerTask),
    recommendations: []
  };

  if (state.avgTokensPerTask > 8000) {
    analysis.recommendations.push('Vérifier agent_identity.json pour instructions contradictoires');
  }

  if (state.calls > 0 && state.outputTotal / state.calls > 500) {
    analysis.recommendations.push('Réponses trop longues, réduire output_tokens');
  }

  res.json(analysis);
});
```

### 3. Logs détaillés par outil

Dans `routes/chat.js`, ajouter après chaque tool call:
```javascript
console.log(`[Tool ${toolName}] Tokens: input=${tokensInput}, output=${tokensOutput}, total=${tokensTotal}`);
```

---

## Actions correctives si dérive détectée

### Si moyenne > 8,000 tokens/tâche

1. **Vérifier `agent_identity.json`:**
   - Chercher les "je ne peux pas" obsolètes
   - Simplifier les instructions
   - Supprimer les exemples trop verbeux

2. **Réduire le contexte:**
   ```javascript
   // conversationService.js
   getContextMessages(conversation, limit = 5) // au lieu de 10
   ```

3. **Auditer le system prompt:**
   ```bash
   # Voir la taille du prompt
   cat prompts/max_system_prompt_v2.txt | wc -c
   cat prompts/max_operational_rules.txt | wc -c
   ```
   Si > 10,000 caractères combinés, réduire.

4. **Forcer des réponses plus courtes:**
   ```env
   MAX_RESPONSE_TOKENS=600  # au lieu de 900
   ```

### Si boucles ou répétitions

1. **Ajouter un compteur de tentatives:**
   ```javascript
   if (conversation.retryCount > 3) {
     return { error: 'Max retries reached', suggestion: 'Check tool availability' };
   }
   ```

2. **Détecter les patterns de boucle:**
   ```javascript
   const lastMessages = conversation.messages.slice(-5);
   const identical = lastMessages.every(m => m.content === lastMessages[0].content);
   if (identical) {
     console.error('[LOOP DETECTED] Identical messages repeated');
     // Break the loop
   }
   ```

---

## Résumé: Checklist anti-gaspillage

**Avant de déployer une nouvelle feature:**

- [ ] Mise à jour `agent_identity.json` avec la nouvelle capacité
- [ ] Ajout du tool dans `tools.allowed`
- [ ] Suppression des anciennes limitations
- [ ] Test de consommation sur tâche type
- [ ] Vérification moyenne < 8,000 tokens
- [ ] Documentation du workflow dans `docs/`

**Monitoring continu:**

- [ ] Vérifier `/api/health` chaque semaine
- [ ] Analyser les logs pour détecter les boucles
- [ ] Comparer avgTokensPerTask avec le seuil (6,000)
- [ ] Si dérive > 20%, investiguer immédiatement

---

**Date:** 2025-11-11
**Version:** Token Optimization Guide v1.0
**Gains obtenus:** -55% de consommation (13,289 → 5,994 tokens)
