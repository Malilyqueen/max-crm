# Guide de Gestion des Tokens M.A.X.

## 📊 Vue d'ensemble

Ce guide explique comment gérer le budget de tokens pour M.A.X., effectuer des recharges et surveiller la consommation.

---

## 🎯 Configuration actuelle

### Budget et limites

| Paramètre | Valeur | Description |
|-----------|--------|-------------|
| **Budget initial** | 2,000,000 tokens | Budget de départ après augmentation |
| **Hard cap** | 10,000,000 tokens | Limite absolue (protection coût) |
| **Recharge min** | 100,000 tokens | Montant minimum par recharge |
| **Recharge max** | 5,000,000 tokens | Montant maximum par recharge |
| **Mot de passe admin** | M4xR3ch4rg3S3cur3!2025 | Requis pour recharges |

### Fichiers de configuration

- **`.env`** : Configuration budget et sécurité
- **`lib/tokenRecharge.js`** : Module de recharge
- **`routes/billing.js`** : API endpoints
- **`billing/recharges.jsonl`** : Historique des recharges
- **`billing/state.json`** : État actuel du budget

---

## 🔧 Utilisation

### 1. Monitoring du budget

#### Affichage simple
```powershell
.\MONITOR_TOKENS.ps1
```

Affiche :
- Budget actuel et consommé
- Pourcentage utilisé avec barre de progression
- Hard cap et capacité restante
- Tokens d'entrée/sortie et nombre d'appels
- Historique des recharges
- Coût en USD
- Alertes si budget < 10%

#### Mode surveillance continue
```powershell
.\MONITOR_TOKENS.ps1 -Watch -RefreshInterval 30
```

Met à jour l'affichage toutes les 30 secondes (Ctrl+C pour quitter).

#### Personnaliser le seuil d'alerte
```powershell
.\MONITOR_TOKENS.ps1 -AlertThreshold 20
```

Génère une alerte si le budget restant < 20%.

---

### 2. Recharge du budget

#### Méthode interactive (recommandée)
```powershell
.\RECHARGE_TOKENS.ps1
```

Le script vous guidera :
1. Affichage du statut actuel
2. Demande du montant à recharger
3. Demande du mot de passe admin
4. Confirmation et exécution

#### Méthode automatisée
```powershell
.\RECHARGE_TOKENS.ps1 -Amount 1000000 -Reason "Recharge mensuelle"
```

Puis entrez le mot de passe admin quand demandé.

#### Exemples de recharge

**Recharge standard (1M tokens)**
```powershell
.\RECHARGE_TOKENS.ps1 -Amount 1000000
```

**Recharge maximale (5M tokens)**
```powershell
.\RECHARGE_TOKENS.ps1 -Amount 5000000 -Reason "Preparation campagne marketing"
```

**Recharge minimale (100K tokens)**
```powershell
.\RECHARGE_TOKENS.ps1 -Amount 100000 -Reason "Test systeme"
```

---

### 3. API Endpoints

Tous les endpoints sont disponibles sur `http://localhost:3005/api/billing`

#### GET /api/billing/status
Récupère le statut complet du budget.

**Réponse :**
```json
{
  "ok": true,
  "currentBudget": 2000000,
  "consumed": 245678,
  "remaining": 1754322,
  "percentUsed": "12.28",
  "hardCap": 10000000,
  "remainingCapacity": 8000000,
  "totalRecharges": 0,
  "rechargeCount": 0,
  "alert": {
    "isLow": false,
    "percentRemaining": "87.72",
    "remaining": 1754322,
    "threshold": 10,
    "message": "✓ Budget OK: 87.72% remaining (1754322 tokens)"
  }
}
```

#### POST /api/billing/recharge
Effectue une recharge du budget.

**Request :**
```json
{
  "amount": 1000000,
  "password": "M4xR3ch4rg3S3cur3!2025",
  "reason": "Recharge mensuelle"
}
```

**Réponse (succès) :**
```json
{
  "ok": true,
  "success": true,
  "amount": 1000000,
  "previousBudget": 2000000,
  "newBudget": 3000000,
  "hardCap": 10000000,
  "remainingCapacity": 7000000,
  "reason": "Recharge mensuelle",
  "timestamp": "2025-11-16T14:30:00.000Z"
}
```

**Réponse (échec - mauvais mot de passe) :**
```json
{
  "ok": false,
  "success": false,
  "error": "Authentication failed: Invalid admin password"
}
```

**Réponse (échec - hard cap dépassé) :**
```json
{
  "ok": false,
  "success": false,
  "error": "Hard cap exceeded: 11000000 > 10000000. Cannot recharge.",
  "amount": 1000000,
  "currentBudget": 10000000,
  "newBudget": 11000000,
  "hardCap": 10000000,
  "maxAllowedRecharge": 0
}
```

#### GET /api/billing/history?limit=50
Récupère l'historique des recharges.

**Réponse :**
```json
{
  "ok": true,
  "count": 3,
  "history": [
    {
      "timestamp": "2025-11-16T14:30:00.000Z",
      "success": true,
      "amount": 1000000,
      "previousBudget": 2000000,
      "newBudget": 3000000,
      "reason": "Recharge mensuelle"
    },
    ...
  ]
}
```

#### GET /api/billing/alert?threshold=10
Vérifie les alertes de budget faible.

**Réponse :**
```json
{
  "ok": true,
  "isLow": false,
  "percentRemaining": "87.72",
  "remaining": 1754322,
  "threshold": 10,
  "message": "✓ Budget OK: 87.72% remaining (1754322 tokens)"
}
```

#### GET /api/billing/stats
Statistiques complètes du système.

**Réponse :**
```json
{
  "ok": true,
  "tokens": {
    "consumed": 245678,
    "input": 156789,
    "output": 88889,
    "calls": 234,
    "avgPerCall": 1049.5
  },
  "budget": {
    "current": 2000000,
    "remaining": 1754322,
    "percentUsed": "12.28",
    "hardCap": 10000000,
    "remainingCapacity": 8000000
  },
  "recharges": {
    "total": 0,
    "count": 0,
    "last": null
  },
  "cost": {
    "usd": 0.0614
  }
}
```

---

## 🔒 Sécurité

### Mot de passe admin

Le mot de passe admin est stocké dans `.env` :
```env
ADMIN_RECHARGE_PASSWORD=M4xR3ch4rg3S3cur3!2025
```

**⚠️ Important :**
- Ne partagez JAMAIS ce mot de passe
- Changez-le en production
- Utilisez un gestionnaire de mots de passe
- Le mot de passe est hashé (SHA-256) avant comparaison

### Protection Hard Cap

Le hard cap à 10M tokens empêche :
- Les recharges accidentelles massives
- Les dépassements de budget
- Les coûts incontrôlés

**Exemple :**
```
Budget actuel: 9,500,000 tokens
Tentative de recharge: 1,000,000 tokens
Résultat: REFUSÉ (9,500,000 + 1,000,000 = 10,500,000 > 10,000,000)
Recharge max autorisée: 500,000 tokens
```

### Traçabilité

Toutes les recharges (réussies ET échouées) sont loggées dans :
```
d:\Macrea\CRM\max_backend\billing\recharges.jsonl
```

Format JSONL (une ligne JSON par recharge) :
```json
{"timestamp":"2025-11-16T14:30:00.000Z","success":true,"amount":1000000,"previousBudget":2000000,"newBudget":3000000,"reason":"Recharge mensuelle"}
{"timestamp":"2025-11-16T15:00:00.000Z","success":false,"error":"Authentication failed: Invalid admin password","amount":500000}
```

---

## 📈 Stratégies de recharge

### Stratégie prudente (Production)

1. **Monitoring quotidien**
   ```powershell
   .\MONITOR_TOKENS.ps1
   ```

2. **Recharge quand < 20%**
   ```powershell
   .\RECHARGE_TOKENS.ps1 -Amount 1000000 -Reason "Maintenance mensuelle"
   ```

3. **Alertes automatiques**
   - Vérifier `/api/billing/alert` dans un cron job
   - Email si budget < 10%

### Stratégie agressive (Marketing/Campagnes)

1. **Recharge préventive**
   Avant une campagne, recharger 3-5M tokens

2. **Surveillance continue**
   ```powershell
   .\MONITOR_TOKENS.ps1 -Watch -RefreshInterval 15
   ```

3. **Budget tampon**
   Maintenir toujours 1M tokens de réserve

### Stratégie économique (Test/Dev)

1. **Recharges minimales**
   100K-500K tokens à la fois

2. **Monitoring hebdomadaire**
   Seulement quand nécessaire

3. **Hard cap bas**
   Réduire `MAX_BUDGET_HARD_CAP` dans `.env`

---

## 🚨 Résolution de problèmes

### Erreur : "Authentication failed"

**Cause :** Mot de passe incorrect

**Solution :**
1. Vérifiez le mot de passe dans `.env`
2. Assurez-vous de taper exactement le même (sensible à la casse)
3. Si oublié, modifiez `ADMIN_RECHARGE_PASSWORD` dans `.env` et redémarrez le serveur

### Erreur : "Hard cap exceeded"

**Cause :** La recharge dépasserait le hard cap de 10M tokens

**Solution :**
1. Rechargez un montant plus petit (voir `maxAllowedRecharge` dans la réponse)
2. Ou augmentez `MAX_BUDGET_HARD_CAP` dans `.env` (⚠️ risque de coûts élevés)

### Erreur : "Amount too low/high"

**Cause :** Montant hors limites (100K - 5M)

**Solution :**
- Minimum : 100,000 tokens
- Maximum : 5,000,000 tokens par recharge
- Pour recharger plus, faites plusieurs recharges

### API non accessible

**Cause :** Serveur M.A.X. non démarré

**Solution :**
```powershell
cd d:\Macrea\CRM\max_backend
npm start
```

---

## 📝 Bonnes pratiques

### ✅ À FAIRE

- ✅ Surveiller le budget régulièrement
- ✅ Recharger AVANT d'atteindre 10%
- ✅ Documenter les raisons de recharge
- ✅ Conserver les logs de recharge
- ✅ Tester les scripts sur un montant minimal d'abord
- ✅ Utiliser le mode Watch pendant les campagnes
- ✅ Vérifier les stats après chaque grosse opération

### ❌ À ÉVITER

- ❌ Recharger au dernier moment (< 5%)
- ❌ Partager le mot de passe admin
- ❌ Désactiver le hard cap
- ❌ Ignorer les alertes de budget faible
- ❌ Recharger sans vérifier le statut d'abord
- ❌ Faire des recharges massives sans raison
- ❌ Oublier de documenter les recharges importantes

---

## 📊 Estimation de la consommation

### Cas d'usage typiques (GPT-4o-mini)

| Action | Tokens approx | Fréquence | Consommation/jour |
|--------|---------------|-----------|-------------------|
| Chat simple | 500-1,000 | 50x/jour | 25,000-50,000 |
| Création champ | 800-1,500 | 10x/jour | 8,000-15,000 |
| Listage leads | 400-800 | 30x/jour | 12,000-24,000 |
| Enrichissement | 1,000-2,000 | 20x/jour | 20,000-40,000 |
| Génération campagne | 3,000-5,000 | 5x/jour | 15,000-25,000 |
| **TOTAL** | - | - | **80,000-154,000** |

**Estimation mensuelle :** 2.4M - 4.6M tokens

**Recommandation :** Budget de 5M tokens/mois pour usage intensif

---

## 🔄 Workflow de recharge mensuel

### Jour 1 du mois

1. **Vérifier le statut**
   ```powershell
   .\MONITOR_TOKENS.ps1
   ```

2. **Analyser la consommation du mois précédent**
   - Consulter `/api/billing/stats`
   - Noter les pics de consommation

3. **Planifier le budget du mois**
   - Si mois standard : 3-5M tokens
   - Si campagne prévue : 7-10M tokens

4. **Effectuer la recharge**
   ```powershell
   .\RECHARGE_TOKENS.ps1 -Amount 5000000 -Reason "Recharge mensuelle novembre"
   ```

### Mi-mois

1. **Vérification intermédiaire**
   ```powershell
   .\MONITOR_TOKENS.ps1
   ```

2. **Si > 50% consommé**, recharger 2-3M supplémentaires

### Fin de mois

1. **Bilan mensuel**
   - Tokens consommés
   - Coût total USD
   - Moyenne par jour

2. **Ajuster la stratégie** pour le mois suivant

---

## 💰 Calcul des coûts

### Formule
```
Coût USD = (Tokens Input / 1,000,000) × 0.25 + (Tokens Output / 1,000,000) × 1.25
```

### Exemples

**Consommation : 1,000,000 tokens (50/50 input/output)**
```
Input: 500,000 tokens → 0.5 × 0.25 = $0.125
Output: 500,000 tokens → 0.5 × 1.25 = $0.625
Total: $0.75
```

**Consommation : 5,000,000 tokens (60/40 input/output)**
```
Input: 3,000,000 tokens → 3 × 0.25 = $0.75
Output: 2,000,000 tokens → 2 × 1.25 = $2.50
Total: $3.25
```

### Estimation budget mensuel

| Tokens/mois | Coût (50/50) | Coût (60/40) | Coût (70/30) |
|-------------|--------------|--------------|--------------|
| 1,000,000 | $0.75 | $0.65 | $0.55 |
| 3,000,000 | $2.25 | $1.95 | $1.65 |
| 5,000,000 | $3.75 | $3.25 | $2.75 |
| 10,000,000 | $7.50 | $6.50 | $5.50 |

---

## 🎓 Support et Contact

Pour toute question ou problème :

1. **Consulter la documentation**
   - Ce guide (GESTION_TOKENS.md)
   - SYSTEME_REPORTING.md pour les activités

2. **Vérifier les logs**
   - `billing/recharges.jsonl` : Historique des recharges
   - `billing/state.json` : État actuel
   - `server.log` : Logs du serveur

3. **Tester les scripts**
   - `.\MONITOR_TOKENS.ps1` : Diagnostiquer l'état
   - `.\RECHARGE_TOKENS.ps1 -Amount 100000` : Test de recharge

---

**Version :** 1.0.0
**Dernière mise à jour :** 16 novembre 2025
**Auteur :** Système M.A.X.
