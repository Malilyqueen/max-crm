-- Migration 001: Créer table tenant_goals pour système de mémoire longue durée
-- Date: 2025-12-10
-- Description: Table pour stocker les objectifs business mesurables des tenants

-- Table tenant_goals
CREATE TABLE IF NOT EXISTS tenant_goals (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id VARCHAR(255) NOT NULL,

  -- Contenu de l'objectif
  goal_text TEXT NOT NULL,
  goal_category VARCHAR(50),

  -- Mesures & progression
  target_value NUMERIC,
  current_value NUMERIC DEFAULT 0,
  unit VARCHAR(50),

  -- Temporalité
  deadline TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),

  -- Statut & priorité
  status VARCHAR(20) DEFAULT 'actif' CHECK (status IN ('actif', 'atteint', 'abandonné', 'archivé')),
  priority INTEGER DEFAULT 50 CHECK (priority >= 1 AND priority <= 100),

  -- Soft delete
  archived BOOLEAN DEFAULT FALSE,
  archived_at TIMESTAMP WITH TIME ZONE,

  -- Métadonnées
  created_by VARCHAR(255),
  metadata JSONB DEFAULT '{}'::jsonb
);

-- Index pour performances
CREATE INDEX IF NOT EXISTS idx_tenant_goals_tenant ON tenant_goals(tenant_id);
CREATE INDEX IF NOT EXISTS idx_tenant_goals_status ON tenant_goals(status);
CREATE INDEX IF NOT EXISTS idx_tenant_goals_archived ON tenant_goals(archived);
CREATE INDEX IF NOT EXISTS idx_tenant_goals_priority ON tenant_goals(priority DESC);
CREATE INDEX IF NOT EXISTS idx_tenant_goals_deadline ON tenant_goals(deadline) WHERE deadline IS NOT NULL;

-- Index composite pour requêtes fréquentes
CREATE INDEX IF NOT EXISTS idx_tenant_goals_active ON tenant_goals(tenant_id, status, archived)
  WHERE archived = FALSE AND status = 'actif';

-- Fonction trigger pour mettre à jour updated_at automatiquement
CREATE OR REPLACE FUNCTION update_tenant_goals_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Trigger sur UPDATE
CREATE TRIGGER trigger_update_tenant_goals_updated_at
  BEFORE UPDATE ON tenant_goals
  FOR EACH ROW
  EXECUTE FUNCTION update_tenant_goals_updated_at();

-- Commentaires pour documentation
COMMENT ON TABLE tenant_goals IS 'Objectifs business mesurables des tenants (mémoire longue durée)';
COMMENT ON COLUMN tenant_goals.goal_text IS 'Description complète de l''objectif';
COMMENT ON COLUMN tenant_goals.goal_category IS 'Catégorie: acquisition, conversion, retention, automation, revenue, other';
COMMENT ON COLUMN tenant_goals.target_value IS 'Valeur cible à atteindre';
COMMENT ON COLUMN tenant_goals.current_value IS 'Progression actuelle';
COMMENT ON COLUMN tenant_goals.unit IS 'Unité de mesure: clients, euros, pourcentage, etc.';
COMMENT ON COLUMN tenant_goals.status IS 'Statut: actif, atteint, abandonné, archivé';
COMMENT ON COLUMN tenant_goals.archived IS 'Soft delete (true = archivé)';
