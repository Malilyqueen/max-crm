-- Migration 009: Table tenant_email_domains (Mode 2 - Custom Domain)
-- Stocke les domaines email validés par tenant via Mailjet MaCréa

CREATE TABLE IF NOT EXISTS tenant_email_domains (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL,
  domain VARCHAR(255) NOT NULL,
  name VARCHAR(255), -- Nom affiché (ex: "Restaurant Le Délice")
  reply_to VARCHAR(255), -- Email reply-to (optionnel, sinon = email)
  mailjet_sender_id BIGINT, -- ID du sender dans Mailjet
  dns_status VARCHAR(20) DEFAULT 'pending' CHECK (dns_status IN ('pending', 'verified', 'failed')),
  dns_instructions JSONB, -- Instructions DNS (SPF, DKIM, DMARC)
  last_dns_check TIMESTAMP, -- Dernière vérification DNS
  verified_at TIMESTAMP, -- Date de validation DNS
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (tenant_id, email)
);

-- Index pour performance
CREATE INDEX idx_tenant_email_domains_tenant ON tenant_email_domains(tenant_id);
CREATE INDEX idx_tenant_email_domains_status ON tenant_email_domains(dns_status);
CREATE INDEX idx_tenant_email_domains_domain ON tenant_email_domains(domain);

-- Trigger updated_at
CREATE OR REPLACE FUNCTION update_tenant_email_domains_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_tenant_email_domains_updated_at
  BEFORE UPDATE ON tenant_email_domains
  FOR EACH ROW
  EXECUTE FUNCTION update_tenant_email_domains_updated_at();

-- Commentaires
COMMENT ON TABLE tenant_email_domains IS 'Domaines email custom validés par tenant (Mode 2 - Branding avancé)';
COMMENT ON COLUMN tenant_email_domains.tenant_id IS 'ID du tenant propriétaire';
COMMENT ON COLUMN tenant_email_domains.email IS 'Email expéditeur complet (ex: contact@restaurant.fr)';
COMMENT ON COLUMN tenant_email_domains.domain IS 'Nom de domaine seul (ex: restaurant.fr)';
COMMENT ON COLUMN tenant_email_domains.dns_status IS 'pending: En attente validation | verified: Domaine validé | failed: Échec validation';
COMMENT ON COLUMN tenant_email_domains.dns_instructions IS 'JSON avec SPF, DKIM, DMARC records';
COMMENT ON COLUMN tenant_email_domains.mailjet_sender_id IS 'ID du sender Mailjet (pour vérification statut)';

-- Données exemple (à supprimer en production)
-- INSERT INTO tenant_email_domains (tenant_id, email, domain, name, dns_status)
-- VALUES ('macrea-demo', 'contact@demo-restaurant.fr', 'demo-restaurant.fr', 'Restaurant Demo', 'pending');
