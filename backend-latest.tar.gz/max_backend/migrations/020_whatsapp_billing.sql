-- =====================================================
-- Migration: WhatsApp Billing System
-- Version: 020
-- Description: Système d'abonnement + recharges WhatsApp
-- =====================================================

-- Table principale billing WhatsApp
CREATE TABLE IF NOT EXISTS whatsapp_billing (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL UNIQUE,

  -- Abonnement mensuel (24,90€/mois)
  subscription_active BOOLEAN DEFAULT false,
  subscription_started_at TIMESTAMPTZ,
  subscription_expires_at TIMESTAMPTZ,
  subscription_price_eur DECIMAL(10,2) DEFAULT 24.90,

  -- Messages inclus dans l'abonnement (100/mois)
  included_messages INTEGER DEFAULT 0,
  included_messages_used INTEGER DEFAULT 0,

  -- Messages recharge (achetés séparément)
  recharged_messages INTEGER DEFAULT 0,
  recharged_messages_used INTEGER DEFAULT 0,

  -- Alertes
  low_balance_alert_sent BOOLEAN DEFAULT false,
  low_balance_threshold INTEGER DEFAULT 20,

  -- Timestamps
  created_at TIMESTAMPTZ DEFAULT NOW(),
  updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Vue calculée pour le solde disponible
CREATE OR REPLACE VIEW whatsapp_billing_summary AS
SELECT
  tenant_id,
  subscription_active,
  subscription_expires_at,

  -- Messages inclus (abonnement)
  included_messages,
  included_messages_used,
  GREATEST(0, included_messages - included_messages_used) AS included_remaining,

  -- Messages rechargés
  recharged_messages,
  recharged_messages_used,
  GREATEST(0, recharged_messages - recharged_messages_used) AS recharged_remaining,

  -- Total disponible
  GREATEST(0, included_messages - included_messages_used) +
  GREATEST(0, recharged_messages - recharged_messages_used) AS total_available,

  -- Alertes
  low_balance_threshold,
  (GREATEST(0, included_messages - included_messages_used) +
   GREATEST(0, recharged_messages - recharged_messages_used)) < low_balance_threshold AS is_low_balance,

  -- Abonnement expire bientôt?
  subscription_expires_at < NOW() + INTERVAL '7 days' AS expires_soon
FROM whatsapp_billing;

-- Table historique des recharges
CREATE TABLE IF NOT EXISTS whatsapp_recharge_history (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL,

  -- Pack acheté
  pack_id VARCHAR(50) NOT NULL,  -- pack_100, pack_250, pack_500, pack_1000
  messages_count INTEGER NOT NULL,
  price_eur DECIMAL(10,2) NOT NULL,

  -- Méta
  created_at TIMESTAMPTZ DEFAULT NOW(),
  created_by VARCHAR(100)
);

-- Index pour performance
CREATE INDEX IF NOT EXISTS idx_whatsapp_billing_tenant ON whatsapp_billing(tenant_id);
CREATE INDEX IF NOT EXISTS idx_whatsapp_billing_active ON whatsapp_billing(subscription_active);
CREATE INDEX IF NOT EXISTS idx_whatsapp_recharge_tenant ON whatsapp_recharge_history(tenant_id);

-- Fonction: Consommer 1 message
CREATE OR REPLACE FUNCTION consume_whatsapp_message(p_tenant_id VARCHAR(100))
RETURNS TABLE(
  success BOOLEAN,
  remaining INTEGER,
  source VARCHAR(20),
  error_message TEXT
) AS $$
DECLARE
  v_billing RECORD;
  v_included_remaining INTEGER;
  v_recharged_remaining INTEGER;
BEGIN
  -- Récupérer état billing
  SELECT * INTO v_billing FROM whatsapp_billing WHERE tenant_id = p_tenant_id;

  -- Pas de billing = erreur
  IF v_billing IS NULL THEN
    RETURN QUERY SELECT false, 0, 'none'::VARCHAR(20), 'Aucun abonnement WhatsApp configuré'::TEXT;
    RETURN;
  END IF;

  -- Abonnement inactif = erreur
  IF NOT v_billing.subscription_active THEN
    RETURN QUERY SELECT false, 0, 'blocked'::VARCHAR(20), 'Abonnement WhatsApp inactif. Veuillez renouveler.'::TEXT;
    RETURN;
  END IF;

  -- Calculer soldes
  v_included_remaining := GREATEST(0, v_billing.included_messages - v_billing.included_messages_used);
  v_recharged_remaining := GREATEST(0, v_billing.recharged_messages - v_billing.recharged_messages_used);

  -- Plus de messages = erreur
  IF (v_included_remaining + v_recharged_remaining) < 1 THEN
    RETURN QUERY SELECT false, 0, 'empty'::VARCHAR(20), 'Solde de messages épuisé. Veuillez recharger.'::TEXT;
    RETURN;
  END IF;

  -- Consommer: priorité aux messages inclus
  IF v_included_remaining > 0 THEN
    UPDATE whatsapp_billing
    SET included_messages_used = included_messages_used + 1,
        updated_at = NOW()
    WHERE tenant_id = p_tenant_id;

    RETURN QUERY SELECT true, (v_included_remaining + v_recharged_remaining - 1), 'included'::VARCHAR(20), NULL::TEXT;
  ELSE
    -- Sinon consommer recharge
    UPDATE whatsapp_billing
    SET recharged_messages_used = recharged_messages_used + 1,
        updated_at = NOW()
    WHERE tenant_id = p_tenant_id;

    RETURN QUERY SELECT true, (v_recharged_remaining - 1), 'recharged'::VARCHAR(20), NULL::TEXT;
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Fonction: Ajouter une recharge
CREATE OR REPLACE FUNCTION add_whatsapp_recharge(
  p_tenant_id VARCHAR(100),
  p_pack_id VARCHAR(50),
  p_messages INTEGER,
  p_price DECIMAL(10,2),
  p_created_by VARCHAR(100) DEFAULT NULL
)
RETURNS BOOLEAN AS $$
BEGIN
  -- S'assurer que le billing existe
  INSERT INTO whatsapp_billing (tenant_id)
  VALUES (p_tenant_id)
  ON CONFLICT (tenant_id) DO NOTHING;

  -- Ajouter les messages
  UPDATE whatsapp_billing
  SET recharged_messages = recharged_messages + p_messages,
      low_balance_alert_sent = false,  -- Reset alerte
      updated_at = NOW()
  WHERE tenant_id = p_tenant_id;

  -- Logger l'historique
  INSERT INTO whatsapp_recharge_history (tenant_id, pack_id, messages_count, price_eur, created_by)
  VALUES (p_tenant_id, p_pack_id, p_messages, p_price, p_created_by);

  RETURN true;
END;
$$ LANGUAGE plpgsql;

-- Fonction: Activer/Renouveler abonnement
CREATE OR REPLACE FUNCTION activate_whatsapp_subscription(
  p_tenant_id VARCHAR(100),
  p_months INTEGER DEFAULT 1
)
RETURNS BOOLEAN AS $$
DECLARE
  v_now TIMESTAMPTZ := NOW();
  v_expires TIMESTAMPTZ;
BEGIN
  -- S'assurer que le billing existe
  INSERT INTO whatsapp_billing (tenant_id)
  VALUES (p_tenant_id)
  ON CONFLICT (tenant_id) DO NOTHING;

  -- Calculer date expiration
  SELECT
    CASE
      WHEN subscription_expires_at > v_now THEN subscription_expires_at + (p_months || ' months')::INTERVAL
      ELSE v_now + (p_months || ' months')::INTERVAL
    END
  INTO v_expires
  FROM whatsapp_billing
  WHERE tenant_id = p_tenant_id;

  -- Mettre à jour
  UPDATE whatsapp_billing
  SET
    subscription_active = true,
    subscription_started_at = COALESCE(subscription_started_at, v_now),
    subscription_expires_at = v_expires,
    -- Reset messages inclus pour le nouveau mois
    included_messages = 100,
    included_messages_used = 0,
    low_balance_alert_sent = false,
    updated_at = v_now
  WHERE tenant_id = p_tenant_id;

  RETURN true;
END;
$$ LANGUAGE plpgsql;

-- Insérer données par défaut pour tenant macrea (test)
INSERT INTO whatsapp_billing (tenant_id, subscription_active, included_messages)
VALUES ('macrea', false, 0)
ON CONFLICT (tenant_id) DO NOTHING;

-- Commentaires
COMMENT ON TABLE whatsapp_billing IS 'Gestion des abonnements et crédits WhatsApp par tenant';
COMMENT ON TABLE whatsapp_recharge_history IS 'Historique des recharges WhatsApp';
COMMENT ON FUNCTION consume_whatsapp_message IS 'Consomme 1 message WhatsApp, retourne succès + solde restant';
COMMENT ON FUNCTION add_whatsapp_recharge IS 'Ajoute une recharge de messages WhatsApp';
COMMENT ON FUNCTION activate_whatsapp_subscription IS 'Active ou renouvelle un abonnement WhatsApp';
