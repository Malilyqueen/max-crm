-- Migration Supabase: Système d'Alertes Vivantes M.A.X.
-- PostgreSQL compatible
-- Database: Supabase

-- Table: lead_activities
-- Track TOUTES les interactions avec les leads

CREATE TABLE IF NOT EXISTS lead_activities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id TEXT NOT NULL DEFAULT 'macrea',
  lead_id TEXT NOT NULL,
  channel TEXT NOT NULL CHECK (channel IN ('whatsapp', 'email', 'call', 'other')),
  direction TEXT NOT NULL CHECK (direction IN ('in', 'out')),
  status TEXT DEFAULT 'sent' CHECK (status IN ('sent', 'delivered', 'failed', 'replied', 'no_answer')),
  message_snippet TEXT,
  meta JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index optimisés pour Supabase (tenant-aware)
CREATE INDEX IF NOT EXISTS idx_lead_activities_tenant ON lead_activities (tenant_id);
CREATE INDEX IF NOT EXISTS idx_lead_activities_tenant_lead_created ON lead_activities (tenant_id, lead_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_lead_activities_channel ON lead_activities (channel);
CREATE INDEX IF NOT EXISTS idx_lead_activities_direction ON lead_activities (direction);

-- Table: max_alerts
-- Alertes générées automatiquement par M.A.X.

CREATE TABLE IF NOT EXISTS max_alerts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id TEXT NOT NULL DEFAULT 'macrea',
  lead_id TEXT NOT NULL,
  type TEXT NOT NULL CHECK (type IN ('NoContact7d', 'NoReply3d')),
  severity TEXT NOT NULL CHECK (severity IN ('low', 'med', 'high')),
  message TEXT NOT NULL,
  suggested_action JSONB,
  created_at TIMESTAMPTZ DEFAULT NOW(),
  resolved_at TIMESTAMPTZ DEFAULT NULL,
  resolved_by TEXT DEFAULT NULL
);

-- Index optimisés (tenant-aware)
CREATE INDEX IF NOT EXISTS idx_max_alerts_tenant ON max_alerts (tenant_id);
CREATE INDEX IF NOT EXISTS idx_max_alerts_tenant_lead ON max_alerts (tenant_id, lead_id);
CREATE INDEX IF NOT EXISTS idx_max_alerts_type ON max_alerts (type);
CREATE INDEX IF NOT EXISTS idx_max_alerts_unresolved ON max_alerts (resolved_at) WHERE resolved_at IS NULL;
CREATE INDEX IF NOT EXISTS idx_max_alerts_severity ON max_alerts (severity);

-- CONTRAINTE UNIQUE: Pas de duplication d'alerte active pour (tenant_id, lead_id, type)
CREATE UNIQUE INDEX IF NOT EXISTS idx_max_alerts_unique_active
ON max_alerts (tenant_id, lead_id, type)
WHERE resolved_at IS NULL;

-- Vue: active_alerts
-- Alertes actives avec infos leads (join EspoCRM via lead_id)
-- Note: Cette vue ne peut pas joindre directement EspoCRM car DB séparées
-- La route API fera le join côté application

CREATE OR REPLACE VIEW active_alerts AS
SELECT
  a.id,
  a.tenant_id,
  a.lead_id,
  a.type,
  a.severity,
  a.message,
  a.suggested_action,
  a.created_at,
  (
    SELECT created_at
    FROM lead_activities
    WHERE lead_id = a.lead_id AND tenant_id = a.tenant_id
    ORDER BY created_at DESC
    LIMIT 1
  ) as last_activity_at
FROM max_alerts a
WHERE a.resolved_at IS NULL
ORDER BY
  CASE a.severity
    WHEN 'high' THEN 1
    WHEN 'med' THEN 2
    WHEN 'low' THEN 3
  END,
  a.created_at DESC;

-- Enable Row Level Security (RLS) - Bonne pratique Supabase
ALTER TABLE lead_activities ENABLE ROW LEVEL SECURITY;
ALTER TABLE max_alerts ENABLE ROW LEVEL SECURITY;

-- Policy: Permettre tout pour service_role (backend API)
-- À ajuster selon vos besoins de sécurité
CREATE POLICY "Enable all for service role" ON lead_activities
  FOR ALL USING (true);

CREATE POLICY "Enable all for service role" ON max_alerts
  FOR ALL USING (true);

-- Commentaires pour documentation
COMMENT ON TABLE lead_activities IS 'Tracking de toutes les interactions avec les leads (WhatsApp, email, appels)';
COMMENT ON TABLE max_alerts IS 'Alertes proactives générées par M.A.X. pour le suivi commercial';
COMMENT ON COLUMN max_alerts.suggested_action IS 'Action suggérée au format JSON: {action: "whatsapp_followup", template: "relance_douce"}';
