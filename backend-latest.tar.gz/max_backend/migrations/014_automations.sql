-- =============================================================================
-- Migration 014: Table automations
-- =============================================================================
-- Stocke les workflows/automatisations (remplace le mock de automationMvp1.js)
--
-- Structure du workflow:
--   - trigger: déclencheur (lead_created, time_based, lead_status_changed)
--   - actions: liste d'actions ordonnées (send_email, wait, add_tag, create_task, update_field)
--   - stats: statistiques d'exécution
-- =============================================================================

-- Table principale des automatisations
CREATE TABLE IF NOT EXISTS automations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(100) NOT NULL,

    -- Métadonnées
    name VARCHAR(255) NOT NULL,
    description TEXT,
    status VARCHAR(20) NOT NULL DEFAULT 'draft' CHECK (status IN ('draft', 'active', 'inactive', 'archived')),

    -- Déclencheur (trigger)
    trigger_type VARCHAR(50) NOT NULL CHECK (trigger_type IN (
        'lead_created',
        'lead_status_changed',
        'lead_scored',
        'time_based',
        'lead_updated',
        'tag_added',
        'manual'
    )),
    trigger_label VARCHAR(255),
    trigger_config JSONB DEFAULT '{}'::jsonb,

    -- Actions (array d'objets action)
    actions JSONB NOT NULL DEFAULT '[]'::jsonb,

    -- Statistiques d'exécution
    stats_total_executions INTEGER DEFAULT 0,
    stats_success_rate DECIMAL(5,2) DEFAULT 0,
    stats_last_executed TIMESTAMP WITH TIME ZONE,
    stats_average_duration INTEGER DEFAULT 0, -- en secondes

    -- Métadonnées de création
    created_by VARCHAR(100) DEFAULT 'user', -- 'user', 'max', 'system'
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes pour les requêtes fréquentes
CREATE INDEX IF NOT EXISTS idx_automations_tenant ON automations(tenant_id);
CREATE INDEX IF NOT EXISTS idx_automations_status ON automations(status);
CREATE INDEX IF NOT EXISTS idx_automations_trigger_type ON automations(trigger_type);
CREATE INDEX IF NOT EXISTS idx_automations_tenant_status ON automations(tenant_id, status);

-- Trigger pour updated_at automatique
CREATE OR REPLACE FUNCTION update_automations_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trigger_automations_updated_at ON automations;
CREATE TRIGGER trigger_automations_updated_at
    BEFORE UPDATE ON automations
    FOR EACH ROW
    EXECUTE FUNCTION update_automations_updated_at();

-- Table pour l'historique d'exécution des automatisations
CREATE TABLE IF NOT EXISTS automation_executions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id VARCHAR(100) NOT NULL,
    automation_id UUID NOT NULL REFERENCES automations(id) ON DELETE CASCADE,

    -- Contexte d'exécution
    lead_id VARCHAR(100), -- ID du lead concerné (si applicable)
    trigger_data JSONB DEFAULT '{}'::jsonb, -- Données du déclencheur

    -- Résultat
    status VARCHAR(20) NOT NULL CHECK (status IN ('pending', 'running', 'success', 'failed', 'cancelled')),
    started_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    completed_at TIMESTAMP WITH TIME ZONE,
    duration_ms INTEGER, -- durée en millisecondes

    -- Détail des actions exécutées
    actions_executed JSONB DEFAULT '[]'::jsonb, -- [{action_id, status, result, error}]
    error_message TEXT,

    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Indexes pour automation_executions
CREATE INDEX IF NOT EXISTS idx_automation_executions_tenant ON automation_executions(tenant_id);
CREATE INDEX IF NOT EXISTS idx_automation_executions_automation ON automation_executions(automation_id);
CREATE INDEX IF NOT EXISTS idx_automation_executions_status ON automation_executions(status);
CREATE INDEX IF NOT EXISTS idx_automation_executions_lead ON automation_executions(lead_id);
CREATE INDEX IF NOT EXISTS idx_automation_executions_date ON automation_executions(created_at DESC);

-- Row Level Security
ALTER TABLE automations ENABLE ROW LEVEL SECURITY;
ALTER TABLE automation_executions ENABLE ROW LEVEL SECURITY;

-- Policies pour automations
DROP POLICY IF EXISTS automations_tenant_isolation ON automations;
CREATE POLICY automations_tenant_isolation ON automations
    FOR ALL
    USING (tenant_id = current_setting('app.tenant_id', true))
    WITH CHECK (tenant_id = current_setting('app.tenant_id', true));

-- Policies pour automation_executions
DROP POLICY IF EXISTS automation_executions_tenant_isolation ON automation_executions;
CREATE POLICY automation_executions_tenant_isolation ON automation_executions
    FOR ALL
    USING (tenant_id = current_setting('app.tenant_id', true))
    WITH CHECK (tenant_id = current_setting('app.tenant_id', true));

-- Commentaires
COMMENT ON TABLE automations IS 'Workflows/automatisations configurables par tenant';
COMMENT ON TABLE automation_executions IS 'Historique des exécutions des automatisations';
COMMENT ON COLUMN automations.trigger_type IS 'Type de déclencheur: lead_created, lead_status_changed, time_based, etc.';
COMMENT ON COLUMN automations.actions IS 'Array JSON des actions: [{id, type, label, description, config, order}]';
COMMENT ON COLUMN automations.stats_average_duration IS 'Durée moyenne d''exécution en secondes';
