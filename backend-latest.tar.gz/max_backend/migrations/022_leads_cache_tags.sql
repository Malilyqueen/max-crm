-- ═══════════════════════════════════════════════════════════════════
-- Migration 022: Ajouter colonne tags à leads_cache
-- ═══════════════════════════════════════════════════════════════════
--
-- Objectif: Stocker les tags (tagsIA + maxTags fusionnés) depuis EspoCRM
-- pour éviter les 403 lors des requêtes directes avec filtre tenant
--
-- ═══════════════════════════════════════════════════════════════════

-- Ajouter la colonne tags (array de texte)
ALTER TABLE leads_cache ADD COLUMN IF NOT EXISTS tags TEXT[] DEFAULT '{}';

-- Index GIN pour recherche efficace dans les arrays
CREATE INDEX IF NOT EXISTS idx_leads_cache_tags ON leads_cache USING GIN (tags);

-- Index composite pour filtre tenant + tags
CREATE INDEX IF NOT EXISTS idx_leads_cache_tenant_tags ON leads_cache USING GIN (tenant_id, tags);

-- Commentaire explicatif
COMMENT ON COLUMN leads_cache.tags IS 'Tags fusionnés depuis EspoCRM (tagsIA + maxTags sans doublons)';
