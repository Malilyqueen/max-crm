-- Migration 001: Création des tables pour la mémoire IA de M.A.X.
-- Phase 2A-Supabase
-- Date: 2025-12-06

-- ============================================================================
-- Table max_sessions : Sessions de conversation avec M.A.X.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.max_sessions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id VARCHAR(255) UNIQUE NOT NULL,
  tenant_id VARCHAR(100) NOT NULL,
  user_id VARCHAR(255),
  user_email VARCHAR(255),
  started_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  last_activity_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  ended_at TIMESTAMPTZ,
  message_count INTEGER DEFAULT 0,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Index pour recherche rapide par session_id
CREATE INDEX IF NOT EXISTS idx_max_sessions_session_id ON public.max_sessions(session_id);

-- Index pour recherche par tenant et date
CREATE INDEX IF NOT EXISTS idx_max_sessions_tenant_date ON public.max_sessions(tenant_id, started_at DESC);

-- Index pour recherche par utilisateur
CREATE INDEX IF NOT EXISTS idx_max_sessions_user ON public.max_sessions(user_email);

-- Trigger pour mettre à jour updated_at automatiquement
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER update_max_sessions_updated_at
  BEFORE UPDATE ON public.max_sessions
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- Table max_logs : Logs des actions de M.A.X.
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.max_logs (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  session_id VARCHAR(255),
  tenant_id VARCHAR(100) NOT NULL,
  user_id VARCHAR(255),
  action_type VARCHAR(100) NOT NULL, -- 'lead_status_changed', 'note_added', 'email_sent', etc.
  action_category VARCHAR(50) NOT NULL, -- 'crm', 'communication', 'automation', etc.
  entity_type VARCHAR(50), -- 'Lead', 'Contact', 'Opportunity', etc.
  entity_id VARCHAR(255),
  description TEXT,
  input_data JSONB,
  output_data JSONB,
  success BOOLEAN DEFAULT true,
  error_message TEXT,
  execution_time_ms INTEGER,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  metadata JSONB DEFAULT '{}'::jsonb
);

-- Index pour recherche par session
CREATE INDEX IF NOT EXISTS idx_max_logs_session ON public.max_logs(session_id, created_at DESC);

-- Index pour recherche par tenant et date
CREATE INDEX IF NOT EXISTS idx_max_logs_tenant_date ON public.max_logs(tenant_id, created_at DESC);

-- Index pour recherche par type d'action
CREATE INDEX IF NOT EXISTS idx_max_logs_action_type ON public.max_logs(action_type, created_at DESC);

-- Index pour recherche par entité
CREATE INDEX IF NOT EXISTS idx_max_logs_entity ON public.max_logs(entity_type, entity_id);

-- Index pour recherche par succès/erreur
CREATE INDEX IF NOT EXISTS idx_max_logs_success ON public.max_logs(success, created_at DESC);

-- ============================================================================
-- Table tenant_memory : Mémoire contextuelle par tenant
-- ============================================================================
CREATE TABLE IF NOT EXISTS public.tenant_memory (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL,
  memory_key VARCHAR(255) NOT NULL,
  memory_type VARCHAR(50) NOT NULL, -- 'preference', 'context', 'learned_pattern', etc.
  memory_value JSONB NOT NULL,
  scope VARCHAR(100) DEFAULT 'global', -- 'global', 'user:{user_id}', 'entity:{entity_type}', etc.
  priority INTEGER DEFAULT 0, -- Pour prioriser certaines mémoires
  expires_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
  last_accessed_at TIMESTAMPTZ,
  access_count INTEGER DEFAULT 0,
  metadata JSONB DEFAULT '{}'::jsonb,
  UNIQUE(tenant_id, memory_key, scope)
);

-- Index pour recherche rapide par tenant et clé
CREATE INDEX IF NOT EXISTS idx_tenant_memory_tenant_key ON public.tenant_memory(tenant_id, memory_key);

-- Index pour recherche par type
CREATE INDEX IF NOT EXISTS idx_tenant_memory_type ON public.tenant_memory(tenant_id, memory_type);

-- Index pour recherche par scope
CREATE INDEX IF NOT EXISTS idx_tenant_memory_scope ON public.tenant_memory(tenant_id, scope);

-- Index pour recherche par priorité
CREATE INDEX IF NOT EXISTS idx_tenant_memory_priority ON public.tenant_memory(tenant_id, priority DESC);

-- Index pour nettoyage des mémoires expirées
CREATE INDEX IF NOT EXISTS idx_tenant_memory_expires ON public.tenant_memory(expires_at) WHERE expires_at IS NOT NULL;

-- Trigger pour mettre à jour updated_at
CREATE TRIGGER update_tenant_memory_updated_at
  BEFORE UPDATE ON public.tenant_memory
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at_column();

-- ============================================================================
-- Politiques RLS (Row Level Security) - Activées pour sécurité
-- ============================================================================

-- Activer RLS sur toutes les tables
ALTER TABLE public.max_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.max_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tenant_memory ENABLE ROW LEVEL SECURITY;

-- Politique : Le service_role peut tout faire (pour le backend M.A.X.)
CREATE POLICY "Service role has full access to max_sessions"
  ON public.max_sessions
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Service role has full access to max_logs"
  ON public.max_logs
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Service role has full access to tenant_memory"
  ON public.tenant_memory
  FOR ALL
  TO service_role
  USING (true)
  WITH CHECK (true);

-- ============================================================================
-- Commentaires pour documentation
-- ============================================================================

COMMENT ON TABLE public.max_sessions IS 'Sessions de conversation avec M.A.X. - Track toutes les interactions utilisateurs';
COMMENT ON TABLE public.max_logs IS 'Logs de toutes les actions effectuées par M.A.X. - Audit trail complet';
COMMENT ON TABLE public.tenant_memory IS 'Mémoire contextuelle de M.A.X. par tenant - Apprentissage et préférences';

COMMENT ON COLUMN public.max_sessions.session_id IS 'Identifiant unique de session (format: session_TIMESTAMP_RANDOM)';
COMMENT ON COLUMN public.max_sessions.tenant_id IS 'ID du tenant (macrea-admin, damath, etc.)';
COMMENT ON COLUMN public.max_sessions.metadata IS 'Métadonnées flexibles: device, browser, ip, etc.';

COMMENT ON COLUMN public.max_logs.action_type IS 'Type d''action spécifique: lead_status_changed, note_added, email_sent, etc.';
COMMENT ON COLUMN public.max_logs.action_category IS 'Catégorie générale: crm, communication, automation, analysis';
COMMENT ON COLUMN public.max_logs.execution_time_ms IS 'Temps d''exécution en millisecondes pour monitoring performance';

COMMENT ON COLUMN public.tenant_memory.memory_key IS 'Clé unique de la mémoire (ex: preferred_language, typical_response_time)';
COMMENT ON COLUMN public.tenant_memory.memory_type IS 'Type: preference, context, learned_pattern, user_habit, etc.';
COMMENT ON COLUMN public.tenant_memory.scope IS 'Portée: global, user:{id}, entity:{type}, session:{id}';
COMMENT ON COLUMN public.tenant_memory.priority IS 'Priorité (0-100) pour hiérarchiser les mémoires importantes';
