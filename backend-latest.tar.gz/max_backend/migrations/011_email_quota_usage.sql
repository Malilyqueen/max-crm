-- Migration 011: Table email_quota_usage
-- Compteur mensuel emails par tenant (Mode 1 & 2)
-- Utilisé pour facturation dépassement (0,005 €/email au-delà de 1000)

CREATE TABLE IF NOT EXISTS email_quota_usage (
  id SERIAL PRIMARY KEY,
  tenant_id VARCHAR(100) NOT NULL,
  year INTEGER NOT NULL, -- Année (ex: 2026)
  month INTEGER NOT NULL, -- Mois (1-12)
  emails_sent INTEGER DEFAULT 0, -- Nombre emails envoyés
  quota_limit INTEGER DEFAULT 1000, -- Quota inclus (copié depuis tenant_settings)
  overage_count INTEGER DEFAULT 0, -- Dépassement (emails au-delà du quota)
  overage_cost_eur DECIMAL(10,4) DEFAULT 0.0000, -- Coût dépassement (0,005 €/email)
  billing_status VARCHAR(20) DEFAULT 'pending' CHECK (billing_status IN ('pending', 'billed', 'paid')),
  billed_at TIMESTAMP, -- Date facturation
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW(),
  UNIQUE (tenant_id, year, month)
);

-- Index pour performance
CREATE INDEX idx_email_quota_usage_tenant ON email_quota_usage(tenant_id);
CREATE INDEX idx_email_quota_usage_period ON email_quota_usage(year, month);
CREATE INDEX idx_email_quota_usage_billing ON email_quota_usage(billing_status);

-- Trigger updated_at
CREATE OR REPLACE FUNCTION update_email_quota_usage_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_email_quota_usage_updated_at
  BEFORE UPDATE ON email_quota_usage
  FOR EACH ROW
  EXECUTE FUNCTION update_email_quota_usage_updated_at();

-- Trigger auto-calcul overage
CREATE OR REPLACE FUNCTION calculate_email_quota_overage()
RETURNS TRIGGER AS $$
BEGIN
  -- Calculer dépassement
  IF NEW.emails_sent > NEW.quota_limit THEN
    NEW.overage_count := NEW.emails_sent - NEW.quota_limit;
    NEW.overage_cost_eur := NEW.overage_count * 0.005;
  ELSE
    NEW.overage_count := 0;
    NEW.overage_cost_eur := 0.0;
  END IF;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_email_quota_overage
  BEFORE INSERT OR UPDATE ON email_quota_usage
  FOR EACH ROW
  EXECUTE FUNCTION calculate_email_quota_overage();

-- Fonction helper: Incrémenter compteur email
CREATE OR REPLACE FUNCTION increment_email_quota(
  p_tenant_id VARCHAR(100),
  p_year INTEGER DEFAULT EXTRACT(YEAR FROM NOW()),
  p_month INTEGER DEFAULT EXTRACT(MONTH FROM NOW())
)
RETURNS VOID AS $$
DECLARE
  v_quota_limit INTEGER;
BEGIN
  -- Récupérer quota depuis tenant_settings
  SELECT email_quota_limit INTO v_quota_limit
  FROM tenant_settings
  WHERE tenant_id = p_tenant_id;

  -- Fallback si pas de settings
  IF v_quota_limit IS NULL THEN
    v_quota_limit := 1000;
  END IF;

  -- Insérer ou incrémenter
  INSERT INTO email_quota_usage (tenant_id, year, month, emails_sent, quota_limit)
  VALUES (p_tenant_id, p_year, p_month, 1, v_quota_limit)
  ON CONFLICT (tenant_id, year, month)
  DO UPDATE SET emails_sent = email_quota_usage.emails_sent + 1;
END;
$$ LANGUAGE plpgsql;

-- Fonction: Récupérer usage du mois en cours
CREATE OR REPLACE FUNCTION get_current_email_quota(p_tenant_id VARCHAR(100))
RETURNS TABLE (
  emails_sent INTEGER,
  quota_limit INTEGER,
  remaining INTEGER,
  overage_count INTEGER,
  overage_cost_eur DECIMAL(10,4),
  percentage_used DECIMAL(5,2)
) AS $$
BEGIN
  RETURN QUERY
  SELECT
    COALESCE(u.emails_sent, 0) AS emails_sent,
    COALESCE(u.quota_limit, 1000) AS quota_limit,
    GREATEST(0, COALESCE(u.quota_limit, 1000) - COALESCE(u.emails_sent, 0)) AS remaining,
    COALESCE(u.overage_count, 0) AS overage_count,
    COALESCE(u.overage_cost_eur, 0.0) AS overage_cost_eur,
    ROUND((COALESCE(u.emails_sent, 0)::DECIMAL / COALESCE(u.quota_limit, 1000)::DECIMAL) * 100, 2) AS percentage_used
  FROM email_quota_usage u
  WHERE u.tenant_id = p_tenant_id
    AND u.year = EXTRACT(YEAR FROM NOW())
    AND u.month = EXTRACT(MONTH FROM NOW());

  -- Si aucune ligne, retourner valeurs par défaut
  IF NOT FOUND THEN
    RETURN QUERY
    SELECT 0, 1000, 1000, 0, 0.0::DECIMAL(10,4), 0.0::DECIMAL(5,2);
  END IF;
END;
$$ LANGUAGE plpgsql;

-- Commentaires
COMMENT ON TABLE email_quota_usage IS 'Compteur mensuel emails par tenant (facturation dépassement)';
COMMENT ON COLUMN email_quota_usage.emails_sent IS 'Nombre total emails envoyés ce mois';
COMMENT ON COLUMN email_quota_usage.quota_limit IS 'Quota inclus (1000 par défaut)';
COMMENT ON COLUMN email_quota_usage.overage_count IS 'Nombre emails au-delà du quota';
COMMENT ON COLUMN email_quota_usage.overage_cost_eur IS 'Coût dépassement (0,005 € par email)';
COMMENT ON COLUMN email_quota_usage.billing_status IS 'pending: Non facturé | billed: Facturé | paid: Payé';

COMMENT ON FUNCTION increment_email_quota IS 'Incrémente le compteur email pour un tenant (appeler après chaque envoi)';
COMMENT ON FUNCTION get_current_email_quota IS 'Récupère l''usage quota du mois en cours pour un tenant';

-- Exemples usage:
-- SELECT increment_email_quota('macrea-admin'); -- +1 email
-- SELECT * FROM get_current_email_quota('macrea-admin'); -- Voir usage
