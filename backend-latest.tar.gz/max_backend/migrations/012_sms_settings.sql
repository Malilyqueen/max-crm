/**
 * Migration 012: SMS Settings - Sender ID + Twilio Self-Service
 *
 * Objectif: Permettre aux tenants de personnaliser leur expéditeur SMS
 *
 * Mode 1 (MaCréa): Sender ID alphanumérique personnalisable
 * Mode 2 (Self-Service): Credentials Twilio propres du client
 *
 * Contraintes:
 * - SMS transactionnels uniquement (pas de marketing)
 * - Sender ID unique globalement (tous tenants)
 * - Templates verrouillés (RDV, confirmation, rappel, notification)
 */

-- ============================================================
-- 1. Ajouter colonnes SMS dans tenant_settings
-- ============================================================

ALTER TABLE tenant_settings
ADD COLUMN IF NOT EXISTS sms_mode VARCHAR(20) DEFAULT 'macrea',
ADD COLUMN IF NOT EXISTS sms_sender_label VARCHAR(50),
ADD COLUMN IF NOT EXISTS sms_sender_id VARCHAR(11),
ADD COLUMN IF NOT EXISTS twilio_messaging_service_sid VARCHAR(50),
ADD COLUMN IF NOT EXISTS twilio_from_number VARCHAR(20);

-- ============================================================
-- 2. Contraintes
-- ============================================================

-- Sender ID unique globalement (éviter collisions entre tenants)
CREATE UNIQUE INDEX IF NOT EXISTS idx_sms_sender_id_unique
ON tenant_settings(sms_sender_id)
WHERE sms_sender_id IS NOT NULL;

-- Sender ID requis en mode MaCréa
ALTER TABLE tenant_settings
ADD CONSTRAINT check_sms_sender_id_required
CHECK (
  sms_mode != 'macrea' OR sms_sender_id IS NOT NULL
);

-- En mode self-service, au moins un identifiant Twilio requis
ALTER TABLE tenant_settings
ADD CONSTRAINT check_twilio_credentials
CHECK (
  sms_mode != 'self_service' OR
  (twilio_messaging_service_sid IS NOT NULL OR twilio_from_number IS NOT NULL)
);

-- Validation format Sender ID (3-11 chars, alphanumeric, starts with letter)
ALTER TABLE tenant_settings
ADD CONSTRAINT check_sms_sender_id_format
CHECK (
  sms_sender_id IS NULL OR (
    LENGTH(sms_sender_id) BETWEEN 3 AND 11 AND
    sms_sender_id ~ '^[A-Z][A-Z0-9]*$'
  )
);

-- ============================================================
-- 3. Valeurs par défaut pour tenants existants
-- ============================================================

-- Générer un sender_id par défaut basé sur le nom du tenant
-- Ex: tenant "macrea" → sender_id "MACREA"
UPDATE tenant_settings
SET
  sms_mode = 'macrea',
  sms_sender_label = COALESCE(
    (SELECT company_name FROM tenants WHERE tenants.id = tenant_settings.tenant_id),
    'MAX CRM'
  ),
  sms_sender_id = UPPER(
    REGEXP_REPLACE(
      COALESCE(
        SUBSTRING(
          (SELECT slug FROM tenants WHERE tenants.id = tenant_settings.tenant_id),
          1, 11
        ),
        'MAXCRM'
      ),
      '[^A-Z0-9]', '', 'g'
    )
  )
WHERE sms_sender_id IS NULL;

-- ============================================================
-- 4. Comments
-- ============================================================

COMMENT ON COLUMN tenant_settings.sms_mode IS
'Mode SMS: macrea (défaut, sender ID partagé) | self_service (Twilio client)';

COMMENT ON COLUMN tenant_settings.sms_sender_label IS
'Nom affiché expéditeur SMS (UX, ex: "Cabinet Dr. Martin")';

COMMENT ON COLUMN tenant_settings.sms_sender_id IS
'Sender ID technique alphanumérique (3-11 chars, unique global, ex: "DRMARTIN")';

COMMENT ON COLUMN tenant_settings.twilio_messaging_service_sid IS
'Mode self-service: Twilio Messaging Service SID (optionnel si twilio_from_number)';

COMMENT ON COLUMN tenant_settings.twilio_from_number IS
'Mode self-service: Numéro Twilio expéditeur (optionnel si messaging_service_sid)';

-- ============================================================
-- 5. Index performance
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_tenant_settings_sms_mode
ON tenant_settings(sms_mode);

-- ============================================================
-- Rollback
-- ============================================================

-- Pour rollback:
-- ALTER TABLE tenant_settings DROP CONSTRAINT IF EXISTS check_sms_sender_id_required;
-- ALTER TABLE tenant_settings DROP CONSTRAINT IF EXISTS check_twilio_credentials;
-- ALTER TABLE tenant_settings DROP CONSTRAINT IF EXISTS check_sms_sender_id_format;
-- DROP INDEX IF EXISTS idx_sms_sender_id_unique;
-- DROP INDEX IF EXISTS idx_tenant_settings_sms_mode;
-- ALTER TABLE tenant_settings DROP COLUMN IF EXISTS sms_mode;
-- ALTER TABLE tenant_settings DROP COLUMN IF EXISTS sms_sender_label;
-- ALTER TABLE tenant_settings DROP COLUMN IF EXISTS sms_sender_id;
-- ALTER TABLE tenant_settings DROP COLUMN IF EXISTS twilio_messaging_service_sid;
-- ALTER TABLE tenant_settings DROP COLUMN IF EXISTS twilio_from_number;