-- Migration 007: Support Lite MVP (Version Safe - Idempotente)
-- Système de tickets minimaliste pour support client

-- Table tickets
CREATE TABLE IF NOT EXISTS support_tickets (
  id SERIAL PRIMARY KEY,
  ticket_number VARCHAR(20) UNIQUE NOT NULL, -- Format: TICK-0001234

  -- Identité
  tenant_id VARCHAR(100) NOT NULL,
  user_id INTEGER NOT NULL, -- Créateur (foreign key vers users si existe)
  user_email VARCHAR(255) NOT NULL, -- Email pour notifications

  -- Contenu
  subject VARCHAR(255) NOT NULL,
  priority VARCHAR(20) DEFAULT 'normal', -- 'urgent', 'normal'

  -- Statut simple
  status VARCHAR(20) DEFAULT 'open', -- 'open', 'replied', 'closed'

  -- Timestamps
  created_at TIMESTAMP DEFAULT NOW(),
  last_activity_at TIMESTAMP DEFAULT NOW(),
  closed_at TIMESTAMP
);

-- Index pour performance (safe)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_tickets_tenant') THEN
    CREATE INDEX idx_tickets_tenant ON support_tickets(tenant_id);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_tickets_status') THEN
    CREATE INDEX idx_tickets_status ON support_tickets(status);
  END IF;
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_tickets_user') THEN
    CREATE INDEX idx_tickets_user ON support_tickets(user_id);
  END IF;
END $$;

-- Table messages (conversation)
CREATE TABLE IF NOT EXISTS support_messages (
  id SERIAL PRIMARY KEY,
  ticket_id INTEGER NOT NULL REFERENCES support_tickets(id) ON DELETE CASCADE,

  -- Auteur
  user_id INTEGER NOT NULL,
  user_email VARCHAR(255) NOT NULL,
  user_name VARCHAR(255),
  is_support BOOLEAN DEFAULT false, -- true si réponse MaCréa, false si client

  -- Contenu
  message TEXT NOT NULL,

  -- Pièce jointe (1 seule max, optionnelle)
  attachment_filename VARCHAR(255),
  attachment_url TEXT,
  attachment_size INTEGER, -- en bytes

  created_at TIMESTAMP DEFAULT NOW()
);

-- Index messages (safe)
DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_indexes WHERE indexname = 'idx_messages_ticket') THEN
    CREATE INDEX idx_messages_ticket ON support_messages(ticket_id);
  END IF;
END $$;

-- Fonction pour générer les numéros de ticket
CREATE OR REPLACE FUNCTION generate_ticket_number()
RETURNS TEXT AS $$
DECLARE
  next_id INTEGER;
BEGIN
  SELECT COALESCE(MAX(CAST(SUBSTRING(ticket_number FROM 6) AS INTEGER)), 0) + 1
  INTO next_id
  FROM support_tickets;

  RETURN 'TICK-' || LPAD(next_id::TEXT, 7, '0');
END;
$$ LANGUAGE plpgsql;

-- Trigger pour auto-générer ticket_number
CREATE OR REPLACE FUNCTION set_ticket_number()
RETURNS TRIGGER AS $$
BEGIN
  IF NEW.ticket_number IS NULL OR NEW.ticket_number = '' THEN
    NEW.ticket_number := generate_ticket_number();
  END IF;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Supprimer l'ancien trigger si existe
DROP TRIGGER IF EXISTS trigger_set_ticket_number ON support_tickets;

-- Créer le trigger
CREATE TRIGGER trigger_set_ticket_number
BEFORE INSERT ON support_tickets
FOR EACH ROW
EXECUTE FUNCTION set_ticket_number();

-- Trigger pour mettre à jour last_activity_at quand nouveau message
CREATE OR REPLACE FUNCTION update_ticket_activity()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE support_tickets
  SET
    last_activity_at = NOW(),
    status = CASE
      WHEN NEW.is_support THEN 'replied'
      ELSE status
    END
  WHERE id = NEW.ticket_id;

  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Supprimer l'ancien trigger si existe
DROP TRIGGER IF EXISTS trigger_update_ticket_activity ON support_messages;

-- Créer le trigger
CREATE TRIGGER trigger_update_ticket_activity
AFTER INSERT ON support_messages
FOR EACH ROW
EXECUTE FUNCTION update_ticket_activity();

-- Vérification finale
DO $$
BEGIN
  RAISE NOTICE 'Migration 007 Support Lite - Appliquée avec succès';
  RAISE NOTICE 'Tables créées: support_tickets, support_messages';
  RAISE NOTICE 'Triggers créés: trigger_set_ticket_number, trigger_update_ticket_activity';
END $$;