# Script de red�marrage propre du serveur M.A.X.
Write-Host "= Red�marrage du serveur M.A.X..." -ForegroundColor Cyan

# Arr�ter tous les processus Node.js sur le port 3005
$port = 3005
$processId = (Get-NetTCPConnection -LocalPort $port -ErrorAction SilentlyContinue).OwningProcess

if ($processId) {
    Write-Host "=� Processus trouv� (PID: $processId) - Arr�t en cours..." -ForegroundColor Yellow
    Stop-Process -Id $processId -Force -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    Write-Host " Processus arr�t�" -ForegroundColor Green
} else {
    Write-Host "9 Aucun processus sur le port $port" -ForegroundColor Gray
}

# Attendre que le port soit lib�r�
Write-Host "� Attente lib�ration du port..." -ForegroundColor Yellow
Start-Sleep -Seconds 2

# D�marrer le serveur
Write-Host "=� D�marrage du serveur..." -ForegroundColor Cyan
Set-Location "d:\Macrea\CRM\max_backend"
npm run dev
