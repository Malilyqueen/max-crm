# Script de monitoring du budget tokens M.A.X.
# Affiche le statut actuel et génère des alertes si nécessaire

param(
    [int]$AlertThreshold = 10,  # Seuil d'alerte en %
    [switch]$Watch,             # Mode surveillance continue
    [int]$RefreshInterval = 30  # Interval de refresh en secondes (mode Watch)
)

$apiUrl = "http://localhost:3005/api/billing"

function Show-TokenStatus {
    param([int]$Threshold)

    Clear-Host

    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host "   M.A.X. TOKEN MONITOR" -ForegroundColor Cyan
    Write-Host "========================================" -ForegroundColor Cyan
    Write-Host ""

    try {
        # Recuperer le statut
        $status = Invoke-RestMethod -Uri "$apiUrl/status" -Method GET

        if (-not $status.ok) {
            Write-Host "Erreur lors de la recuperation du statut" -ForegroundColor Red
            return $false
        }

        # Recuperer les stats
        $stats = Invoke-RestMethod -Uri "$apiUrl/stats" -Method GET

        # Afficher le statut du budget
        Write-Host "BUDGET" -ForegroundColor Yellow
        Write-Host "  Budget actuel: $($status.currentBudget.ToString('N0')) tokens" -ForegroundColor White
        Write-Host "  Consomme: $($status.consumed.ToString('N0')) tokens" -ForegroundColor $(if ($status.percentUsed -gt 75) { "Red" } elseif ($status.percentUsed -gt 50) { "Yellow" } else { "Green" })
        Write-Host "  Restant: $($status.remaining.ToString('N0')) tokens ($([math]::Round(100 - $status.percentUsed, 2))%)" -ForegroundColor $(if ($status.remaining -lt ($status.currentBudget * 0.1)) { "Red" } else { "Green" })
        Write-Host ""

        # Barre de progression
        $barLength = 40
        $usedLength = [math]::Floor($barLength * $status.percentUsed / 100)
        $remainingLength = $barLength - $usedLength

        $bar = "[" + ("=" * $usedLength) + (" " * $remainingLength) + "]"
        $barColor = if ($status.percentUsed -gt 90) { "Red" } elseif ($status.percentUsed -gt 75) { "Yellow" } else { "Green" }

        Write-Host "  $bar $([math]::Round($status.percentUsed, 1))% utilise" -ForegroundColor $barColor
        Write-Host ""

        # Afficher les limites
        Write-Host "LIMITES" -ForegroundColor Yellow
        Write-Host "  Hard cap: $($status.hardCap.ToString('N0')) tokens" -ForegroundColor Gray
        Write-Host "  Capacite restante: $($status.remainingCapacity.ToString('N0')) tokens" -ForegroundColor Gray
        Write-Host ""

        # Afficher les tokens consommes
        Write-Host "CONSOMMATION" -ForegroundColor Yellow
        Write-Host "  Tokens entree: $($stats.tokens.input.ToString('N0'))" -ForegroundColor White
        Write-Host "  Tokens sortie: $($stats.tokens.output.ToString('N0'))" -ForegroundColor White
        Write-Host "  Appels IA: $($stats.tokens.calls)" -ForegroundColor White
        Write-Host "  Moyenne/appel: $([math]::Round($stats.tokens.avgPerCall, 0)) tokens" -ForegroundColor White
        Write-Host ""

        # Afficher les recharges
        Write-Host "RECHARGES" -ForegroundColor Yellow
        Write-Host "  Total recharge: $($stats.recharges.total.ToString('N0')) tokens" -ForegroundColor White
        Write-Host "  Nombre de recharges: $($stats.recharges.count)" -ForegroundColor White

        if ($stats.recharges.last) {
            $lastRechargeTime = [DateTime]::Parse($stats.recharges.last.timestamp)
            $timeSince = (Get-Date) - $lastRechargeTime

            Write-Host "  Derniere recharge: $($stats.recharges.last.amount.ToString('N0')) tokens" -ForegroundColor White

            if ($timeSince.TotalDays -lt 1) {
                Write-Host "    il y a $([math]::Floor($timeSince.TotalHours))h $($timeSince.Minutes)min" -ForegroundColor Gray
            } else {
                Write-Host "    il y a $([math]::Floor($timeSince.TotalDays)) jour(s)" -ForegroundColor Gray
            }
        } else {
            Write-Host "  Aucune recharge effectuee" -ForegroundColor Gray
        }

        Write-Host ""

        # Afficher le cout
        Write-Host "COUT" -ForegroundColor Yellow
        Write-Host "  Total USD: `$$([math]::Round($stats.cost.usd, 4))" -ForegroundColor White
        Write-Host ""

        # Verifier les alertes
        $alert = Invoke-RestMethod -Uri "$apiUrl/alert?threshold=$Threshold" -Method GET

        if ($alert.isLow) {
            Write-Host "========================================" -ForegroundColor Red
            Write-Host "   ALERTE BUDGET FAIBLE !" -ForegroundColor Red
            Write-Host "========================================" -ForegroundColor Red
            Write-Host ""
            Write-Host $alert.message -ForegroundColor Yellow
            Write-Host ""
            Write-Host "Recommandation: Rechargez le budget avec:" -ForegroundColor White
            Write-Host "  .\RECHARGE_TOKENS.ps1" -ForegroundColor Cyan
            Write-Host ""
        } else {
            Write-Host "Budget OK - $($alert.percentRemaining)% restant" -ForegroundColor Green
            Write-Host ""
        }

        # Afficher l'heure de mise a jour
        Write-Host "Derniere mise a jour: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')" -ForegroundColor Gray

        if ($Watch) {
            Write-Host "Prochaine actualisation dans $RefreshInterval secondes... (Ctrl+C pour quitter)" -ForegroundColor Gray
        }

        Write-Host ""
        Write-Host "========================================" -ForegroundColor Cyan

        return $true

    } catch {
        Write-Host ""
        Write-Host "Erreur de connexion a l'API M.A.X." -ForegroundColor Red
        Write-Host "Verifiez que le serveur est demarre sur le port 3005" -ForegroundColor Yellow
        Write-Host ""
        Write-Host "Details: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host ""
        return $false
    }
}

# Mode surveillance continue
if ($Watch) {
    Write-Host "Mode surveillance active (Ctrl+C pour quitter)" -ForegroundColor Cyan
    Write-Host ""

    while ($true) {
        $success = Show-TokenStatus -Threshold $AlertThreshold

        if ($success) {
            Start-Sleep -Seconds $RefreshInterval
        } else {
            Write-Host "Nouvelle tentative dans 10 secondes..." -ForegroundColor Yellow
            Start-Sleep -Seconds 10
        }
    }
} else {
    # Affichage unique
    Show-TokenStatus -Threshold $AlertThreshold
}
