# Script de recharge manuelle du budget tokens M.A.X.
# Utilise l'API sécurisée avec authentification admin

param(
    [int]$Amount = 0,
    [string]$Reason = "Manual recharge via PowerShell"
)

$apiUrl = "http://localhost:3005/api/billing"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "   M.A.X. TOKEN RECHARGE SYSTEM" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

# Récupérer le statut actuel
Write-Host "[1/4] Recuperation du statut actuel..." -ForegroundColor Yellow
try {
    $status = Invoke-RestMethod -Uri "$apiUrl/status" -Method GET

    if ($status.ok) {
        Write-Host "Budget actuel: $($status.currentBudget) tokens" -ForegroundColor Green
        Write-Host "Consomme: $($status.consumed) tokens ($($status.percentUsed)%)" -ForegroundColor White
        Write-Host "Restant: $($status.remaining) tokens" -ForegroundColor Green
        Write-Host "Hard cap: $($status.hardCap) tokens" -ForegroundColor Gray
        Write-Host "Capacite restante: $($status.remainingCapacity) tokens" -ForegroundColor Gray
        Write-Host ""
    } else {
        Write-Host "Erreur lors de la recuperation du statut" -ForegroundColor Red
        exit 1
    }
} catch {
    Write-Host "Impossible de se connecter a l'API M.A.X." -ForegroundColor Red
    Write-Host "Verifiez que le serveur est demarre sur le port 3005" -ForegroundColor Yellow
    exit 1
}

# Demander le montant si non fourni
if ($Amount -eq 0) {
    Write-Host "[2/4] Montant de la recharge" -ForegroundColor Yellow
    Write-Host "Limites: 100,000 - 5,000,000 tokens par recharge" -ForegroundColor Gray
    $Amount = Read-Host "Entrez le montant (tokens)"
    $Amount = [int]$Amount
    Write-Host ""
}

# Valider le montant
if ($Amount -lt 100000) {
    Write-Host "Montant trop faible. Minimum: 100,000 tokens" -ForegroundColor Red
    exit 1
}

if ($Amount -gt 5000000) {
    Write-Host "Montant trop eleve. Maximum: 5,000,000 tokens par recharge" -ForegroundColor Red
    exit 1
}

# Demander le mot de passe admin
Write-Host "[3/4] Authentification admin" -ForegroundColor Yellow
$securePassword = Read-Host "Mot de passe admin" -AsSecureString
$password = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($securePassword))
Write-Host ""

# Effectuer la recharge
Write-Host "[4/4] Execution de la recharge..." -ForegroundColor Yellow

$body = @{
    amount = $Amount
    password = $password
    reason = $Reason
} | ConvertTo-Json

try {
    $result = Invoke-RestMethod -Uri "$apiUrl/recharge" -Method POST -Body $body -ContentType "application/json"

    if ($result.ok -and $result.success) {
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Green
        Write-Host "   RECHARGE REUSSIE !" -ForegroundColor Green
        Write-Host "========================================" -ForegroundColor Green
        Write-Host ""
        Write-Host "Montant recharge: $($result.amount) tokens" -ForegroundColor White
        Write-Host "Ancien budget: $($result.previousBudget) tokens" -ForegroundColor Gray
        Write-Host "Nouveau budget: $($result.newBudget) tokens" -ForegroundColor Green
        Write-Host "Capacite restante: $($result.remainingCapacity) tokens" -ForegroundColor Gray
        Write-Host "Timestamp: $($result.timestamp)" -ForegroundColor Gray
        Write-Host ""
    } else {
        Write-Host ""
        Write-Host "========================================" -ForegroundColor Red
        Write-Host "   ECHEC DE LA RECHARGE" -ForegroundColor Red
        Write-Host "========================================" -ForegroundColor Red
        Write-Host ""
        Write-Host "Erreur: $($result.error)" -ForegroundColor Red

        if ($result.maxAllowedRecharge) {
            Write-Host "Recharge maximale autorisee: $($result.maxAllowedRecharge) tokens" -ForegroundColor Yellow
        }

        Write-Host ""
        exit 1
    }
} catch {
    Write-Host ""
    Write-Host "Erreur lors de la recharge:" -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red

    # Tenter de parser la réponse d'erreur
    try {
        $errorResponse = $_.ErrorDetails.Message | ConvertFrom-Json
        if ($errorResponse.error) {
            Write-Host "Details: $($errorResponse.error)" -ForegroundColor Yellow
        }
    } catch {
        # Ignore parsing errors
    }

    Write-Host ""
    exit 1
}

# Afficher l'historique des dernières recharges
Write-Host "Derniere recharges:" -ForegroundColor Cyan
try {
    $history = Invoke-RestMethod -Uri "$apiUrl/history?limit=5" -Method GET

    if ($history.ok -and $history.count -gt 0) {
        foreach ($recharge in $history.history) {
            $timestamp = [DateTime]::Parse($recharge.timestamp).ToString("yyyy-MM-dd HH:mm:ss")
            $statusIcon = if ($recharge.success) { "✓" } else { "✗" }
            $statusColor = if ($recharge.success) { "Green" } else { "Red" }

            Write-Host "  $statusIcon [$timestamp] $($recharge.amount) tokens" -ForegroundColor $statusColor
            if ($recharge.reason) {
                Write-Host "    Raison: $($recharge.reason)" -ForegroundColor Gray
            }
        }
    }
} catch {
    # Ignore errors for history display
}

Write-Host ""
Write-Host "========================================" -ForegroundColor Cyan
