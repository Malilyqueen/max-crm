# 🛠️ MVP1 - Guide d'Implémentation Complet

**Timeline: 9-10 jours | Version condensée validée**

---

## 📐 Wireframes Détaillés par Page

### **Page 1: 🏠 Dashboard** (Durée: 1 jour)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [Logo MaCréa]  [💰 850/1000 crédits]  [Mode: Assisté ▼]  [⚙️ Admin]   │
├────────────────────────────────────────────────────────────────────────┤
│ 🏠 Dashboard │ 💬 M.A.X. │ 📋 CRM │ ⚙️ Auto │ 📊 Rapports             │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  📊 VUE D'ENSEMBLE                                                     │
│                                                                        │
│  ┌──────────────────────────┐  ┌──────────────────────────┐          │
│  │ 📈 Leads totaux          │  │ 📱 Messages envoyés      │          │
│  │                          │  │                          │          │
│  │       120                │  │        47                │          │
│  │   +12 vs mois dernier    │  │   +8 cette semaine       │          │
│  └──────────────────────────┘  └──────────────────────────┘          │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ 📈 Évolution des leads (30 derniers jours)                       │ │
│  │                                                                  │ │
│  │  [Graphique Chart.js LineChart simple]                          │ │
│  │                                                                  │ │
│  │  120 ┤          ●                                                │ │
│  │      ┤        ●   ●                                              │ │
│  │   90 ┤      ●       ●                                            │ │
│  │      ┤    ●           ●                                          │ │
│  │   60 ┤  ●               ●                                        │ │
│  │      └─────────────────────────────────────────────────          │ │
│  │       J-30  J-20  J-10  Aujourd'hui                              │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ 📅 À VENIR (prochains RDV et rappels)                            │ │
│  │                                                                  │ │
│  │  • RDV Jean Dupont - 15/12 à 14h30                              │ │
│  │  • Relance Sophie Laurent - 16/12                               │ │
│  │  • RDV Pierre Martin - 17/12 à 10h00                            │ │
│  │  • Rappel panier abandonné Marie - 18/12                        │ │
│  │  • RDV Luc Bernard - 20/12 à 16h00                              │ │
│  │                                                                  │ │
│  │  [Voir tout dans MaCréa CRM]                                     │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ ⚠️ ALERTES                                                        │ │
│  │                                                                  │ │
│  │  🔴 3 leads à relancer (pas de contact depuis 7 jours)          │ │
│  │  🟡 Quotas à 85% (150 crédits restants ce mois)                 │ │
│  │  🟢 2 RDV à confirmer aujourd'hui                                │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ ⚡ ACTIONS RAPIDES                                                │ │
│  │                                                                  │ │
│  │  [➕ Nouveau lead]  [📱 Envoyer message]                         │ │
│  │  [📋 Voir CRM]      [⚙️ Créer automatisation]                    │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

**Éléments Indispensables**:
- ✅ **2 KPI** (leads totaux + messages envoyés) avec évolution vs période précédente
- ✅ **1 graphique LineChart** (Chart.js) - évolution leads 30j
- ✅ **Bloc "À venir"** (5 prochains RDV/rappels) - liste simple
- ✅ **3 alertes** (leads à relancer, quotas, RDV à confirmer)
- ✅ **4 boutons rapides** (nouveau lead, envoyer message, voir CRM, créer auto)

---

### **Page 2: 💬 M.A.X. Chat Global** (Durée: 2 jours)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [Logo]  [💰 850/1000]  [Mode: Assisté ▼]  [⚙️]                        │
├────────────────────────────────────────────────────────────────────────┤
│ 🏠 │ 💬 M.A.X. │ 📋 CRM │ ⚙️ Auto │ 📊 Rapports                        │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  💬 M.A.X. - Assistant Global                                         │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ [Historique messages]                                            │ │
│  │                                                                  │ │
│  │  User:                                                           │ │
│  │  Analyse mon CSV des leads Q1                                    │ │
│  │                                                                  │ │
│  │  M.A.X.:                                                         │ │
│  │  J'ai analysé votre fichier CSV. Voici les insights :           │ │
│  │  • 47 leads identifiés                                           │ │
│  │  • 23% secteur e-commerce                                        │ │
│  │  • Taux qualification: 62%                                       │ │
│  │                                                                  │ │
│  │  [Voir le rapport complet] [Exporter résultats]                 │ │
│  │                                                                  │ │
│  │  ─────────────────────────────────────────────────────          │ │
│  │                                                                  │ │
│  │  User:                                                           │ │
│  │  Propose une campagne de relance                                │ │
│  │                                                                  │ │
│  │  M.A.X.:                                                         │ │
│  │  Je suggère 3 scénarios de relance :                            │ │
│  │                                                                  │ │
│  │  1. Relance J+3 (15 leads concernés)                            │ │
│  │     ➜ [Lancer cette campagne]                                   │ │
│  │                                                                  │ │
│  │  2. Rappel panier abandonné (8 leads)                           │ │
│  │     ➜ [Lancer cette campagne]                                   │ │
│  │                                                                  │ │
│  │  3. Confirmation RDV demain (5 leads)                           │ │
│  │     ➜ [Lancer cette campagne]                                   │ │
│  │                                                                  │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ [Tapez votre message...]                            [Envoyer 📤] │ │
│  │                                                                  │ │
│  │ 📎 Joindre CSV  │  🎯 Campagne  │  📊 Analyse                    │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘

// Modale de confirmation (Mode Assisté)
┌────────────────────────────────────────────┐
│ ⚠️ Confirmation d'action                   │
├────────────────────────────────────────────┤
│                                            │
│ M.A.X. va exécuter l'action suivante :    │
│                                            │
│ Envoyer le template "Relance J+3"         │
│ à 15 leads (secteur e-commerce)           │
│                                            │
│ Coût estimé : 15 crédits                  │
│                                            │
│ [Annuler]  [Confirmer et exécuter]        │
│                                            │
└────────────────────────────────────────────┘

// Modale Mode Auto (sécurité)
┌────────────────────────────────────────────┐
│ ⚠️ Mode Automatique                        │
├────────────────────────────────────────────┤
│                                            │
│ En mode Auto, M.A.X. exécutera les        │
│ actions SANS demander votre confirmation. │
│                                            │
│ ⚠️ Utilisez ce mode uniquement si vous    │
│    maîtrisez parfaitement les workflows.  │
│                                            │
│ Exemples d'actions automatiques :         │
│ • Envoi de messages WhatsApp              │
│ • Mise à jour de statuts leads            │
│ • Création de tâches et rappels           │
│                                            │
│ [Annuler]  [Activer Mode Auto]            │
│                                            │
└────────────────────────────────────────────┘
```

**Éléments Indispensables**:
- ✅ **MessageList** scrollable avec messages user/M.A.X.
- ✅ **ChatInput** avec textarea + bouton envoyer
- ✅ **Upload CSV** (bouton + traitement fichier)
- ✅ **Boutons d'action** dans réponses M.A.X. (ex: "Lancer campagne")
- ✅ **ConfirmModal** pour actions sensibles (mode Assisté)
- ✅ **ModeSelector** (dropdown Assisté/Auto/Conseil)
- ✅ **Modale sécurité** pour activation Mode Auto
- ✅ **Loading state** pendant traitement M.A.X.

---

### **Page 3: 📋 CRM avec Panneau Lead** (Durée: 2 jours)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [Logo]  [💰 850/1000]  [Mode: Assisté ▼]  [⚙️]                        │
├────────────────────────────────────────────────────────────────────────┤
│ 🏠 │ 💬 │ 📋 CRM │ ⚙️ │ 📊                                             │
├──────────────────────────────────┬─────────────────────────────────────┤
│ 📋 CRM - Mes Leads               │ 💼 Espace M.A.X.                    │
│                                  │                                     │
│ [🔍 Rechercher...]               │ Lead: Jean Dupont                   │
│ [Statut: Tous ▼] [Secteur: ▼]   │ Entreprise: MaCréa Design           │
│                                  │ Statut: Qualified | Score: 85       │
│ ┌────────────────────────────┐  │                                     │
│ │ 👤 Jean Dupont             │◄─┼─[LEAD SÉLECTIONNÉ]                  │
│ │ MaCréa Design              │  │                                     │
│ │ Qualified | Score: 85      │  │ ─────────────────────────────       │
│ │ [💬 Ouvrir M.A.X.]         │  │                                     │
│ └────────────────────────────┘  │ 💬 Chat contextuel                  │
│                                  │                                     │
│ ┌────────────────────────────┐  │ M.A.X.:                             │
│ │ 👤 Sophie Laurent          │  │ "Jean Dupont est un lead qualifié   │
│ │ E-Shop Pro                 │  │  dans le secteur e-commerce.        │
│ │ New | Score: 42            │  │  RDV confirmé le 15/12 à 14h30."    │
│ │ [💬 Ouvrir M.A.X.]         │  │                                     │
│ └────────────────────────────┘  │ User:                               │
│                                  │ "Envoie la confirmation RDV"        │
│ ┌────────────────────────────┐  │                                     │
│ │ 👤 Pierre Martin           │  │ M.A.X.:                             │
│ │ Tech Corp                  │  │ "✅ Confirmation RDV envoyée via    │
│ │ Contacted | Score: 68      │  │  WhatsApp au +33 6 48 66 27 34"     │
│ │ [💬 Ouvrir M.A.X.]         │  │                                     │
│ └────────────────────────────┘  │ [Votre message...]      [Envoyer]   │
│                                  │                                     │
│ ┌────────────────────────────┐  │ ─────────────────────────────       │
│ │ 👤 Marie Dubois            │  │                                     │
│ │ Beauty Shop                │  │ 📱 5 derniers messages WhatsApp     │
│ │ Qualified | Score: 91      │  │                                     │
│ │ [💬 Ouvrir M.A.X.]         │  │ • 15/12 14:22 - Confirmation RDV ✅ │
│ └────────────────────────────┘  │ • 12/12 10:15 - Relance J+3 ✅      │
│                                  │ • 08/12 16:42 - Premier contact ✅  │
│ ┌────────────────────────────┐  │ • 05/12 09:30 - Bienvenue ✅        │
│ │ 👤 Luc Bernard             │  │ • 02/12 11:20 - Confirmation ✅     │
│ │ Design Studio              │  │                                     │
│ │ New | Score: 55            │  │ [Voir historique complet WhatsApp]  │
│ │ [💬 Ouvrir M.A.X.]         │  │                                     │
│ └────────────────────────────┘  │ ─────────────────────────────       │
│                                  │                                     │
│ [◀ Page 1/5 ▶]                   │ 📅 Rappels et RDV                   │
│                                  │                                     │
│                                  │ • RDV confirmé: 15/12 à 14h30       │
│                                  │ • Relance auto si pas réponse: 20/12│
│                                  │ • Follow-up prévu: 22/12            │
│                                  │                                     │
│                                  │ ─────────────────────────────       │
│                                  │                                     │
│                                  │ 🔗 [Voir dans MaCréa CRM]           │
│                                  │                                     │
│                                  │ [✕ Fermer le panneau]               │
│                                  │                                     │
└──────────────────────────────────┴─────────────────────────────────────┘
```

**Éléments Indispensables**:
- ✅ **SearchBar** (recherche texte temps réel)
- ✅ **FilterBar** (2 dropdowns: Statut + Secteur)
- ✅ **LeadList** avec cartes lead (nom, entreprise, statut, score)
- ✅ **Bouton "Ouvrir M.A.X."** par lead
- ✅ **LeadPanel** (panneau latéral 40% largeur)
- ✅ **Chat contextuel** dans panneau (réutilise MessageList/ChatInput)
- ✅ **WhatsAppPreview** (5 derniers messages) - liste simple avec dates + statuts
- ✅ **RemindersBlock** (3 rappels/RDV max) - liste simple
- ✅ **Bouton "Voir dans MaCréa CRM"** (ouvre nouvel onglet)
- ✅ **Pagination** simple (◀ 1/5 ▶)

---

### **Page 4: ⚙️ Automatisations** (Durée: 1.5 jours)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [Logo]  [💰 850/1000]  [Mode: Assisté ▼]  [⚙️]                        │
├────────────────────────────────────────────────────────────────────────┤
│ 🏠 │ 💬 │ 📋 │ ⚙️ Automatisations │ 📊                                 │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  ⚙️ AUTOMATISATIONS                                                    │
│                                                                        │
│  [📱 Templates WhatsApp]  [📋 Historique]                              │
│  ──────────────────────────────────────────────────────────          │
│                                                                        │
│  📱 TEMPLATES WHATSAPP                                                 │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ Template                     Type          Statut    Action      │ │
│  ├──────────────────────────────────────────────────────────────────┤ │
│  │ Confirmation RDV - TEXT      appointment   ● Active  [○ Toggle] │ │
│  │ Variables: prenom, date, heure                                   │ │
│  │                                                                  │ │
│  │ Confirmation RDV - Quick     appointment   ● Active  [○ Toggle] │ │
│  │ Variables: prenom, date, heure, leadId, tenantId                 │ │
│  │ Boutons: Confirmer, Annuler                                      │ │
│  │                                                                  │ │
│  │ Rappel RDV                   appointment   ● Active  [○ Toggle] │ │
│  │ Variables: prenom, date, heure                                   │ │
│  │                                                                  │ │
│  │ Relance J+1                  follow_up     ● Active  [○ Toggle] │ │
│  │ Variables: prenom, produit                                       │ │
│  │                                                                  │ │
│  │ Relance J+3                  follow_up     ● Active  [○ Toggle] │ │
│  │ Variables: prenom                                                │ │
│  │                                                                  │ │
│  │ Panier abandonné - simple    cart          ● Active  [○ Toggle] │ │
│  │ Variables: prenom, montant, produit                              │ │
│  │                                                                  │ │
│  │ Inscription événement        event         ○ Inactif [○ Toggle] │ │
│  │ Variables: prenom, eventName, date                               │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  Note MVP1: Pas de création/édition de templates dans cette version.  │
│  Les templates sont chargés depuis whatsapp-message-presets.js        │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘

// Onglet Historique
┌────────────────────────────────────────────────────────────────────────┐
│  📋 HISTORIQUE DES ENVOIS                                              │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ Date/Heure       Lead            Template           Statut       │ │
│  ├──────────────────────────────────────────────────────────────────┤ │
│  │ 15/12 14:22     Jean Dupont      Confirmation RDV   ✅ Envoyé    │ │
│  │ 15/12 10:18     Marie Dubois     Relance J+3        ✅ Envoyé    │ │
│  │ 14/12 16:45     Sophie Laurent   Panier abandonné   ✅ Envoyé    │ │
│  │ 14/12 09:30     Pierre Martin    Confirmation RDV   ❌ Échec     │ │
│  │ 13/12 11:20     Luc Bernard      Rappel RDV         ✅ Envoyé    │ │
│  │ 12/12 15:10     Jean Dupont      Relance J+3        ✅ Envoyé    │ │
│  │ 12/12 08:50     Marie Dubois     Inscription event  ✅ Envoyé    │ │
│  │ 11/12 17:30     Sophie Laurent   Confirmation RDV   ✅ Envoyé    │ │
│  │ ...                                                               │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  [◀ Page 1/12 ▶]                                                       │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

**Éléments Indispensables**:
- ✅ **Tabs** (Templates WhatsApp | Historique)
- ✅ **TemplateList** avec colonnes: nom, type, statut, toggle
- ✅ **Toggle switch** pour activer/désactiver template
- ✅ **Affichage variables** par template (lecture seule)
- ✅ **Affichage boutons** (Quick Reply/CTA) si applicable
- ✅ **HistoryTable** avec colonnes: date, lead, template, statut
- ✅ **Pagination** historique
- ❌ **Pas de CRUD** (création/édition templates) en MVP1

---

### **Page 5: 📊 Rapports** (Durée: 0.5 jour)

```
┌────────────────────────────────────────────────────────────────────────┐
│ [Logo]  [💰 850/1000]  [Mode: Assisté ▼]  [⚙️]                        │
├────────────────────────────────────────────────────────────────────────┤
│ 🏠 │ 💬 │ 📋 │ ⚙️ │ 📊 Rapports                                        │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│  📊 RAPPORTS                                                           │
│                                                                        │
│  Période: [7 jours ▼]  (options: 7j, 30j, 90j)                        │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ 📈 Évolution des leads                                           │ │
│  │                                                                  │ │
│  │  [Graphique Chart.js LineChart]                                 │ │
│  │                                                                  │ │
│  │  120 ┤                    ●                                      │ │
│  │      ┤                  ●   ●                                    │ │
│  │   90 ┤                ●       ●                                  │ │
│  │      ┤              ●           ●                                │ │
│  │   60 ┤            ●               ●                              │ │
│  │      ┤          ●                   ●                            │ │
│  │   30 ┤        ●                       ●                          │ │
│  │      └────────────────────────────────────────────              │ │
│  │       J-30  J-25  J-20  J-15  J-10  J-5  Aujourd'hui            │ │
│  │                                                                  │ │
│  │  Total sur la période: 120 leads                                │ │
│  │  Taux de croissance: +15%                                        │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  ┌──────────────────────────────────────────────────────────────────┐ │
│  │ 🏆 Top 10 Leads par Score                                        │ │
│  │                                                                  │ │
│  │  Nom              Entreprise         Statut        Score        │ │
│  │  ─────────────────────────────────────────────────────────────  │ │
│  │  Marie Dubois     Beauty Shop        Qualified      91          │ │
│  │  Jean Dupont      MaCréa Design      Qualified      85          │ │
│  │  Luc Bernard      Design Studio      Qualified      78          │ │
│  │  Sophie Laurent   E-Shop Pro         Qualified      72          │ │
│  │  Pierre Martin    Tech Corp          Contacted      68          │ │
│  │  Claire Moreau    Fashion Ltd        Qualified      65          │ │
│  │  Marc Leroy       Digital Co         New            62          │ │
│  │  Julie Petit      Web Agency         Contacted      58          │ │
│  │  Paul Girard      Start-Up Inc       New            55          │ │
│  │  Anna Roux        Retail Shop        New            52          │ │
│  └──────────────────────────────────────────────────────────────────┘ │
│                                                                        │
│  Note MVP1: Export CSV sera ajouté en Phase 2.                        │
│                                                                        │
└────────────────────────────────────────────────────────────────────────┘
```

**Éléments Indispensables**:
- ✅ **PeriodSelector** (dropdown 7j/30j/90j)
- ✅ **1 graphique LineChart** (Chart.js) - évolution leads
- ✅ **1 tableau** top 10 leads par score
- ✅ **Statistiques résumées** (total période, taux croissance)
- ❌ **Pas d'export CSV** en MVP1 (Phase 2)

---

## 🗂️ Arborescence Complète des Composants React

```
src/
├── main.tsx                           # Point d'entrée
├── App.tsx                            # Router + providers
│
├── pages/
│   ├── AppShell.tsx                   # Layout principal (header + nav + outlet)
│   ├── DashboardPage.tsx              # Page Dashboard
│   ├── ChatPage.tsx                   # Page M.A.X. Chat Global
│   ├── CRMPage.tsx                    # Page CRM avec panneau lead
│   ├── AutomationPage.tsx             # Page Automatisations
│   └── ReportingPage.tsx              # Page Rapports
│
├── components/
│   │
│   ├── common/                        # Composants réutilisables
│   │   ├── Header.tsx                 # Logo + Quotas + Mode + Admin
│   │   ├── Navigation.tsx             # 5 onglets navigation
│   │   ├── ModeSelector.tsx           # Dropdown mode (Assisté/Auto/Conseil)
│   │   ├── ModeAutoModal.tsx          # Modale confirmation Mode Auto
│   │   ├── CreditsBadge.tsx           # Badge quotas avec tooltip
│   │   ├── ConfirmModal.tsx           # Modale confirmation action
│   │   ├── Button.tsx                 # Bouton réutilisable
│   │   ├── Input.tsx                  # Input texte réutilisable
│   │   ├── Select.tsx                 # Dropdown réutilisable
│   │   ├── LoadingSpinner.tsx         # Spinner chargement
│   │   └── ErrorBanner.tsx            # Bannière erreur
│   │
│   ├── dashboard/                     # Composants Dashboard
│   │   ├── KPICard.tsx                # Carte KPI (leads, messages)
│   │   ├── LineChart.tsx              # Graphique évolution (Chart.js)
│   │   ├── UpcomingBlock.tsx          # Bloc "À venir" (RDV/rappels)
│   │   ├── AlertsBlock.tsx            # Bloc alertes (3 max)
│   │   └── QuickActions.tsx           # 4 boutons actions rapides
│   │
│   ├── chat/                          # Composants Chat M.A.X.
│   │   ├── ChatHeader.tsx             # Header chat (mode + titre)
│   │   ├── MessageList.tsx            # Liste messages (scrollable)
│   │   ├── Message.tsx                # Message individuel (user/M.A.X.)
│   │   ├── ChatInput.tsx              # Input + boutons (envoyer, CSV)
│   │   ├── UploadCSV.tsx              # Zone upload CSV + traitement
│   │   └── ActionButtons.tsx          # Boutons d'action dans réponses M.A.X.
│   │
│   ├── crm/                           # Composants CRM
│   │   ├── SearchBar.tsx              # Barre recherche leads
│   │   ├── FilterBar.tsx              # Filtres (statut + secteur)
│   │   ├── LeadList.tsx               # Liste leads avec pagination
│   │   ├── LeadCard.tsx               # Carte lead individuelle
│   │   ├── LeadPanel.tsx              # Panneau latéral lead (container)
│   │   ├── LeadContextChat.tsx        # Chat contextuel dans panneau
│   │   ├── WhatsAppPreview.tsx        # 5 derniers messages WhatsApp
│   │   ├── RemindersBlock.tsx         # 3 rappels/RDV max
│   │   └── ExternalLink.tsx           # Bouton "Voir dans MaCréa CRM"
│   │
│   ├── automation/                    # Composants Automatisations
│   │   ├── TemplateList.tsx           # Liste templates WhatsApp
│   │   ├── TemplateRow.tsx            # Ligne template (nom, toggle, variables)
│   │   ├── ToggleSwitch.tsx           # Switch actif/inactif
│   │   ├── HistoryTable.tsx           # Tableau historique envois
│   │   └── Pagination.tsx             # Pagination réutilisable
│   │
│   └── reporting/                     # Composants Rapports
│       ├── PeriodSelector.tsx         # Dropdown période (7j/30j/90j)
│       ├── LineChart.tsx              # Graphique évolution (réutilise chart.tsx)
│       └── TopLeadsTable.tsx          # Tableau top 10 leads
│
├── stores/                            # Stores Zustand
│   ├── useAppStore.ts                 # Store global (config, quotas)
│   └── useMaxStore.ts                 # Store M.A.X. (chat, mode, contexte)
│
├── hooks/                             # Hooks custom
│   ├── useLeads.ts                    # Hook fetch leads + cache
│   ├── useTemplates.ts                # Hook fetch templates + toggle
│   ├── useCredits.ts                  # Hook fetch quotas (polling)
│   └── useSSE.ts                      # Hook Server-Sent Events (réponses M.A.X.)
│
├── api/                               # API client
│   ├── client.ts                      # Axios config + intercepteurs
│   ├── leads.ts                       # API leads (/leads)
│   ├── chat.ts                        # API chat (/chat/stream)
│   ├── whatsapp.ts                    # API WhatsApp (/whatsapp/messages)
│   ├── automation.ts                  # API automatisations (/automation/history)
│   └── credits.ts                     # API quotas (/credits)
│
├── types/                             # Types TypeScript
│   ├── lead.ts                        # Type Lead
│   ├── message.ts                     # Type Message (chat)
│   ├── template.ts                    # Type WhatsAppTemplate
│   ├── automation.ts                  # Type AutomationExecution
│   └── app.ts                         # Types globaux (Mode, Credits, etc.)
│
├── utils/                             # Utilitaires
│   ├── formatDate.ts                  # Formater dates (fr)
│   ├── formatCurrency.ts              # Formater montants
│   └── classNames.ts                  # Helper classNames (Tailwind)
│
└── styles/
    └── globals.css                    # Styles globaux Tailwind
```

**Total composants MVP1**: ~45 composants

---

## 🏢 Stratégie Multi-tenant (Phase 2)

### **MVP1: Single Tenant Simplifié**

Pour le MVP1, nous adoptons une approche **single-tenant simplifié** :
- ✅ Un seul tenant actif : `defaultTenant` ou `macrea`
- ✅ Pas de routing dynamique Espo/Twilio par tenant
- ✅ Pas de gestion avancée des quotas par tenant
- ✅ Auth simple avec token JWT

### **Types Prêts pour Phase 2**

Les types TypeScript incluent déjà `tenantId` pour faciliter la migration future :

```typescript
// types/app.ts
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
  tenantId?: string; // ← Prévu pour Phase 2
}

// API requests incluent le tenant (optionnel en MVP1)
interface APIConfig {
  headers: {
    'Authorization': `Bearer ${token}`,
    'X-Tenant'?: string; // ← Prévu pour Phase 2
  }
}
```

### **Auth MVP1: Login Simple**

```typescript
// Endpoint auth
POST /api/auth/login
Body: { email: string, password: string }
Response: {
  token: string, // JWT simple
  user: {
    id: string,
    email: string,
    name: string,
    role: 'admin' | 'user',
    tenantId: 'defaultTenant' // ← Fixe en MVP1
  }
}

// Le token est stocké dans localStorage
// Pas de refresh token en MVP1 (Phase 2)
```

### **Ce qui sera fait en Phase 2 (après front MVP1)**

1. **Table `tenants`**
```sql
CREATE TABLE tenants (
  id VARCHAR(255) PRIMARY KEY,
  name VARCHAR(255),
  status ENUM('active', 'suspended'),
  created_at TIMESTAMP
);
```

2. **Table `tenant_connections`**
```sql
CREATE TABLE tenant_connections (
  tenant_id VARCHAR(255),
  service_type ENUM('espocrm', 'twilio'),
  config JSON, -- { baseUrl, apiKey } pour Espo, { accountSid, authToken } pour Twilio
  FOREIGN KEY (tenant_id) REFERENCES tenants(id)
);
```

3. **Middleware tenant resolver**
```javascript
// Lit le token JWT → extrait tenantId → charge config Espo/Twilio
app.use(tenantResolver);
```

4. **Routing dynamique**
```javascript
// Espo API par tenant
const espoConfig = getTenantEspoConfig(req.tenantId);
const espoClient = new EspoClient(espoConfig);

// Twilio API par tenant
const twilioConfig = getTenantTwilioConfig(req.tenantId);
const twilioClient = new Twilio(twilioConfig);
```

5. **Quotas par tenant**
```javascript
// Table tenant_usage
CREATE TABLE tenant_usage (
  tenant_id VARCHAR(255),
  month DATE,
  credits_used INT,
  credits_total INT
);
```

### **Timeline Phase 2 (estimée)**

| Tâche | Durée |
|-------|-------|
| Tables tenants + tenant_connections | 1j |
| Middleware tenant resolver | 1j |
| Routing dynamique Espo/Twilio | 2j |
| Quotas par tenant | 1j |
| Migration données existantes | 1j |
| Tests multi-tenant | 1j |
| **TOTAL Phase 2** | **7 jours** |

**Important** : Phase 2 démarre **APRÈS** livraison du front MVP1 (9-10j).

---

## 🔌 Endpoints Backend Nécessaires (Version Allégée)

### **0. Auth API** (⚠️ À créer - 0.5 jour)

```
POST /api/auth/login
→ Authentification utilisateur
Body: { email: string, password: string }
Response: {
  token: string,
  user: { id, email, name, role, tenantId: 'defaultTenant' }
}

GET /api/auth/me
→ Récupère user depuis token
Headers: Authorization: Bearer <token>
Response: { user: User }
```

### **1. Leads API** (déjà existant ✅)

```
GET /api/leads
→ Retourne tous les leads
Response: { leads: Lead[] }

GET /api/leads/:id
→ Retourne un lead spécifique
Response: Lead

GET /api/leads/:id/whatsapp-history
→ Retourne historique WhatsApp d'un lead
Response: { messages: WhatsAppMessage[] }

GET /api/leads/:id/reminders
→ Retourne rappels/RDV d'un lead
Response: { reminders: Reminder[] }
```

### **2. Chat API** (déjà existant ✅)

```
POST /api/chat/stream
→ Envoie un message à M.A.X. (SSE)
Body: { message: string, context?: { leadId: string } }
Response: SSE stream

POST /api/chat/upload-csv
→ Upload CSV pour analyse
Body: FormData avec fichier CSV
Response: { success: boolean, analysis: object }
```

### **3. WhatsApp API** (déjà existant ✅)

```
GET /api/whatsapp/messages
→ Liste tous les templates WhatsApp
Response: { templates: WhatsAppTemplate[] }

GET /api/whatsapp/messages/:id
→ Récupère un template spécifique
Response: WhatsAppTemplate

POST /api/whatsapp/messages/:id/toggle
→ Active/désactive un template
Response: { success: boolean, status: 'active' | 'inactive' }

POST /api/whatsapp/send
→ Envoie un message WhatsApp
Body: { messageId: string, leadId: string, variables?: object }
Response: { success: boolean, messageSid: string }
```

### **4. Automation API** (⚠️ À créer - 1 jour)

```
GET /api/automation/history
→ Historique des automatisations exécutées
Query params: ?page=1&limit=20
Response: {
  history: AutomationExecution[],
  total: number,
  page: number,
  totalPages: number
}

GET /api/automation/upcoming
→ Prochains RDV et rappels programmés
Response: { upcoming: UpcomingEvent[] }
```

### **5. Credits API** (⚠️ À créer - 0.5 jour)

```
GET /api/credits
→ Récupère quotas du tenant
Response: {
  used: number,
  total: number,
  percentage: number,
  breakdown: {
    chat: number,
    whatsapp: number,
    analysis: number
  }
}
```

### **6. Dashboard API** (⚠️ À créer - 0.5 jour)

```
GET /api/dashboard/kpi
→ Récupère KPI dashboard
Response: {
  leadsTotal: number,
  leadsChange: number, // +12 vs mois dernier
  messagesTotal: number,
  messagesChange: number,
  conversionRate: number
}

GET /api/dashboard/alerts
→ Récupère alertes
Response: { alerts: Alert[] }

GET /api/dashboard/chart-data
→ Données graphique évolution leads
Query params: ?period=30
Response: {
  labels: string[], // ['J-30', 'J-29', ...]
  values: number[]  // [85, 87, 90, ...]
}
```

### **7. Reporting API** (⚠️ À créer - 0.5 jour)

```
GET /api/reporting/leads-evolution
→ Évolution leads pour graphique
Query params: ?period=7|30|90
Response: {
  labels: string[],
  values: number[],
  total: number,
  growthRate: number
}

GET /api/reporting/top-leads
→ Top 10 leads par score
Query params: ?limit=10
Response: { leads: Lead[] }
```

---

## 📊 Résumé Backend Additionnel

| API | Endpoints à créer | Temps estimé |
|-----|-------------------|--------------|
| **Auth** | POST /login, GET /me | 0.5j |
| **Automation** | GET /history, GET /upcoming | 1j |
| **Credits** | GET /credits | 0.5j |
| **Dashboard** | GET /kpi, GET /alerts, GET /chart-data | 0.5j |
| **Reporting** | GET /leads-evolution, GET /top-leads | 0.5j |
| **TOTAL MVP1** | | **3 jours** |

**Note**:
- ✅ Leads, Chat, WhatsApp API déjà fonctionnels
- ⚠️ Auth simple (JWT + user hardcodé ou table users basique)
- 🟣 Multi-tenant complet → Phase 2 (7 jours supplémentaires)

---

## 🛠️ Stack Technique Détaillé

### **Frontend**

```json
{
  "dependencies": {
    "react": "^19.1.1",
    "react-dom": "^19.1.1",
    "react-router-dom": "^7.1.3",
    "zustand": "^5.0.8",
    "axios": "^1.7.9",
    "chart.js": "^4.4.0",
    "react-chartjs-2": "^5.2.0",
    "framer-motion": "^12.23.24",
    "date-fns": "^4.1.0",
    "clsx": "^2.1.0"
  },
  "devDependencies": {
    "@vitejs/plugin-react": "^4.3.4",
    "vite": "^7.1.2",
    "tailwindcss": "^3.4.17",
    "autoprefixer": "^10.4.20",
    "postcss": "^8.4.49",
    "typescript": "^5.7.2",
    "@types/react": "^19.0.6",
    "@types/react-dom": "^19.0.3"
  }
}
```

### **Backend** (déjà installé)

```json
{
  "dependencies": {
    "express": "^4.x",
    "twilio": "^5.x",
    "date-fns": "^4.x",
    "dotenv": "^16.x",
    "cors": "^2.x",
    "axios": "^1.x"
  }
}
```

---

## 📝 Types TypeScript Essentiels

### **types/lead.ts**
```typescript
export interface Lead {
  id: string;
  name: string;
  firstName?: string;
  lastName?: string;
  accountName?: string;
  emailAddress?: string;
  phoneNumber?: string;
  status: 'New' | 'Contacted' | 'Qualified' | 'Lost';
  scoreIA?: number;
  secteurInfere?: string;
  dateStart?: string; // ISO date
  nextMeeting?: {
    dateStart: string;
  };
}
```

### **types/message.ts**
```typescript
export interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  metadata?: {
    action?: string;
    parameters?: object;
  };
}
```

### **types/template.ts**
```typescript
export interface WhatsAppTemplate {
  id: string;
  name: string;
  type: 'appointment' | 'follow_up' | 'cart' | 'event' | 'order';
  status: 'active' | 'draft' | 'archived';
  contentSid: string;
  variables: string[];
  buttons?: Button[];
  messageText: string;
  metadata?: {
    mode: 'text' | 'quick_reply' | 'cta';
    templateName: string;
  };
}

interface Button {
  type: 'QUICK_REPLY' | 'URL' | 'PHONE_NUMBER';
  text: string;
  payload?: string;
  url?: string;
  phoneNumber?: string;
}
```

### **types/automation.ts**
```typescript
export interface AutomationExecution {
  id: string;
  date: string;
  leadId: string;
  leadName: string;
  templateId: string;
  templateName: string;
  status: 'success' | 'failed' | 'queued';
  messageSid?: string;
  error?: string;
}

export interface UpcomingEvent {
  id: string;
  type: 'appointment' | 'reminder' | 'followup';
  leadId: string;
  leadName: string;
  date: string;
  description: string;
}
```

### **types/app.ts**
```typescript
export type Mode = 'assist' | 'auto' | 'conseil';

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'user';
  tenantId?: string; // ← Prévu pour Phase 2 (fixe à 'defaultTenant' en MVP1)
}

export interface AuthResponse {
  token: string;
  user: User;
}

export interface Credits {
  used: number;
  total: number;
  percentage: number;
  breakdown?: {
    chat: number;
    whatsapp: number;
    analysis: number;
  };
}

export interface Alert {
  id: string;
  type: 'error' | 'warning' | 'info' | 'success';
  title: string;
  message: string;
  action?: {
    label: string;
    onClick: () => void;
  };
}
```

---

## 🚦 Plan d'Exécution Jour par Jour

### **Jour 1: Base + Navigation + Auth** ✅
- [ ] Setup Vite + Tailwind + React Router
- [ ] Créer AppShell (layout)
- [ ] Créer Header (logo + quotas + mode)
- [ ] Créer Navigation (5 onglets)
- [ ] Créer 2 stores Zustand (App + Max)
- [ ] Setup API client (axios + intercepteurs token)
- [ ] Créer LoginPage simple (email + password)
- [ ] Créer ProtectedRoute (redirect si pas de token)
- [ ] Créer composants common (Button, Input, Select, LoadingSpinner)
- [ ] **Backend**: Créer endpoint POST /api/auth/login (0.5j)

### **Jour 2-3: Chat M.A.X. Global** 📱
- [ ] Créer ChatPage
- [ ] Créer MessageList + Message
- [ ] Créer ChatInput
- [ ] Intégrer SSE (useSSE hook)
- [ ] Créer UploadCSV
- [ ] Créer ConfirmModal
- [ ] Créer ModeSelector + ModeAutoModal
- [ ] Tester envoi messages + réponses M.A.X.

### **Jour 4-5: CRM + Panneau Lead** 📋
- [ ] Créer CRMPage
- [ ] Créer SearchBar + FilterBar
- [ ] Créer LeadList + LeadCard
- [ ] Créer hook useLeads
- [ ] Créer LeadPanel (panneau latéral)
- [ ] Intégrer LeadContextChat (réutilise composants chat)
- [ ] Créer WhatsAppPreview (5 derniers messages)
- [ ] Créer RemindersBlock (3 rappels)
- [ ] Créer ExternalLink (MaCréa CRM)
- [ ] Tester ouverture/fermeture panneau

### **Jour 6: Dashboard** 🏠
- [ ] Créer DashboardPage
- [ ] Créer KPICard (2 cartes)
- [ ] Intégrer Chart.js + créer LineChart
- [ ] Créer UpcomingBlock (bloc "À venir")
- [ ] Créer AlertsBlock
- [ ] Créer QuickActions
- [ ] Fetch données dashboard (API /dashboard/kpi, /alerts, /chart-data)
- [ ] Tester affichage complet

### **Jour 7: Automatisations** ⚙️
- [ ] Créer AutomationPage avec Tabs
- [ ] Créer TemplateList + TemplateRow
- [ ] Créer ToggleSwitch
- [ ] Hook useTemplates (fetch + toggle)
- [ ] Créer HistoryTable
- [ ] Créer Pagination
- [ ] Fetch historique (API /automation/history)
- [ ] Tester toggle templates + affichage historique

### **Jour 8: Rapports** 📊
- [ ] Créer ReportingPage
- [ ] Créer PeriodSelector
- [ ] Réutiliser LineChart (graphique évolution)
- [ ] Créer TopLeadsTable
- [ ] Fetch données (API /reporting/leads-evolution, /top-leads)
- [ ] Tester changement période + affichage

### **Jour 9: Polish + Tests** ✨
- [ ] Loading states partout
- [ ] Messages d'erreur clairs (ErrorBanner)
- [ ] Responsive basique (mobile-friendly)
- [ ] Animations Framer Motion (transitions pages)
- [ ] Tests manuels complets (tous les flux)
- [ ] Fix bugs identifiés
- [ ] Optimisation performance (lazy loading routes)

---

## ✅ Checklist Finale MVP1

### **Fonctionnalités**
- [ ] 5 pages fonctionnelles (Dashboard, Chat, CRM, Auto, Rapports)
- [ ] Chat M.A.X. global (messages + upload CSV + confirmations)
- [ ] Chat M.A.X. contextuel par lead (panneau CRM)
- [ ] Liste leads avec recherche + filtres
- [ ] Affichage 5 derniers messages WhatsApp par lead
- [ ] Affichage 3 rappels/RDV par lead
- [ ] Templates WhatsApp avec toggle actif/inactif
- [ ] Historique automatisations avec pagination
- [ ] Dashboard avec 2 KPI + 1 graphique + alertes
- [ ] Rapports avec 1 graphique + 1 tableau
- [ ] Mode Assisté/Auto/Conseil avec sécurité
- [ ] Quotas visibles et vulgarisés
- [ ] Lien "Voir dans MaCréa CRM" contextuel

### **Technique**
- [ ] 2 stores Zustand (App + Max)
- [ ] 4 hooks custom (useLeads, useTemplates, useCredits, useSSE)
- [ ] API client structuré (axios)
- [ ] Types TypeScript complets
- [ ] Composants réutilisables (Button, Input, etc.)
- [ ] Chart.js intégré
- [ ] Responsive basique
- [ ] Loading states
- [ ] Error handling

### **Backend**
- [ ] API Automation (/history, /upcoming) créée
- [ ] API Credits (/credits) créée
- [ ] API Dashboard (/kpi, /alerts, /chart-data) créée
- [ ] API Reporting (/leads-evolution, /top-leads) créée

---

## 🎯 Prêt pour la Phase 2

Une fois le MVP1 livré, ces fonctionnalités seront ajoutées en Phase 2:
- Floating chat fonctionnel
- CRUD complet templates WhatsApp
- Workflow builder visuel (si/alors)
- Historique WhatsApp complet par lead
- Calendrier/agenda intégré
- Export CSV rapports
- Recherche avancée
- Filtres complexes
- Statistiques détaillées par template
- Notifications push

---

**Document prêt pour l'implémentation ! Tous les détails sont définis : wireframes, composants, endpoints, types, timeline.** 🚀
